npm i && npx tsc
