import { Context } from "koa";
import { batchAllSelectDB, batchSelectDB, batchUpdateDB, createGroupFunc, deleteGroupFunc, encryptUserId, getAccessTokenByUserId, groupUsersSameUnit } from "./func";
import { logger } from "../../ins";
import config from "../../config";
import { getGroupPermissions, setGroupPermissions } from "../../model/openApi/teamPermissions";
import { createPermissions } from "../../model/openApi/groupTag";
import axios from "axios";
import { getAccessToken, getCompanyToken } from "../authToken/func";
import { batchGetCompanyUsers } from "../../model/openApi/company";
import { getGroupUserList } from "../../model/openApi/enterpriseWordMang/defaultWord";

// 转发团队拉人接口，并判断改团队人员是否为同一单位创建
export async function createGroupHandle(ctx: Context) {
  let msg = ''
  try {
    logger.info({
      msg: '服务端拦截拉人接口触发',
      Header: ctx.header,
      body: ctx.request.body,
      params: ctx.query
    })

    // 转发团队拉人接口
    const result = await createGroupFunc(ctx)
    msg = result
    logger.info({
      msg: '接口转发返回结果',
      result
    })

    if (result.result == 0) {
      // 判断当前团队的成员是否为同一单位下
      await groupUsersSameUnit(ctx)
    }

  } catch (error) {
    const err = error.msg || error.message
    logger.error({ err, msg: '接口转发报错' })
    // msg = error
  }

  logger.info({
    message: 'body返回结果',
    msg
  })
  ctx.body = msg
  ctx.status = 200
  return ctx
}

// 转发团队删除成员接口，并判断改团队人员是否为同一单位创建
export async function deleteGrouphandle(ctx: Context) {
  let msg = ''
  try {
    logger.info({
      msg: '服务端拦截删除团队成员接口触发',
      ctx,
      Header: ctx.header,
      body: ctx.request.body,
      params: ctx.query
    })
    // 转发创建团队接口
    const result = await deleteGroupFunc(ctx)
    msg = result
    logger.info({
      msg: '删除团队成员接口转发返回结果',
      result
    })

    if (result.result == 0) {
      // 判断当前团队的成员是否为同一单位下
      await groupUsersSameUnit(ctx,'del')
    }

  } catch (error) {
    const err = error.msg || error.message
    logger.error({ err, msg: '接口转发报错' })
    // msg = error
  }

  logger.info({
    message: 'body返回结果',
    msg
  })
  ctx.body = msg
  ctx.status = 200
  return ctx
}

export async function getGroupInfo(ctx: Context) {
  try {
    const result = await batchAllSelectDB()
    ctx.body = {
      groupList: result,
      code: '0'
    }
  } catch (error) {
    const err = error.message || error.msg
    logger.error({
      msg: '获取团队中间表数据失败',
      err
    })
    ctx.body = {
      code: '1',
      err
    }
  }
}

// 后台管理系统设置团队标识
export async function setGroupAuth(ctx: Context) {
  try {
    const body = ctx.request.body
    await batchUpdateDB(body)
    ctx.body = {
      data: 'ok',
      code: '0'
    }
  } catch (error) {
    const err = error.message || error.msg
    logger.error({
      msg: '获取团队中间表数据失败',
      err
    })
    ctx.body = {
      code: '1',
      err
    }
  }
  ctx.status = 200
  return ctx
}

// 团队文件列表设置权限
export async function setGroupFileAuth(ctx: Context) {
  let msg = ''
  try {
    logger.info({
      msg: '接口接收到的参数',
      body: ctx.request.body
    })

    const { file_ids, groupid } = ctx.request.body

    // const groupId = '5M7MDE'
    if (groupid && file_ids && file_ids.length) {
      // 开放平台的团队id
      const groupId = await encryptUserId(`${groupid}`)
      logger.info({
        msg: '加密后的团队Id',
        groupId,
        groupid
      })

      // 开放平台的文件id
      let encryptFileInter = file_ids.map((item: any) => {
        return encryptUserId(`${item}`)
      })

      const encryptFileList = await Promise.allSettled(encryptFileInter)
      logger.info({
        msg: '加密后的文件返回结果',
        encryptFileList
      })

      const fileList = encryptFileList.map((item: any) => item.value)
      if (!fileList || !fileList.length) {
        throw new Error("文件Id加密失败");
      }
      // const fileList = ['l4GMDE', 'DZrMDE']
      logger.info({
        msg: '获取到的开放平台文件列表id',
        fileList
      })

      // 查询中间表中是否有当前团队id
      const groupInfoList = await batchSelectDB(groupId)
      logger.info({
        msg: '消息中心中通过团队id查询中间表的数据为:',
        groupInfoList,
        groupId
      })

      if (!groupInfoList || !Array.isArray(groupInfoList) || !groupInfoList.length) {
        logger.info({
          msg: '中间表没有存储该团队信息'
        })

      } else {
        // 获取当前团队创建人的开放平台id
        const userId = groupInfoList[0].user_id.split(',')[0]

        logger.info({
          msg: '通过团队创建着的用户id获取accessToken',
          userId
        })
        // 通过三方用户id获取accessToken
        const accessToken = await getAccessTokenByUserId(userId)

        // 获取当前团队所有的权限列表
        const groupPermission: any = await getGroupPermissions(groupId, accessToken)
        logger.info({
          msg: '获取到当前团队所有的权限列表',
          groupPermission,
          groupId
        })

        // 该团队是否为同一组织下创建 0 是 1 不是
        let is_fit =  groupInfoList[0].is_fit == '1'

        // 超管设置后，一切以超管设置为准
        if(groupInfoList[0].is_premiss == '0') {
          is_fit = false
        }
        logger.info({
          msg: '团队标识',
          is_fit
        })

        // 判断如果当前团队的人员不是同一单位，则无需处理，直接返回结束程序
        if (is_fit) {
          logger.info({
            msg: '该团队不是同单位下创建'
          })


          const groupPermissionList = groupPermission.data.compound_perms.filter((item: any) => item.name == '不同单位下创建')
          logger.info({
            msg: '当前团队是否有“不同单位下创建”权限',
            groupPermissionList
          })
          if (groupPermissionList && groupPermissionList.length == 0) {
            // 没有不同单位下创建权限

            const compound_perms = {
              "compound_perms": [             //权限组合详情数组
                {
                  "name": "不同单位下创建",       //自定义权限组合名称，不能包含特殊字符，不能使用预设名称：View Only、Viewable、Editable
                  "permissions": [        //具体权限数组
                    "view",
                    "new_empty",
                    "upload",
                    "update",
                    "history",
                    "share",
                    // "rename"            //枚举类型："view" "new_empty" "upload" "delete" "move" "download" "share" "copy" "update" "rename" "saveas" "history" "secret" "comment"
                  ]
                }
              ]
            }
            const createResult = await createPermissions(groupId, accessToken, compound_perms)
            logger.info({
              msg: '创建权限结果',
              createResult
            })

            if (createResult.result != 0) {
              throw new Error("创建权限失败");
            }
          }
        }
        const setAuthInterList = fileList.map((item: any) => {
          // 给当前文件设置权限
          const compoundObj = {              //权限组合id, compound_id或compound_name两者必传一个, 否则报错
            "compound_name": is_fit ? "不同单位下创建" : 'Editable',
            "compound_type": is_fit ? "custom" : "preset",     //权限组合类型，枚举：preset（预设）/custom（自定义）
            "subfiles_update": true,            //是否更新子文件相应的授权记录
            "subjects": [                       //需要设置权限的对象
              {
                "subject_type": "role",     //枚举类型：user、role、dept、userGroup
                "subject_id": '2'     //根据subject_type的类型来决定
                //如果subject_type=user，subject_id就是company_uid
                //如果subject_type=userGroup，subject_id就是用户组（标签组）id
                //如果subject_type=role，subject_id就是role_id（角色id）
                //如果subject_type=dept，subject_id就是dept_id（部门id）
              }
            ]
          }
          return setGroupPermissions(accessToken, groupId, item, compoundObj)
        })
        const setResult = await Promise.allSettled(setAuthInterList)
        logger.info({
          msg: '设置权限结果',
          setResult
        })
      }
    } else {
      logger.error({
        msg: '参数不正确'
      })
    }

  } catch (error) {
    logger.info({
      msg: '接口转发报错',
      error
    })
    msg = error.message || error.msg || error.code
  }
  ctx.status = 200
  return ctx
}

// 根据团队id查询团队权限
export async function getGroupAuth(ctx: Context) {
  let msg: any = []
  const { group_id }:any = ctx.query
  try {
    const groupId = await encryptUserId(`${group_id}`)
    const result = await batchSelectDB(groupId)
    logger.info({
      msg: '团队权限为',
      group_id,
      result
    })
    msg = {result}
  } catch (error) {
    const message = error.message || error.msg || error.code
    logger.error({
      msg: '根据团队id查询团队权限报错',
      message
    })
    msg = message
  }
  ctx.body = msg
  ctx.status = 200
  return ctx
}

// 判断该团队是否为tong
export async function setGroupListAuth(ctx: Context) {
  let msg:any = ''
  try {
    
  } catch (error) {
    logger.error({
      msg: '设置团队文件权限失败',
      error
    })
  }
  ctx.body = msg
  ctx.status =200
  return ctx
}


export async function getGroupUserListEvent(data:any) {
    const { userid, groupId, file_id }: any = data
    // 获取企业Token
    const token = await getCompanyToken()
    logger.info({
      msg: '获取到的参数为',
      userid, groupId, token
    })

    // 通过开放平台id获取对应三方用户id
    const receiver = await batchGetCompanyUsers(token, userid)
    logger.info({
      msg: '三方用户信息',
      receiver
    })

    // 第三方用户ID
    const thirdUnionId = receiver.company_users[0].third_union_id
    let accessToken = ''

    if (thirdUnionId) {
      // 获取个人accesstoken
      accessToken = await getAccessToken(thirdUnionId)
      logger.info({
        msg: '获取的accesstoken',
        accessToken
      })
    }
    return await getGroupUserList(token, accessToken, `${groupId}`)
}