import { Context } from "koa"
import { logger } from "../../ins"
import config from "../../config"
import axios, { AxiosError, AxiosRequestConfig } from "axios"
import { sdkInstance } from "../../grpc/sdk"
import { currentTime } from "../../util/momentTime"
import { getGroupUserList, getGroupsPrivate } from "../../model/openApi/enterpriseWordMang/defaultWord"
import { getAccessToken, getCompanyToken } from "../authToken/func"
import { batchGetCompanyUsers } from "../../model/openApi/company"
import { GetCompUsersParams, OpenGetIdConfuseParams } from "../../../ecissdk/model/data"

// 转发拉人进团队接口
export async function createGroupFunc(ctx: Context) {
  return new Promise<any>(async (resolve, reject) => {
    const { request: requestInstance, method, url } = ctx
    const { header, body, query }: any = requestInstance
    logger.info({
      type: 'post body',
      msg: body,
      query,
      header
    })
    const headers = getAuthFromHeader(header as { [key: string]: string })
    logger.info({
      msg: '替换后的header参数',
      headers
    })
    const flag = url.includes('/open')
    let newUrl = ''
    if (flag) {
      newUrl = url.replace('/open', config.baseUrl.openBaseUrl)
    } else {
      newUrl = url.replace('/drive', config.baseUrl.driveBaseUrl)
    }
    logger.info({
      type: 'newUrl',
      msg: newUrl
    })

    try {
      const res = await axios({
        url: newUrl,
        method: 'post',
        data: body,
        headers
      })
      logger.info({
        msg: '接口返回结果',
        data: res.data,
        newUrl,
      })
      return resolve(res.data)
    } catch (e) {
      logger.info({
        type: 'post error',
        msg: e
      })
      let msg = ''
      if (e.name == 'Error' && e.message) {
        msg = e.message
      } else {
        msg = e.messsage || e.msg || e.code
      }

      return reject(msg)
    }
  })
}

// 转发删除团队成员接口
export async function deleteGroupFunc(ctx: Context) {
  return new Promise<any>(async (resolve, reject) => {

    logger.info({
      type: '创建接口转发: handle handleOtherPost init',
      msg: ctx
    })
    const { request: requestInstance, method, url } = ctx
    const { header, body, query }: any = requestInstance
    const headers = getAuthFromHeader(header as { [key: string]: string })
    logger.info({
      type: 'delete body',
      msg: body,
      query,
      headers,
      params: ctx.params
    })
    const flag = url.includes('/open')
    let newUrl = ''
    if (flag) {
      newUrl = url.replace('/open', config.baseUrl.openBaseUrl)
    } else {
      newUrl = url.replace('/drive', config.baseUrl.driveBaseUrl)
    }
    logger.info({
      type: 'newUrl',
      msg: newUrl
    })

    try {
      const res = await axios({
        url: newUrl,
        method: 'delete',
        headers
      })
      logger.info({
        msg: '接口返回结果',
        data: res.data,
        newUrl,
      })
      return resolve(res.data)
    } catch (e) {
      logger.info({
        type: 'delete error',
        msg: e
      })
      let msg = ''
      if (e.name == 'Error' && e.message) {
        msg = e.message
      } else {
        msg = e.messsage || e.msg || e.code
      }

      return reject(msg)
    }
  })
}

// 通过用户id获取对应的二级部门id
export async function getSecondDeptIdByUserId(companyUid: string) {
  return new Promise<any>(async (resolve, reject) => {
    const result = await axios({
      method: 'get',
      url: `${config.domain}/c/zzwjaccount/api/v1/uidGetDeptInfo`,
      params: {
        companyUid
      }
    })
    if (result.data && result.data.result && result.data.result == '200') {
      return resolve(result.data)
    } else {
      return reject('通过用户id获取对应的二级部门id失败')
    }
  })
}

// 判断团队人员是否在同一单位下
export async function groupUsersSameUnit(ctx: Context, type?: string) {
  const { group_id } = ctx.params
  const { company_uids } = ctx.request.body
  // const { access_token, company_token } = ctx.query
  logger.info({
    msg: '接口转发参数',
    params: ctx.params,
    query: ctx.query,
    body: ctx.request.body
  })

  // 查询中间表中是否有当前团队id
  const groupInfoList = await batchSelectDB(group_id)
  logger.info({
    msg: '查询中间表是否有当前团队',
    groupInfoList,
    group_id
  })

  // 获取当前团队下的所有人员id
  let user_ids = []
  // 删除人员时，从中间表获取数据
  if (type == 'del' && groupInfoList && Array.isArray(groupInfoList) && groupInfoList.length) {
    const groupObj = groupInfoList[0]
    user_ids = groupObj.user_id.split(',') || []
  } else {
    user_ids = company_uids ? company_uids.split(',') : []
  }
  logger.info({
    msg: '当前团队下的人员',
    company_uids,
    group_id,
    user_ids,
  })
  if (!(user_ids && user_ids.length)) {
    logger.error({
      msg: '获取当前团队人员id失败',
      company_uids
    })
    throw new Error("获取当前团队人员id失败");

  }

  // 获取企业Token
  const token = await getCompanyToken()
  // const token: any = company_token
  // 用户id
  const userId = user_ids[0]

  logger.info({
    msg: '用户id',
    userId
  })

  // 通过开放平台id获取对应三方用户id
  const receiver = await batchGetCompanyUsers(token, userId)
  logger.info({
    msg: '通过开放平台id获取对应的三方用户id',
    receiver,
    userId
  })

  // 第三方用户ID
  const thirdUnionId = receiver.company_users[0].third_union_id
  let userList: any = []
  // let accessToken: any = access_token
  if (thirdUnionId) {
    // 获取个人accesstoken
    const accessToken = await getAccessToken(thirdUnionId)
    logger.info({
      msg: '获取的accesstoken',
      accessToken
    })
    // 获取团队所有人员数据
    userList = await getGroupUserList(token, accessToken, `${group_id}`)
    logger.info({
      msg: '获取的用户的数据为',
      userList,
      group_id
    })
    if (userList && userList.data && userList.data.length) {
      userList = userList.data.map((item: any) => item.company_uid)
    }
  } else {
    throw new Error("获取三方用户id失败");
  }

  logger.info({
    msg: '该团队下所有的人员信息为',
    userList
  })

  const companyUid = userList.join(',')
  logger.info({
    msg: '请求参数为',
    companyUid
  })

  // 通过部门id查询对应部门所属的二级部门
  const secondDeptList = await getSecondDeptIdByUserId(companyUid)
  logger.info({
    msg: '拿到的所有部门数据为,',
    secondDeptList
  })
  let is_tag = false
  let secondDeptids: any = []
  let thirdDeptids: any = []
  secondDeptList.data.map((item: any) => {
    if (item.org_dept_second_id) {
      secondDeptids.push(item.org_dept_second_id)
    }
    if (item.org_dept_third_id) {
      thirdDeptids.push(item.org_dept_third_id)
    }
  })
  if (secondDeptids && secondDeptids.length && secondDeptList.data.length && secondDeptids.length == secondDeptList.data.length) {
    function unique() {
      let list:any = []
      for (let index = 0; index < thirdDeptids.length; index++) {
        const element = thirdDeptids[index];
        if(!list.includes(element)) {
          list.push(element)
        }
      }

      return list.length == 1
    }
    // 判断三级组织是否相同
    if (unique()) {
      is_tag = true
    }else {
      is_tag = false
    }
      
  }
  logger.info({
    msg: '拿到所有的二级部门id',
    secondDeptids
  })

  let second_org_id: any = []

  logger.info({
    msg: '获取到的原有数据为==',
    groupInfoList,
    second_org_id
  })
  secondDeptids.forEach((item: any) => {
    if (!second_org_id.includes(item)) {
      second_org_id.push(item)
    }
  })

  logger.info({
    msg: '获取到的原有数据为',
    second_org_id,
    secondDeptids
  })

  const time = currentTime()
  const groupDbObj = {
    user_id: userList.join(','),
    second_org_id: second_org_id.join(','),
    is_fit: (second_org_id.length == 1) && is_tag ? '0' : '1',
    is_premiss: (second_org_id.length == 1) && is_tag ? '0' : '1',
    group_id,
    group_name: '',
    time
  }
  logger.info({
    msg: '插入数据库数据源',
    groupDbObj
  })
  if (groupInfoList.length) {
    // 更新
    await batchUpdateDB(groupDbObj)
  } else {
    // 新增
    // 将数据保存到数据库中
    await batchInsertDB(groupDbObj)
  }

}

// 插入数据库
async function batchInsertDB(data: any) {
  const sql = `INSERT INTO middle_notify_record (user_id, second_org_id, is_fit, is_premiss, group_id, group_name, description, creat_time, update_time) VALUES (?,?,?,?,?,?,?,?,?)`
  const insertData = await sdkInstance.middleware.mysql.insert(
    config.dbName,
    sql,
    [
      data.user_id,
      data.second_org_id,
      data.is_fit,
      data.is_premiss,
      data.group_id,
      data.group_name,
      '',
      data.time,
      data.time,
    ]
  )
  /* 返回结果判断 */
  if (insertData.result !== 'ok') throw Error('插入团队中间表失败。SqlStr:【' + JSON.stringify(data) + '】')
}

// 更新数据库
export async function batchUpdateDB(data: any) {
  /* 更新中间表 */
  const delData = await sdkInstance.middleware.mysql.update(
    config.dbName,
    'UPDATE middle_notify_record SET user_id=?, second_org_id=?, is_fit=?, is_premiss=?, update_time=? WHERE group_id=?',
    [data.user_id, data.second_org_id, data.is_fit, data.is_premiss, data.time, data.group_id]
  )
  logger.info({
    msg: `修改团队-中间表:${data.group_id}`
  })
  /* 如果错误，抛出错误 */
  if (delData.result !== 'ok') throw Error('更新部门中间表失败。')
}

// 删除中间表数据数据库
export async function batchDeteleDB(group_id: string) {
  /* 更新中间表 */
  const delMiddleUserDept = await sdkInstance.middleware.mysql.delete(
    config.dbName,
    'DELETE FROM middle_notify_record WHERE group_id=?',
    [group_id]
  )
  logger.info({
    msg: `删除部门用户关联中间表:${group_id}`
  })
  /* 如果错误，抛出错误 */
  if (delMiddleUserDept.result !== 'ok') {
    throw Error('删除用户部门关联表失败。')
  }
}

// 按照wps企业成员Id获取对应的部门id
export async function batchSelectDB(group_id: any) {
  return new Promise<any>(async (resolve, reject) => {
    try {
      logger.info({
        msg: '数据库中的查找的数据',
        group_id,
      })
      /* 获取表里用户数据 */
      const SQLResult: any = await sdkInstance.middleware.mysql.select(
        config.dbName,
        `SELECT * FROM middle_notify_record WHERE group_id=?`,
        [group_id]
      )

      logger.info({
        msg: '查询数据库中的数据为：',
        SQLResult
      })

      const groupList = SQLResult.data && SQLResult.data.rows && Array.isArray(SQLResult.data.rows)
        ? SQLResult.data.rows
        : []

      return resolve(groupList)
    } catch (error) {
      const err = error.message || error.msg
      logger.info({
        msg: '查询数据库报错',
        err
      })
      return resolve([])
    }
  })
}

// 查询所有数据
export async function batchAllSelectDB() {
  const SQLResult = await sdkInstance.middleware.mysql.select(
    config.dbName,
    'SELECT * FROM middle_notify_record',
    []
  )
  const SQLUserList =
    SQLResult.data &&
      SQLResult.data.rows &&
      Array.isArray(SQLResult.data.rows)
      ? SQLResult.data.rows
      : []

  return SQLUserList
}

/**
 * 加密用户ID
 * @param userId
 */
export async function encryptUserId(userId: string) {
  const params: OpenGetIdConfuseParams = {
    queryStr: `raw_text=${userId}`
  }
  const result = await sdkInstance.service.wpsopen.getIdConfuse(params)
  logger.info({
    msg: '加密结果:',
    userId,
    result
  })
  if (
    result &&
    result.result === 'ok' &&
    result.data &&
    result.data.confuse_result
  ) {
    return result.data.confuse_result
  } else {
    throw new Error(`加密用户或部门ID：${userId}失败!${result.msg}`)
  }
}

/**
 * 获取用户信息
 * @param userId
 * @param compId
 */
export async function getUserInfo(userId: string) {
  const params: GetCompUsersParams = {
    path: {
      comp_id: config.compId
    },
    queryStr: `user_id=${userId}&status=1`
  }
  logger.info({
    msg: '请求参数',
    userId,
    comp_id: config.compId
  })
  const result = await sdkInstance.service.dev.wpsplus.getCompUsers(params)

  logger.info({
    msg: 'getCompUsers接口返回结果',
    result
  })

  if (result && result.result === 'ok') {
    if (result.data && result.data.users && result.data.users.length > 0) {
      return result.data.users[0]
    } else {
      throw new Error(`根据compId:${config.compId},userId:${userId} 未查询到相关用户!`)
    }
  } else {
    throw new Error('获取用户信息失败!' + result.msg)
  }
}

/**
 * 通过用户id获取access_token
 * @param userId 
 */
export async function getAccessTokenByUserId(userId: string) {
  return new Promise<string>(async (resolve, reject) => {
    try {
      // const userInfoObj = await getUserInfo(userId)
      // logger.info({
      //   msg: '获取云文档长用户id',
      //   userInfoObj,
      //   userId
      // })

      // if (!userInfoObj.comp_uid) {
      //   return reject('获取用户长id失败')
      // }

      // // 加密用户获取开放平台id
      // const openuserId = await encryptUserId(userInfoObj.comp_uid)
      // logger.info({
      //   msg: '获取用户开放平台id',
      //   openuserId
      // })

      // 获取token
      const token = await getCompanyToken()

      // 通过开放平台id获取对应三方用户id
      const receiver: any = await batchGetCompanyUsers(token, userId)
      logger.info({
        msg: '三方用户信息',
        receiver
      })

      if (receiver.company_users && receiver.company_users.length == 0) {
        return reject('通过开放平台id获取三方用户信息失败')
      }

      // 第三方用户ID
      const thirdUnionId = receiver.company_users[0].third_union_id
      let accessToken = ''

      if (thirdUnionId) {
        // 获取个人accesstoken
        accessToken = await getAccessToken(thirdUnionId)
        logger.info({
          msg: '获取的accesstoken',
          accessToken
        })

      }
      return resolve(accessToken)
    } catch (error) {
      logger.info({
        msg: '获取accessToken失败',
        error
      })
      return reject('获取accessToken失败')
    }
  })
}

// 取出原始签名
export const getAuthFromHeader = (header: { [key: string]: string }) => {
  const {
    'x-origin': xOrigin,
    'content-type': contentType,
    'content-md5': contentMd5,
    'x-auth': xAuth,
    date
  } = header
  return {
    'x-origin': `${xOrigin}`,
    'content-type': `${contentType}`,
    'content-md5': `${contentMd5}`,
    'x-auth': `${xAuth}`,
    date: `${date}`
  }
}

