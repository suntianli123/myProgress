import { Context } from "koa"
import { logger } from "../../ins"
import axios from "axios"
import config from "../../config"
import { batchDeteleDB, getAuthFromHeader } from "../groupAuth/func"


export function errEventFunc(error: any) {
  logger.info({ msg: 'error返回数据:', error })
  const e = JSON.parse(JSON.stringify(error))
  let body: any = ''
  if (e.status == 403 && e.code == 'ERR_BAD_REQUEST') {
    logger.info('触发了')
    body = {
      msg: "您的操作权限不足",
      result: "permissionDenied"
    }
  }
  logger.info({
    msg: '返回的数据为',
    body
  })
  return body
}

// get 请求
export async function handleOtherGetFunc(ctx: Context) {
  const { request: requestInstance, method, url } = ctx
  const { header }: any = requestInstance
  logger.info({
    msg: 'get请求参数为',
    method,
    body: ctx.request.body,
    query: ctx.query,
    header
  })
  const headers = getAuthFromHeader(header as { [key: string]: string })
  logger.info({
    msg: '替换后的header参数',
    headers
  })
  const flag = url.includes('/open')
  let newUrl = ''
  if (flag) {
    newUrl = url.replace('/open', config.baseUrl.openBaseUrl)
  } else {
    newUrl = url.replace('/drive', config.baseUrl.driveBaseUrl)
  }

  logger.info({
    type: 'newUrl',
    msg: newUrl
  })
  try {
    const res = await axios({
      url: newUrl,
      method: 'get',
      headers
    })
    logger.info({
      type: `get接口返回结果`,
      data: res.data,
    })
    ctx.status = 200
    ctx.body = res.data
  } catch (e) {
    logger.info({
      type: 'get error',
      msg: e
    })
    let msg = ''
    if (e.name == 'Error' && e.message) {
      msg = e.message
    } else {
      msg = e.messsage || e.msg || e.code
    }
    ctx.body = msg
  }
  return ctx
}

// delete 请求
export async function handleOtherDeleteFunc(ctx: Context) {
  const { request: requestInstance, method, url } = ctx
  const { header }: any = requestInstance
  logger.info({
    msg: '请求参数为',
    method,
    body: ctx.request.body,
    params: ctx.query,
    header
  })
  const headers = getAuthFromHeader(header as { [key: string]: string })
  const flag = url.includes('/open')
  let newUrl = ''
  if (flag) {
    newUrl = url.replace('/open', config.baseUrl.openBaseUrl)
  } else {
    newUrl = url.replace('/drive', config.baseUrl.driveBaseUrl)
  }

  try {
    const res = await axios({
      url: newUrl,
      method: 'delete',
      // params: flag ? {} : ctx.query,
      headers
    })
    logger.info({
      type: `${url} res`,
      msg: res.data
    })
    
    ctx.status = 200
    ctx.body = res.data
  } catch (e) {
    logger.info({
      type: 'delete error',
      msg: e
    })
    ctx.status = e.status || 403
    const result = errEventFunc(e)
    logger.info({ msg: 'result返回参数为:', result })
    ctx.body = result ? result : e
  }

  return ctx
}

// post请求
export async function handleOtherPostFunc(ctx: Context) {
  const { request: requestInstance, method, url } = ctx
  const { header, body, query }: any = requestInstance
  logger.info({
    msg: '请求参数为',
    method,
    body: ctx.request.body,
    params: ctx.query,
    header
  })
  const headers = getAuthFromHeader(header as { [key: string]: string })
  const flag = url.includes('/open')
  let newUrl = ''
  if (flag) {
    newUrl = url.replace('/open', config.baseUrl.openBaseUrl)
  } else {
    newUrl = url.replace('/drive', config.baseUrl.driveBaseUrl)
  }

  logger.info({
    type: 'newUrl',
    msg: newUrl
  })
  let res
  try {
    res = await axios({
      url: newUrl,
      method: 'post',
      // params: flag ? {} : ctx.query,
      data: body,
      headers
    })
    logger.info({
      type: `${url} res`,
      msg: res.data
    })
    ctx.body = res.data
    ctx.status = 200
  } catch (e) {
    logger.info({
      type: 'post error',
      msg: e
    })
    ctx.status = e.status || 403
    const result = errEventFunc(e)
    logger.info({ msg: 'result返回参数为:', result })
    ctx.body = result ? result : e
  }
  return ctx
}

// put 请求
export async function handleOtherPutFunc(ctx: Context) {
  const { request: requestInstance, method, params, url } = ctx
  const { header, querystring, body }: any = requestInstance
  logger.info({
    msg: '请求参数为',
    method,
    body: ctx.request.body,
    params: ctx.query,
    header
  })
  const headers = getAuthFromHeader(header as { [key: string]: string })
  const flag = url.includes('/open')
  let newUrl = ''
  if (flag) {
    newUrl = url.replace('/open', config.baseUrl.openBaseUrl)
  } else {
    newUrl = url.replace('/drive', config.baseUrl.driveBaseUrl)
  }

  logger.info({
    type: 'newUrl',
    msg: newUrl
  })
  try {
    const res = await axios({
      url: newUrl,
      method: 'put',
      // params: flag ? {} : ctx.query,
      data: body,
      headers
    })
    logger.info({
      type: `${url} res`,
      msg: res.data
    })
    ctx.status = 200
    ctx.body = res.data
  } catch (e) {
    logger.info({
      type: 'put error',
      msg: e
    })
    ctx.status = e.status || 403
    const result = errEventFunc(e)
    logger.info({ msg: 'result返回参数为:', result })
    ctx.body = result ? result : e
  }

  return ctx
}