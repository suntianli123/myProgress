import { Context } from 'koa'
import { logger } from '../ins'
import { sdkInstance } from '../grpc/sdk'
import { handleOtherDeleteFunc, handleOtherGetFunc, handleOtherPostFunc, handleOtherPutFunc } from './interfaceForward'
import { createGroupHandle, deleteGrouphandle, getGroupAuth, getGroupInfo, getGroupUserListEvent, setGroupAuth, setGroupFileAuth, setGroupListAuth } from './groupAuth'
import { getAccessToken, getCompanyToken } from './authToken/func'
import { batchGetCompanyUsers, companyInfo, getCompanyUsers } from '../model/openApi/company'
import { addpersonJoInGroups, delGroupUsers, getGroupList, getGroupUserList } from '../model/openApi/enterpriseWordMang/defaultWord'
import { batchDeteleDB, batchSelectDB, encryptUserId, getSecondDeptIdByUserId, getUserInfo, groupUsersSameUnit } from './groupAuth/func'
import { notificationA } from './notification'
import { createPermissions, getGroupPermissions, getPremissionsRoleMsg, setGroupPermissions } from '../model/openApi/teamPermissions'
import { ErrResp } from '../../ecissdk/model/resHelper'
import { authUserTokenByUnionid } from '../model/openApi/authToken'
import config from '../config'
const Router = require('@koa/router')

export function api() {
  const router = new Router()
  // 指定路由
  router.get('/api/test/ping', async function (ctx: Context) {
    ctx.status = 200
    ctx.body = {
      result: 'ok'
    }
    return ctx
  })
  // 添加团队人员接口
  router.post('/api/v1/addGroups/:group_id', async (ctx: Context) => {
    try {
      logger.info({
        msg: '接口参数',
        params: ctx.params,
        query: ctx.query,
        body: ctx.request.body
      })
      const { group_id }: any = ctx.params
      const { company_uids, userid } = ctx.request.body

      // 获取企业Token
      const token = await getCompanyToken()

      // 通过开放平台id获取对应三方用户id
      const receiver = await batchGetCompanyUsers(token, userid)
      logger.info({
        msg: '三方用户信息',
        receiver
      })

      // 第三方用户ID
      const thirdUnionId = receiver.company_users[0].third_union_id
      let accessToken = ''

      if (thirdUnionId) {
        // 获取个人accesstoken
        accessToken = await getAccessToken(thirdUnionId)
        logger.info({
          msg: '获取的accesstoken',
          accessToken
        })
      }

      const result: any = await addpersonJoInGroups(token, accessToken, group_id, company_uids)
      ctx.body = result
    } catch (error) {
      logger.error({
        msg: '添加团队人员失败',
        error
      })
      const msg = error.message || error.msg || error.code
      ctx.body = msg
    }
    ctx.status = 200
    return ctx
  })

  // 获取开放平台用户id
  router.get('/api/v1/openUserId', async (ctx: Context) => {
    const { userid } = ctx.query
    const userInfoObj = await getUserInfo(`${userid}`)
    logger.info({
      msg: '长用户id',
      userid,
      userInfoObj
    })
    const params: any = {
      queryStr: `raw_text=${userInfoObj.comp_uid}`
    }
    const result = await sdkInstance.service.wpsopen.getIdConfuse(params)
    logger.info({
      result,
      msg: '开放平台用户id'
    })
    ctx.body = result
    ctx.status = 200
    return ctx
  })

  // 获取开放平台用户id
  router.get('/api/v1/getUserInfo', async (ctx: Context) => {
    try {
      const { userid } = ctx.query
      const result = await getUserInfo(`${userid}`)
      ctx.body = result
    } catch (error) {
      logger.error({ error, msg: '获取长用户id失败' })
    }
    ctx.status = 200
    return ctx
  })

  // 加密接口
  router.get('/api/v1/encryptUserId', async (ctx: Context) => {
    const { userid } = ctx.query
    ctx.body = await encryptUserId(`${userid}`)
    ctx.status = 200
    return ctx
  })

  // 获取企业所有人接口
  router.get('/api/v1/getAllUser', async (ctx: Context) => {
    // 获取企业Token
    const token = await getCompanyToken()
    ctx.body = await getCompanyUsers(token, 0, 999)
    ctx.status = 200
    return ctx
  })

  // 获取所有团队接口
  router.get('/api/v1/getGroupList', async (ctx: Context) => {
    try {
      const { userid }: any = ctx.query

      // 获取企业Token
      const token = await getCompanyToken()

      // 通过开放平台id获取对应三方用户id
      const receiver = await batchGetCompanyUsers(token, userid)
      logger.info({
        msg: '三方用户信息',
        receiver
      })

      // 第三方用户ID
      const thirdUnionId = receiver.company_users[0].third_union_id
      let accessToken = ''

      if (thirdUnionId) {
        // 获取个人accesstoken
        accessToken = await getAccessToken(thirdUnionId)
        logger.info({
          msg: '获取的accesstoken',
          accessToken
        })
      }

      ctx.body = await getGroupList(token, accessToken)
    } catch (error) {
      logger.error({
        error,
        msg: '获取所有团队列表'
      })
    }
    ctx.status = 200
    return ctx
  })

  // 接收消息中心推送
  // router.post('/api/v1/notification', notificationA)

  router.post('/api/v1/createCommoud', async (ctx: Context) => {
    const { group_id, userid }: any = ctx.query
    // 获取企业Token
    const token = await getCompanyToken()

    // 通过开放平台id获取对应三方用户id
    const receiver = await batchGetCompanyUsers(token, userid)
    logger.info({
      msg: '三方用户信息',
      receiver
    })

    // 第三方用户ID
    const thirdUnionId = receiver.company_users[0].third_union_id
    let accessToken = ''

    if (thirdUnionId) {
      // 获取个人accesstoken
      accessToken = await getAccessToken(thirdUnionId)
      logger.info({
        msg: '获取的accesstoken',
        accessToken
      })
    }
    // const result = await getGroupPermissions(group_id, accessToken)

    const compound_perms = {
      "compound_perms": [             //权限组合详情数组
        {
          "name": "测试",       //自定义权限组合名称，不能包含特殊字符，不能使用预设名称：View Only、Viewable、Editable
          "permissions": [        //具体权限数组
            "view",
            "new_empty",
            "upload",
            "update",
            "history",
            "share"
            // "rename"            //枚举类型："view" "new_empty" "upload" "delete" "move" "download" "share" "copy" "update" "rename" "saveas" "history" "secret" "comment"
          ]
        }
      ]
    }
    const resulta = await createPermissions(group_id, accessToken, compound_perms)
    ctx.body = resulta
    ctx.status = 200
    return ctx
  })

  // 获取团队中所有人员数据
  router.get('/api/v1/getGroupUserList', async (ctx: Context) => {
    const { userid, groupId, file_id }: any = ctx.query
    ctx.body = await getGroupUserListEvent(ctx.query)
    ctx.status = 200
    return ctx
  })

  // 响应etcd配置，
  router.post('/inject/v2/replace/GetMetadata/:fileid', async (ctx: Context) => {

    const body: any = ctx.request.body
    try {
      const headers: any = ctx.headers
      const fileid = ctx.params.fileid

      logger.info('請求了這個接口：/inject/v2/replace/GetMetadata/{fileid}')
      logger.info({
        params: ctx.params,
        msg: 'params参数',
        url: ctx.request.url
      })


      if (!fileid) {
        return {
          result: 'ERR_BAD_FILE_ID',
          data: '文件id不可用'
        }
      }

      logger.info({ info: `request file copy interceptor, headers: ${JSON.stringify(headers)}` })


      logger.info({
        body,
        msg: 'body参数333333'
      })
      // 文档创建者id 未加密
      const creatorid = body.creator.deprecated_id
      // 当前用户id 未加密
      const currentUserid = body.user.deprecated_id


      // 当前文档所属团队id 未加密
      const group_id = body.file.attrs.groupid

      logger.info({
        msg: '用户信息',
        data: {
          creatorid,
          currentUserid,
        }
      })
      let is_tag = true // true 不允许文件落地 false 允许文件落地
      // if (currentUserid == creatorid) {
      //   is_tag = false
      // } else 
      if (body && body.file && body.file.user_acl) {

        // 当前登录人和文档创建人不是一个人
        // 查询团队对应权限
        const groupId = await encryptUserId(`${group_id}`)
        const groupAuthList = await batchSelectDB(groupId)
        logger.info({
          msg: '团队权限为',
          group_id,
          groupAuthList
        })

        if (groupAuthList && groupAuthList.length) {
          const authObj = groupAuthList[0]

          // 同单位或跨单位允许下载的
          // 判断当前登录人是否在团队内

          // 获取团队创建着开放平台用户id
          const createUserInfoObj = await getUserInfo(`${creatorid}`)
          logger.info({
            msg: '长用户id',
            creatorid,
            createUserInfoObj
          })
          const createOpenUserId = await encryptUserId(`${createUserInfoObj.comp_uid}`)
          logger.info({
            msg: '开放平台用户id',
            createOpenUserId
          })

          // 获取当前登陆着开放平台用户id
          const currentUserInfoObj = await getUserInfo(`${currentUserid}`)
          logger.info({
            msg: '长用户id',
            creatorid,
            currentUserInfoObj
          })
          const currentOpenUserId = await encryptUserId(`${currentUserInfoObj.comp_uid}`)
          logger.info({
            msg: '开放平台用户id',
            currentOpenUserId
          })

          // is_tag = false
          // 查询该团队所有人员信息
          const groupUserList: any = await getGroupUserListEvent({ userid: createOpenUserId, groupId })
          logger.info({
            msg: '获取团队所有人员为',
            groupUserList
          })
          if (groupUserList?.data?.length == 1) {
            // 个人团队文档
            if (creatorid == currentUserid) {
              // 当前登录人与团队创建人为同一用户
              is_tag = false
            } else {
              // 不是同一个人,则查询两个人是否为同一个二级单位下
              // 通过部门id查询对应部门所属的二级部门
              let secondDeptList = await getSecondDeptIdByUserId(`${currentOpenUserId},${createOpenUserId}`)
              logger.info({
                msg: '拿到的所有部门数据为,',
                secondDeptList
              })

              let secondDeptids: any = []
              let thirdDeptids: any = []

              secondDeptList.data.forEach((item: any) => {
                if (item.org_dept_second_id) {
                  secondDeptList.push(item.org_dept_second_id)
                }
                if (item.org_dept_third_id) {
                  thirdDeptids.push(item.org_dept_third_id)
                }
              })
              if (secondDeptids.length == 2) {
                logger.info({
                  msg: '拿到所有的二级部门id',
                  secondDeptids
                })

                let second_org_id: any = []

                logger.info({
                  msg: '获取到的原有数据为==',
                  second_org_id
                })
                secondDeptids.forEach((item: any) => {
                  if (!second_org_id.includes(item)) {
                    second_org_id.push(item)
                  }
                })

                logger.info({
                  msg: '获取到的原有数据为',
                  second_org_id,
                  secondDeptids
                })
                if (secondDeptids.length == 1) {
                  // 同一个二级单位
                  if (thirdDeptids.length == 2 && thirdDeptids[0] == thirdDeptids[1]) {
                    is_tag = false
                  } else {
                    is_tag = true
                  }

                } else {
                  // 不是同一个二级单位
                  is_tag = true
                }

              } else {
                is_tag = true
              }

            }
          } else {
            // 团队文档
            const groupList = groupUserList.data.filter((item: any) => item.company_uid == currentOpenUserId)
            console.log('是否为当前团队中的一员', groupList)
            // 判断当前人员是否为团队的一员，则允许查看
            if (groupList.length) {
              // 是团队中一员
              if (authObj.is_premiss == 0) {
                is_tag = false
              } else {
                is_tag = true
              }
            } else {
              // 不是团队一员
              // 通过部门id查询对应部门所属的二级部门
              const secondDeptList = await getSecondDeptIdByUserId(`${currentOpenUserId},${createOpenUserId}`)
              logger.info({
                msg: '拿到的所有部门数据为,',
                secondDeptList
              })

              let secondDeptids: any = []
              let thirdDeptids: any = []

              secondDeptList.data.forEach((item: any) => {
                if (item.org_dept_second_id) {
                  secondDeptids.push(item.org_dept_second_id)
                }
                if (item.org_dept_third_id) {
                  thirdDeptids.push(item.org_dept_third_id)
                }
              })
              if (secondDeptids.length == 2) {
                logger.info({
                  msg: '拿到所有的二级部门id',
                  secondDeptids
                })

                let second_org_id: any = []

                logger.info({
                  msg: '获取到的原有数据为==',
                  second_org_id
                })
                secondDeptids.forEach((item: any) => {
                  if (!second_org_id.includes(item)) {
                    second_org_id.push(item)
                  }
                })

                logger.info({
                  msg: '获取到的原有数据为',
                  second_org_id,
                  secondDeptids
                })
                if (secondDeptids.length == 1) {
                  // 同一个二级单位
                  // 再查看是否是同一个三级单位
                  if (thirdDeptids.length == 2 && thirdDeptids[0] == thirdDeptids[1]) {
                    is_tag = false
                  } else {
                    is_tag = true
                  }
                } else {
                  // 不是同一个二级单位
                  is_tag = true
                }

              } else {
                is_tag = true
              }
            }
          }

        }else if(groupAuthList && groupAuthList.length == 0 && creatorid == currentUserid) {
          is_tag = false
        } else {
          is_tag = true
        }

      }
      if (is_tag) {
        body.file.user_acl.copy = 0
        body.file.user_acl.print = 0
        body.file.user_acl.saveas = 0
        body.file.user_acl.download = 0
      }
      logger.info({
        msg: '返回的权限位：',
        origPerm: body.user.attrs.origPerm,
        body
      })
      ctx.body = body
    } catch (error) {
      logger.error({
        msg: '报错信息',
        error
      })
      ctx.body = body
    }
    ctx.status = 200
    return ctx
  })

  // 删除团队人员
  router.delete('/api/v1/delGroupUser', async (ctx: Context) => {
    const { userid, groupId, companyId }: any = ctx.query
    // 获取企业Token
    const token = await getCompanyToken()

    // 通过开放平台id获取对应三方用户id
    const receiver = await batchGetCompanyUsers(token, userid)
    logger.info({
      msg: '三方用户信息',
      receiver
    })

    // 第三方用户ID
    const thirdUnionId = receiver.company_users[0].third_union_id
    let accessToken = ''

    if (thirdUnionId) {
      // 获取个人accesstoken
      accessToken = await getAccessToken(thirdUnionId)
      logger.info({
        msg: '获取的accesstoken',
        accessToken
      })
    }
    ctx.body = await delGroupUsers(token, accessToken, groupId, companyId)
    ctx.status = 200
    return ctx
  })

  router.get('/api/v1/getRoleMsg', async (ctx: Context) => {
    const { groupId, userid }: any = ctx.query
    // 获取企业Token
    const token = await getCompanyToken()

    // 通过开放平台id获取对应三方用户id
    const receiver = await batchGetCompanyUsers(token, userid)
    logger.info({
      msg: '三方用户信息',
      receiver
    })

    // 第三方用户ID
    const thirdUnionId = receiver.company_users[0].third_union_id
    let accessToken = ''

    if (thirdUnionId) {
      // 获取个人accesstoken
      accessToken = await getAccessToken(thirdUnionId)
      logger.info({
        msg: '获取的accesstoken',
        accessToken
      })
    }
    ctx.body = await getPremissionsRoleMsg(accessToken, groupId)
    ctx.status = 200
    return ctx
  })

  // 团队文档设置权限 (已作废)
  // router.post('/api/v1/setGroupFileAuth', setGroupFileAuth)

  // 根据团队id查询该团队权限
  router.get('/api/v1/getGroupAuth', getGroupAuth)


  // 查询数据库中间表数据
  router.get('/api/v1/getGroupInfo', getGroupInfo)

  // 后台管理系统设置对应团队文档权限
  router.post('/api/v1/setGroupAuth', setGroupAuth)

  // 获取access_token
  router.get('/api/v1/getAccessToken', async (ctx: Context) => {
    const thirdUnionId: any = ctx.query.thirdUnionId
    ctx.body = await authUserTokenByUnionid(thirdUnionId)
    ctx.status = 200
    return ctx
  })

  // 手动判断团队是否同一单位创建
  router.post('/api/v1/setGroupListAuth/:group_id', async (ctx: Context) => {
    try {
      await groupUsersSameUnit(ctx)
      ctx.body = '数据保存完成'

    } catch (error) {
      logger.error({
        msg: '手动判断团队是否同一单位创建',
        error
      })
    }
    ctx.status = 200
    return ctx
  })

  // 服务端拦截团队拉人接口
  router.post('/open/drive/v1/corpgroups/:group_id/members', createGroupHandle)

  // 服务端拦截团队解散接口
  router.delete('/open/drive/v1/corpgroups/:group_id', async (ctx: Context) => {
    try {
      const result = await handleOtherDeleteFunc(ctx)
      logger.info({ msg: '删除中间表结果', result })
      if (result.result == 0) {
        if (ctx.params && Array.isArray(Object.keys(ctx.params)) && Object.keys(ctx.params).length == 1) {
          const res = await batchDeteleDB(ctx.params.group_id)
          logger.info({ msg: '删除中间表结果', res })
        }
      }
      ctx.body = result
    } catch (error) {
      logger.error({
        msg: '团队解散报错',
        error
      })
    }
    ctx.status = 200
    return ctx
  })

  // 获取云文档企业Id
  router.get('/api/v1/getCompId', async(ctx:Context) => {
    ctx.body = config.compId
    ctx.status = 200
    return ctx
  })

  // 服务端拦截删除团队成员接口
  router.delete('/open/drive/v1/corpgroups/:group_id/members/:company_uid', deleteGrouphandle)



  router.post('/open/drive/v1/corpgroups/(.*)', handleOtherPostFunc)
  router.get('/open/drive/v1/corpgroups/(.*)', handleOtherGetFunc)
  router.delete('/open/drive/v1/corpgroups/(.*)', handleOtherDeleteFunc)
  router.put('/open/drive/v1/corpgroups/(.*)', handleOtherPutFunc)

  router.post('/open/drive/v1/corpgroups', handleOtherPostFunc)
  router.get('/open/drive/v1/corpgroups', handleOtherGetFunc)
  router.delete('/open/drive/v1/corpgroups', handleOtherDeleteFunc)
  router.put('/open/drive/v1/corpgroups', handleOtherPutFunc)




  return router
}
