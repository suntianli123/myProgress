// import sdkInstance from '../../util/sdk'
import { sdkInstance } from '../../grpc/sdk'
import { resCheck, sdkCheck } from '../../util/msgCode'
import { companyToken } from '../../model/openApi/company'
import { logger } from '../../ins'
import { authUserTokenByUnionid } from '../../model/openApi/authToken'


/**
 * @name  验证是否刷新
 * @param tempToken
 * @returns {boolean} true 刷新 false不刷新
 */
export function chechTimer(tempToken: any) {
  let res = true
  if (tempToken && tempToken.data && tempToken.data.data) {
    try {
      const temp = JSON.parse(tempToken.data.data).expire
      res = temp < new Date().getTime()
    } catch (error) {
      res = true
    }
  }
  return res
}

/**
 * @name get
 * @returns {string} 企业token
 */
export async function getCompanyToken(reset = false): Promise<string> {
  const resData: any = await companyToken()
  return resData.token.company_token
  let tempToken: any = await sdkInstance.middleware.cache.get('company_token')
  sdkCheck(tempToken)
  if (!tempToken.data.data || chechTimer(tempToken) || reset) {
    /** 通过企业app应用获取企业信息 */
    const resData: any = await companyToken()
    logger.info({
      msg: '获取token接口返回结果',
      data: resData
    })
    resCheck(resData)
    // eslint-disable-next-line camelcase
    const { expires_in, company_token } = resData.token
    // eslint-disable-next-line camelcase
    const timestamp = new Date().getTime() + expires_in
    const value = { value: company_token, expire: timestamp }
    const setCompanyToken = await sdkInstance.middleware.cache.set(
      'company_token',
      JSON.stringify(value)
    )
    sdkCheck(setCompanyToken)
    // eslint-disable-next-line camelcase
    tempToken = company_token
  } else {
    tempToken = JSON.parse(tempToken.data.data).value
  }
  logger.info({
    msg: '获取token返回结果',
    data: tempToken
  })
  return tempToken
}

/**
 * @name get
 * @returns {string} 个人token
 */
export async function getAccessToken(thirdUnionId: string, reset = false): Promise<string> {
  const resData: any = await authUserTokenByUnionid(thirdUnionId)
  return resData.token.access_token
  let tempToken: any = await sdkInstance.middleware.cache.get('access_token')
  sdkCheck(tempToken)
  if (!tempToken.data.data || chechTimer(tempToken) || reset) {
    /** 通过企业app应用获取企业信息 */
    const resData: any = await authUserTokenByUnionid(thirdUnionId)
    logger.info({
      msg: '获取access_token接口返回结果',
      data: resData
    })
    resCheck(resData)
    // eslint-disable-next-line camelcase
    const { expires_in, access_token } = resData.token
    // eslint-disable-next-line camelcase
    const timestamp = new Date().getTime() + expires_in
    const value = { value: access_token, expire: timestamp }
    const setCompanyToken = await sdkInstance.middleware.cache.set(
      'access_token',
      JSON.stringify(value)
    )
    sdkCheck(setCompanyToken)
    // eslint-disable-next-line camelcase
    tempToken = access_token
  } else {
    tempToken = JSON.parse(tempToken.data.data).value
  }
  logger.info({
    msg: '获取access_token返回结果',
    data: tempToken
  })
  return tempToken
}

/**
 * @name get
 * @returns {string}  获取第三方token, 有效期30秒
 */
export async function getThirdToken(): Promise<string> {
  const resData = await companyToken()
  return `${resData}`
}
