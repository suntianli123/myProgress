import { Context } from 'koa'
import config from '../../config'
import { resJson, resErrJson } from '../../util/msgCode'
import axios from 'axios'
import { logger } from '../../ins'
import { batchSelectDB, encryptUserId, getAccessTokenByUserId } from '../groupAuth/func'
import { createPermissions, getGroupPermissions, setGroupPermissions } from '../../model/openApi/teamPermissions'

/**
 * @path     /app/{appid}/api/v1/notification
 * @param   {object} Context
 * @returns {object}
 */
export async function notificationA(ctx: Context) {
  logger.info({ message: '/c/aknodejszzwj/api/v1/notification' })
  let res
  let msg: any
  const body = ctx.request.body
  logger.info({ message: `notificationA:`, ctx })
  logger.info({ message: `notificationA-query`, query: ctx.query })
  logger.info({ message: `notificationA-query`, params: ctx.params })
  logger.info({ message: `notificationA-body:`, body })
  try {
    const { buss_type, data = {} } = body
    // const {group_id,fileid} = data
    if (buss_type == 'wps.file') {
      // 上传和创建文档消息通过
      let groupId = data.group_id
      // 加密后的团队id  不确定是否为加密后的团队id
      // groupId = await encryptUserId(groupId)

      // 查询中间表中是否有当前团队id
      const groupInfoList = await batchSelectDB(groupId)
      logger.info({
        msg: '消息中心中通过团队id查询中间表的数据为:',
        groupInfoList,
        groupId
      })
      if (!groupInfoList || !Array.isArray(groupInfoList) || !groupInfoList.length) {
        logger.info({
          msg: '中间表没有存储该团队信息'
        })

      } else {
        // 获取当前团队创建人的开放平台id
        const userId = groupInfoList[0].user_id.split(',')[0]

        logger.info({
          msg: '通过团队创建着的用户id获取accessToken',
          userId
        })
        // 通过三方用户id获取accessToken
        const accessToken = await getAccessTokenByUserId(userId)

        // 判断如果当前团队的人员不是同一单位，则无需处理，直接返回结束程序
        if (groupInfoList && groupInfoList.length && groupInfoList[0].is_fit == '1') {
          logger.info({
            msg: '该团队不是同单位下创建'
          })

          // 获取当前团队所有的权限列表
          const groupPermission: any = await getGroupPermissions(groupId, accessToken)
          logger.info({
            msg: '获取到当前团队所有的权限列表',
            groupPermission,
            groupId
          })
          const groupPermissionList = groupPermission.data.compound_perms.filter((item: any) => item.name == '不同单位下创建')
          logger.info({
            msg: '当前团队是否有“不同单位下创建”权限',
            groupPermissionList
          })
          if (groupPermissionList && groupPermissionList.length == 0) {
            // 没有不同单位下创建权限

            const compound_perms = {
              "compound_perms": [             //权限组合详情数组
                {
                  "name": "不同单位下创建",       //自定义权限组合名称，不能包含特殊字符，不能使用预设名称：View Only、Viewable、Editable
                  "permissions": [        //具体权限数组
                    "view",
                    "new_empty",
                    "upload",
                    "update",
                    "history",
                    "rename"            //枚举类型："view" "new_empty" "upload" "delete" "move" "download" "share" "copy" "update" "rename" "saveas" "history" "secret" "comment"
                  ]
                }
              ]
            }
            const createResult = await createPermissions(groupId, accessToken, compound_perms)
            logger.info({
              msg: '创建权限结果',
              createResult
            })

            if (createResult.result == 0) {
              throw new Error("创建权限失败");
            }
          }

          // 给当前文件设置权限
          const compoundObj = {              //权限组合id, compound_id或compound_name两者必传一个, 否则报错
            "compound_name": "不同单位创建",          //权限组合类型，枚举：preset（预设）/custom（自定义）
            "subfiles_update": true,            //是否更新子文件相应的授权记录
            "subjects": [                       //需要设置权限的对象
              {
                "subject_type": "role",     //枚举类型：user、role、dept、userGroup
                "subject_id": '2'     //根据subject_type的类型来决定
                //如果subject_type=user，subject_id就是company_uid
                //如果subject_type=userGroup，subject_id就是用户组（标签组）id
                //如果subject_type=role，subject_id就是role_id（角色id）
                //如果subject_type=dept，subject_id就是dept_id（部门id）
              }
            ]
          }
          const setResult = await setGroupPermissions(groupId, accessToken, data.fileid, compoundObj)
          logger.info({
            msg: '设置权限结果',
            setResult
          })
        } else {
          logger.info({
            msg: '该团队是同单位下创建的'
          })

          
        }
      }

      res = resJson()
    }


  } catch (e) {
    res = resErrJson(e)
    logger.error(`通知推送异常!Error【${e}】消息内容【${msg}】`)
  }
  ctx.status = 200
  ctx.body = res
  return ctx
}