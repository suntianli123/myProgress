import * as dotenv from 'dotenv'
dotenv.config()

interface Config {
  port: number
  appid: string
  appkey: string

  baseUrl: {
    driveBaseUrl: string
    openBaseUrl: string
  }

  compId: string

  domain: string
  scope: string
  appID: string
  appKey: string

  dbName: string

  grpc: {
    addr: string
  }
  ecisHost: string
}

const config: Config = {
  port: process.env.HTTP_KPORT ? parseInt(process.env.HTTP_KPORT) : 8000,
  appid: process.env.AK,
  appkey: process.env.SK,

  baseUrl: {
    driveBaseUrl: 'http://mics-urlrouter',
    openBaseUrl: 'http://yunkit-opengateway'
  },

  // zzwj环境
  // domain: 'http://109.201.0.189',
  // 开放平台部署节点
  domain: process.env.domain || "http://109.202.104.5",
  appID: process.env.appID || 'AK20230420OPUHLV',
  appKey: process.env.appKey || 'f61b07ec6ea471aed72ba45259f6167c',
  compId: process.env.compId || '611668693',

  scope: 'corp_contacts_mgr,corp_files_synerg_mgr,corp_normal_group_all',
 
  // 数据库
  // dbName: `ecis_plugins_ak20230406zzwj`,
  dbName: `ecis_plugins_ak20230306zzwj`,

  grpc: {
    addr: process.env.GRPC_ADDR ? process.env.GRPC_ADDR : 'encs-pri-ecis:50051'
  },
  ecisHost: process.env.ECIS_HOST
}

export default config
