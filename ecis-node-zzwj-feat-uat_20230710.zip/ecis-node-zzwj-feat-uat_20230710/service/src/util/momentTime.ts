const moment = require('moment')

export function currentTime() {
  return moment().format('YYYY-MM-DD HH:mm:ss') // 当前时间格式
}



/**
 * // 处理数组排序
 * @param objs 需要排序的数据源
 * @param order 排序的规则
 * @param type 按照type字段排序
 */
export function ArraySort(objs: any, order: any, type:any) {
  // var objs = [
  //   {'name': 'A', 'type': 'fly'},
  //   {'name': 'B', 'type': 'blur'},
  //   {'name': 'C', 'type': 'wipe'},
  //   {'name': 'D', 'type': 'cube'},
  //   {'name': 'E', 'type': 'iris'},
  //   {'name': 'F', 'type': 'fade'}
  // ];

  return objs.sort(function (a: any, b: any) {
    // order是规则bai  objs是需要排序的数du组
    // var order = ["wipe", "fly", "iris", "flip", "cube",
    //   "blur", "zoom", "fade", "glow", "rotate"];
    return order.indexOf(a[type]) - order.indexOf(b[type]);
  });
}