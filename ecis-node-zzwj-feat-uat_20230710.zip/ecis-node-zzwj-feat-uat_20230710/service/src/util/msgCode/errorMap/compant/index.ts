/*
 * @Author: lz-ui@jczxw.cn
 * @Date: 2022-04-21 15:21:05
 * @LastEditors: lz-ui
 * @LastEditTime: 2022-04-21 15:42:27
 * @Description: file content
 */
export default {
  ERR_COMPANT_TOKEN: { code: 10000001, msg: '获取企业tonken失败' },
  ERR_COMPANT_INFO: { code: 10000001, msg: '获取企业信息失败' },
  ERR_COMPANT_DEPTS: { code: 10000002, msg: '获取企业部门列表' }
}
