/*
 * @Author: lz-ui@jczxw.cn
 * @Date: 2022-04-21 15:20:05
 * @LastEditors: lz-ui
 * @LastEditTime: 2022-04-21 15:44:45
 * @Description: file content
 */

/** 企业通讯录 */
import compant from './compant'

/** 根据自己业务模块，自定义业务错误code */
const errorMapCode: { [x: string]: any } = {
  ...compant
}

export default errorMapCode
