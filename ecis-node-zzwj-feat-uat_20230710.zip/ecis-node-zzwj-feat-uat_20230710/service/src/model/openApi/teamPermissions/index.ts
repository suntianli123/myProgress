import request from '../../../util/request'
import config from '../../../config'
import { API } from './typings'

/**
 * @name 1.新建权限组合
 * @param {string} companyToken通过company_token创建部门
 * @param {Object} data
 * @returns {Promise}
 */
export const createPermissions = (
  group_id: string,
  accessToken: string,
  compound_perms:any
): Promise<API.ResponseApi> => {
  // @ts-ignore
  return request({
    url: `/open/kopen/plus/v1/corpgroups/${group_id}/compound/permissions?access_token=${accessToken}`,
    method: 'post',
    data: compound_perms,
  })
}

/**
 * @name 2.获取权限组合
 * @param {string} accessToken
 * @param {Object} group_id
 * @returns {Promise}
 */
export const getGroupPermissions = (
  group_id: string,
  accessToken: string,
): Promise<API.ResponseApi> => {
  // @ts-ignore
  return request({
    url: `/open/kopen/plus/v1/corpgroups/${group_id}/compound/permissions?access_token=${accessToken}`,
    method: 'get',
  })
}

/**
 * @name 6.设置权限
 * @param {string} companyToken通过company_token创建部门
 * @param {Object} data
 * @returns {Promise}
 */
export const setGroupPermissions = (
  accessToken: string,
  group_id: string,
  file_id: string,
  compoundObj:any
): Promise<API.ResponseApi> => {
  // @ts-ignore
  return request({
    url: `/open/kopen/plus/v1/corpgroups/${group_id}/files/${file_id}/permissions?access_token=${accessToken}`,
    method: 'put',
    data: compoundObj,
  })
}

/**
 * @name 8.获取权限角色信息
 * @param {string} companyToken通过company_token创建部门
 * @param {Object} data
 * @returns {Promise}
 */
export const getPremissionsRoleMsg = (
  accessToken: string,
  group_id: string,
): Promise<API.ResponseApi> => {
  // @ts-ignore
  return request({
    url: `/open/kopen/plus/v1/corpgroups/${group_id}/permission/roles?access_token=${accessToken}`,
    method: 'get',
  })
}