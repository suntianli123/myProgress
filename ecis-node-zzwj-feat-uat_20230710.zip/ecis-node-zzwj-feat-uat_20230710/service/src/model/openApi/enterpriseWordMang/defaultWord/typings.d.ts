export namespace API {
  /** 公共返回值 */
  interface ResponseApi {
    result: number
    msg?: string
  }

  /** wps-企业Token /company/inner/token */
  interface ResponseGroupMembers extends ResponseApi {
    token?: {
      expires_in: number
      company_token: string
    }
  }
}
