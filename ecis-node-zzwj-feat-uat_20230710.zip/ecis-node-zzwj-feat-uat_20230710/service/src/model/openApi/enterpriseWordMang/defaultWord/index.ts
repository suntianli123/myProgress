import request from '../../../../util/request'
import config from '../../../../config'
import { API } from './typings'

/**
 * @name 2.获取团队列表
 * @param {string} companyToken通过company_token创建部门
 * @param {Object} data
 * @returns {Promise}
 */
export const getGroupList = (
  companyToken: string,
  accessToken: string,
  offset=0,
  count=99,
): Promise<API.ResponseApi> => {
  // @ts-ignore
  return request({
    url: `/open/drive/v1/corpgroups?access_token=${accessToken}&company_token=${companyToken}&offset=${offset}&count=${count}`,
    method: 'get'
  })
}

/**
 * @name 5.获取团队成员列表
 * @param {string} companyToken通过company_token创建部门
 * @param {Object} data
 * @returns {Promise}
 */
export const getGroupUserList = (
  companyToken: string,
  accessToken: string,
  groupId: string,
): Promise<API.ResponseApi> => {
  // @ts-ignore
  return request({
    url: `/open/drive/v1/corpgroups/${groupId}/members?company_token=${companyToken}&access_token=${accessToken}`,
    method: 'get',
  })
}

/**
 * @name 6.添加团队成员
 * @param {string} companyToken通过company_token创建部门
 * @param {Object} data
 * @returns {Promise}
 */
export const addpersonJoInGroups = (
  companyToken: string,
  accessToken: string,
  groupId: string,
  companyUids: string
): Promise<API.ResponseApi> => {
  // @ts-ignore
  return request({
    url: `/open/drive/v1/corpgroups/${groupId}/members?company_token=${companyToken}&access_token=${accessToken}`,
    method: 'post',
    data: {
      company_uids: companyUids
    }
  })
}

/**
 * @name 7.删除团队成员
 * @param {string} companyToken通过company_token创建部门
 * @param {Object} data
 * @returns {Promise}
 */
export const delGroupUsers = (
  companyToken: string,
  accessToken: string,
  groupId: string,
  companyUids: string
): Promise<API.ResponseApi> => {
  // @ts-ignore
  return request({
    url: `/open/drive/v1/corpgroups/${groupId}/members/${companyUids}?company_token=${companyToken}&access_token=${accessToken}`,
    method: 'delete',
  })
}

/**
 * @name 11.获取我的企业文档信息
 * @param {string} companyToken通过company_token创建部门
 * @param {Object} data
 * @returns {Promise}
 */
export const getGroupsPrivate = (
  companyToken: string,
  company_uid: string,
): Promise<API.ResponseApi> => {
  // @ts-ignore
  return request({
    url: `/open/kopen/plus/v1/dev/companies/users/${company_uid}/groups/private?company_token=${companyToken}`,
    method: 'get',
  })
}