import request from '../../../util/request'
import config from '../../../config'
import { API } from './typings'

/**
 * @name 2.获取标签组
 * @param {string} companyToken通过company_token创建部门
 * @param {Object} data
 * @returns {Promise}
 */
export const createPermissions = (
  group_id: string,
  accessToken: string,
  compound_perms:any
): Promise<API.ResponseApi> => {
  // @ts-ignore
  return request({
    url: `/open/kopen/plus/v1/corpgroups/${group_id}/compound/permissions?access_token=${accessToken}`,
    method: 'post',
    data: compound_perms,
  })
}

