/* eslint-disable camelcase */

/**
 * 密标文档协同管理相关接口
 **/

export namespace API {
  /** 公共返回值 */
  interface ResponseApi {
    result: number
    msg?: string
  }

  /** 新增定密依据  /secure/v1/mb-admin/accord/new  data参数 */
  interface RequestAccordNew {
    parentId: number
    value: string
    accordClass: number
  }

  /** 新增定密依据  /secure/v1/mb-admin/accord/new */
  interface ResponseAccordNew extends ResponseApi {
    data: {
      id: number
    }
  }

  /** 修改定密依据  /secure/v1/mb-admin/accord/edit  data参数 */
  interface RequestAccordEdit {
    parentId: number
    value: string
    id: number
    sort: number
    status: number
    accordClass: number
  }

  /** 导入定密依据  /secure/v1/mb-admin/accord/import */
  interface ResponseAccordImport extends ResponseApi {
    data: {
      validate_failed_data: [
        {
          path: string
          row: number
          err: string
          name: string
        }
      ]
      duplicate_rows: number[]
      success_data: [
        {
          path: string
          row: number
          name: string
        }
      ]
    }
  }

  /** 获取指定目录下的定密依据  /secure/v1/mb-admin/accord-catalog/dir */
  // status 枚举: 0,1 枚举备注: 0-正常，1-禁用
  interface ResponseAccordCatalogDir extends ResponseApi {
    data: {
      total: number
      list: [
        {
          id: number
          value: string
          accord_class: number
          accord_class_name: string
          status: number
          sort: number
        }
      ]
    }
  }

  /** 获取指定目录的定密依据目录  /secure/v1/mb-admin/accord-catalog/subdir */
  interface ResponseAccordCatalogSubdir extends ResponseApi {
    data: {
      list: [
        {
          id: number
          parent_id: number
          sort: number
          value: string
        }
      ]
    }
  }

  /** 新增定密依据目录  /secure/v1/mb-admin/accord-catalog/new  data请求参数 */
  interface RequestAccordCatalogNew {
    parent_id: number
    value: string
  }

  /** 新增定密依据目录  /secure/v1/mb-admin/accord-catalog/new */
  interface ResponseAccordCatalogNew extends ResponseApi {
    data: {
      id: number
    }
  }

  /** 修改定密依据目录  /secure/v1/mb-admin/accord-catalog/edit  data请求参数 */
  interface RequestAccordCatalogEdit {
    parent_id: number // 目录id，根目录为-1
    value: string //
    id: number
    sort: number
  }

  /** 修改定密依据目录  /secure/v1/mb-admin/accord-catalog/edit */
  interface ResponseAccordCatalogEdit extends ResponseApi {
    data: {
      id: number
    }
  }

  /** 修改定密依据目录  /secure/v1/mb-admin/accord-catalog/edit */
  interface ResponseAccordCatalogEdit extends ResponseApi {
    data: {
      id: number
    }
  }

  /** 获取人员密级列表  /secure/v1/mb-admin/member-class/list */
  interface ResponseMemberClassList extends ResponseApi {
    data: {
      total: number
      list: [
        {
          id: number
          company_uid: string
          nick_name: string
          account: string
          dept: string
          mb_class_name: string
          mb_class: number
        }
      ]
    }
  }

  /** 添加人员密级  /secure/v1/mb-admin/member-class/add data请求参数 */
  interface RequestMemnerClassAdd {
    mb_class: number // 密级值
    company_uids: string // 用户ID数组;多个用逗号分开
  }

  /** 编辑人员密级  /secure/v1/mb-admin/member-class/edit data请求参数 */
  interface RequestMemnerClassEdit {
    mb_class: number // 密级值
    id: string // 密级ID标识
  }

  /** 获取人员密级列表  /secure/v1/mb-admin/role/list */
  interface ResponseRoleList extends ResponseApi {
    data: {
      total: number
      list: [
        {
          id: number
          company_uid: string
          nick_name: string
          account: string
          dept: string
          scopes: [
            {
              id: string
              name: string
            }
          ]
        }
      ]
    }
  }

  /** 在角色列表中新增人员  /secure/v1/mb-admin/role/add data请求参数 */
  interface RequestRoleAdd {
    scopes: string // 权限范围部门ID数组;多个用逗号分开
    company_uid: string // 用户ID
    role_type: number // 角色类型，文档起草人：0，定密责任人：1，文档签发人：2
  }

  /** 编辑人员角色  /secure/v1/mb-admin/role/edit data请求参数 */
  interface RequestRoleEdit {
    scopes: string // 权限范围部门ID数组;多个用逗号分开
    id: string
  }

  /** 转让人员角色  /secure/v1/mb-admin/role/transfer data请求参数 */
  interface RequestRoleTransfer {
    target_company_uid: string // 角色承接人的企业用户ID
    id: string
  }

  /** 新增密级标识  /secure/v1/mb-admin/class/add */
  interface RequestClassAdd {
    name: string
    identifier: string
    pos: number
    level: number
  }

  /** 编辑密级标识  /secure/v1/mb-admin/class/edit */
  interface RequestClassEdit {
    id: number // 密级标识ID
    name: string // 密级标识名称
    identifier: string // 密级标识符号
    icon: string // 密级标识图标(base64 dataurl)
    level: number // 密级标识值
  }

  /** 新增保密类型  /secure/v1/mb-admin/encryption/add */
  interface RequestEncryptionAdd {
    name: string // 保密类型名称
    control_type: string // 控件类型
    control_value: string // 控件属性内容
    levels: string // 密级集合;多个用逗号分开
  }

  /** 编辑保密类型  /secure/v1/mb-admin/encryption/edit */
  interface RequestEncryptionEdit {
    id: string // 保密类型ID
    name: string // 保密类型名称
    control_type: string // 控件类型
    control_value: string // 控件属性内容，仅下拉框的时候才有用。格式：X-Y，X代表数字，Y：0-日，1-月，2-年； 比如说12-0，那就是12日，12-1，那就是12个月，5-2，那就是5年
    levels: string // 密级集合;多个用逗号分开
  }

  /** 修改指定策略  /secure/v1/mb-admin/settings/edit */
  interface RequestSettingsEdit {
    value: string // 策略值
    name: string // 策略名称
  }

  /** 获取密标文档列表  /secure/v1/mb-admin/file/list */
  interface ResponseFileList extends ResponseApi {
    data: {
      total: number
      list: [
        {
          mb_status: number
          class_name: string
          document_id: number
          encryption_name: string
          encryption_value: string
          id: number
          document_name: string
        }
      ]
    }
  }
}
