/** 密标-管理员API */

import request from '../../../../util/request'
import config from '../../../../config'
import { API } from './typings'

/**
 * 一.定密依据
 * @name 1.1 新增定密依据
 * @param {string} companyToken
 * @param {string} access_token
 * @param {number} parentId   目录id
 * @param {string} value 依据内容
 * @param {number} accordClass 依据的密级
 *  @returns {Promise}
 */
export function getAccordNew(
  accessToken: string,
  companyToken: string,
  data: API.RequestAccordNew
): Promise<API.ResponseAccordNew> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/accord/new?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data
  })
}

/**
 * 一.定密依据
 * @name 1.2 修改定密依据
 * @param {string} companyToken
 * @param {string} access_token
 * @param {number} parentId   目录id
 * @param {string} value 依据内容
 * @param {number} id 依据唯一id
 * @param {number} sort 依据在数据库的排序值，可以是不连续的，但必须为大于0
 * @param {number} status 依据状态
 * @param {number} accordClass 依据的密级
 *  @returns {Promise}
 */
export function getAccordEdit(
  accessToken: string,
  companyToken: string,
  data: API.RequestAccordEdit
): Promise<API.ResponseApi> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/accord/edit?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data
  })
}

/**
 * 一.定密依据
 * @name 1.2 删除定密依据
 * @param {string} companyToken
 * @param {string} access_token
 * @param {string} ids 依据唯一id组成的数组，逗号分开
 *  @returns {Promise}
 */
export function getAccordDelete(
  accessToken: string,
  companyToken: string,
  ids: string
): Promise<API.ResponseApi> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/accord/delete?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data: {
      ids
    }
  })
}

/**
 * 一.定密依据
 * @name 1.2 导入定密依据
 * @param {string} companyToken
 * @param {string} access_token
 * @param {string} input_csv csv字节流；最大20M
 *  @returns {Promise}
 */
export function getAccordImport(
  accessToken: string,
  companyToken: string,
  inputCsv: string
): Promise<API.ResponseAccordImport> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/accord/import?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data: {
      input_csv: inputCsv
    }
  })
}

/**
 * 一.定密依据
 * @name 1.2 获取指定目录下的定密依据
 * @param {string} companyToken
 * @param {string} accessToken
 * @param {number} parentId
 * @param {number} offset
 * @param {number} limit
 *  @returns {Promise}
 */
export function getAccordCatalogDir(
  accessToken: string,
  companyToken: string,
  parentId: string,
  offset: string,
  limit: string
): Promise<API.ResponseAccordCatalogDir> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/accord-catalog/dir?access_token=${accessToken}&company_token=${companyToken}&parent_id=${parentId}&offset=${offset}&limit=${limit}`,
    method: 'get'
  })
}

/**
 * 一.定密依据
 * @name 1.2 获取指定目录的定密依据目录
 * @param {string} companyToken
 * @param {string} accessToken
 * @param {number} parentId
 *  @returns {Promise}
 */
export function getAccordCatalogSubdir(
  accessToken: string,
  companyToken: string,
  parentId: string
): Promise<API.ResponseAccordCatalogSubdir> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/accord-catalog/subdir?access_token=${accessToken}&company_token=${companyToken}&parent_id=${parentId}`,
    method: 'get'
  })
}

/**
 * 一.定密依据
 * @name 1.2 新增定密依据目录
 * @param {string} companyToken
 * @param {string} accessToken
 * @param {number} parentId
 *  @returns {Promise}
 */
export function getAccordCatalogNew(
  accessToken: string,
  companyToken: string,
  data: API.RequestAccordCatalogNew
): Promise<API.ResponseAccordCatalogNew> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/accord-catalog/new?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data
  })
}

/**
 * 一.定密依据
 * @name 1.2 修改定密依据目录
 * @param {string} companyToken
 * @param {string} accessToken
 * @param {number} parentId
 *  @returns {Promise}
 */
export function getAccordCatalogEdit(
  accessToken: string,
  companyToken: string,
  data: API.RequestAccordCatalogEdit
): Promise<API.ResponseAccordCatalogEdit> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/accord-catalog/edit?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data
  })
}

/**
 * 一.定密依据
 * @name 1.2 删除定密依据目录
 * @param {string} companyToken
 * @param {string} accessToken
 * @param {number} parentId
 *  @returns {Promise}
 */
export function getAccordCatalogDelete(
  accessToken: string,
  companyToken: string,
  ids: string // 依据唯一id组成的数组
): Promise<API.ResponseApi> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/accord-catalog/delete?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data: {
      ids
    }
  })
}

/**
 * 一.定密依据
 * @name 1.2 获取人员密级列表
 * @param {string} companyToken
 * @param {string} accessToken
 * @param {string} kw // 用户昵称搜索关键字
 * @param {number} offset
 * @param {number} limit
 *  @returns {Promise}
 */
export function getMemberClassList(
  accessToken: string,
  companyToken: string,
  kw: string,
  offset: number,
  limit: number
): Promise<API.ResponseMemberClassList> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/member-class/list?access_token=${accessToken}&company_token=${companyToken}&kw=${kw}&offset=${offset}&limit=${limit}`,
    method: 'get'
  })
}

/**
 * 一.定密依据
 * @name 1.2 添加人员密级
 * @param {string} companyToken
 * @param {string} accessToken
 * @param {string} company_uids
 * @param {number} mb_class
 *  @returns {Promise}
 */
export function getMemberClassAdd(
  accessToken: string,
  companyToken: string,
  data: API.RequestMemnerClassAdd
): Promise<API.ResponseApi> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/member-class/add?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data
  })
}

/**
 * 一.定密依据
 * @name 1.2 编辑人员密级
 * @param {string} companyToken
 * @param {string} accessToken
 * @param {number} mb_class
 * @param {number} id
 *  @returns {Promise}
 */
export function getMemberClassEdit(
  accessToken: string,
  companyToken: string,
  data: API.RequestMemnerClassEdit
): Promise<API.ResponseApi> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/member-class/edit?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data
  })
}

/**
 * 一.定密依据
 * @name 1.2 删除人员密级
 * @param {string} companyToken
 * @param {string} accessToken
 * @param {string} ids //删除的密级id集合;多个用逗号分开
 *  @returns {Promise}
 */
export function getMemberClassDelete(
  accessToken: string,
  companyToken: string,
  ids: string
): Promise<API.ResponseApi> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/member-class/delete?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data: {
      ids
    }
  })
}

/**
 * 一.定密依据
 * @name 1.2 获取指定角色下的成员列表
 * @param {string} companyToken
 * @param {string} accessToken
 * @param {string} type // 角色类型，文档起草人：0，定密责任人：1，文档签发人：2
 * @param {number} offset
 * @param {number} limit
 * @returns {Promise}
 */
export function getRoleList(
  accessToken: string,
  companyToken: string,
  type: string,
  offset: number,
  limit: number
): Promise<API.ResponseRoleList> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/role/list?access_token=${accessToken}&company_token=${companyToken}&type=${type}&offset=${offset}&limit=${limit}`,
    method: 'get'
  })
}

/**
 * 一.定密依据
 * @name 1.2 在角色列表中新增人员
 * @param {string} companyToken
 * @param {string} accessToken
 * @param {string} type // 角色类型，文档起草人：0，定密责任人：1，文档签发人：2
 * @param {number} offset
 * @param {number} limit
 * @returns {Promise}
 */
export function getRoleAdd(
  accessToken: string,
  companyToken: string,
  type: string,
  offset: number,
  limit: number
): Promise<API.ResponseApi> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/role/add?access_token=${accessToken}&company_token=${companyToken}&type=${type}&offset=${offset}&limit=${limit}`,
    method: 'get'
  })
}

/**
 * 一.定密依据
 * @name 1.2 编辑人员角色
 * @param {string} companyToken
 * @param {string} accessToken
 * @returns {Promise}
 */
export function getRoleEdit(
  accessToken: string,
  companyToken: string,
  data: API.RequestRoleEdit
): Promise<API.ResponseApi> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/role/edit?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data
  })
}

/**
 * 一.定密依据
 * @name 1.2 删除人员角色
 * @param {string} companyToken
 * @param {string} accessToken
 * @returns {Promise}
 */
export function getRoleDelete(
  accessToken: string,
  companyToken: string,
  ids: string
): Promise<API.ResponseApi> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/role/delete?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data: { ids }
  })
}

/**
 * 一.定密依据
 * @name 1.2 转让人员角色
 * @param {string} companyToken
 * @param {string} accessToken
 * @returns {Promise}
 */
export function getRoleTransfer(
  accessToken: string,
  companyToken: string,
  data: API.RequestRoleTransfer
): Promise<API.ResponseApi> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/role/transfer?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data
  })
}

/**
 * 一.定密依据
 * @name 1.2 新增密级标识
 * @param {string} companyToken
 * @param {string} accessToken
 * @returns {Promise}
 */
export function getClassAdd(
  accessToken: string,
  companyToken: string,
  data: API.RequestClassAdd
): Promise<API.ResponseApi> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/class/add?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data
  })
}

/**
 * 一.定密依据
 * @name 1.2 编辑密级标识
 * @param {string} companyToken
 * @param {string} accessToken
 * @returns {Promise}
 */
export function getClassEdit(
  accessToken: string,
  companyToken: string,
  data: API.RequestClassEdit
): Promise<API.ResponseApi> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/class/add?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data
  })
}

/**
 * 一.定密依据
 * @name 1.2 编辑密级标识
 * @param {string} companyToken
 * @param {string} accessToken
 * @returns {Promise}
 */
export function getClassDelete(
  accessToken: string,
  companyToken: string,
  ids: string // 删除的密级id集合;多个用逗号分开
): Promise<API.ResponseApi> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/class/delete?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data: { ids }
  })
}

/**
 * 一.定密依据
 * @name 1.2 新增保密类型
 * @param {string} companyToken
 * @param {string} accessToken
 * @returns {Promise}
 */
export function getEncryptionAdd(
  accessToken: string,
  companyToken: string,
  data: API.RequestEncryptionAdd
): Promise<API.ResponseApi> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/encryption/add?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data
  })
}

/**
 * 一.定密依据
 * @name 1.2 编辑保密类型
 * @param {string} companyToken
 * @param {string} accessToken
 * @returns {Promise}
 */
export function getEncryptionEdit(
  accessToken: string,
  companyToken: string,
  data: API.RequestEncryptionEdit
): Promise<API.ResponseApi> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/encryption/edit?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data
  })
}

/**
 * 一.定密依据
 * @name 1.2 删除保密类型
 * @param {string} companyToken
 * @param {string} accessToken
 * @returns {Promise}
 */
export function getEncryptionDelete(
  accessToken: string,
  companyToken: string,
  ids: string
): Promise<API.ResponseApi> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/encryption/delete?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data: { ids }
  })
}

/**
 * 一.定密依据
 * @name 1.2 修改指定策略
 * @param {string} companyToken
 * @param {string} accessToken
 * @returns {Promise}
 */
export function getSettingsEdit(
  accessToken: string,
  companyToken: string,
  data: API.RequestSettingsEdit
): Promise<API.ResponseApi> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/settings/edit?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'post',
    data
  })
}

/**
 * 一.定密依据
 * @name 1.2 获取密标文档列表
 * @param {string} companyToken
 * @param {string} accessToken
 * @param {string} filename
 * @param {string} classLevel
 * @param {string} encryptionId
 * @param {string} mbStatus
 * @param {string} offset
 * @param {string} limit
 * @returns {Promise}
 */
export function getFileList(
  accessToken: string,
  companyToken: string,
  filename: string,
  classLevel: number,
  encryptionId: number,
  mbStatus: number,
  offset: number,
  limit: number
): Promise<API.ResponseFileList> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/file/list?access_token=${accessToken}&company_token=${companyToken}&filename=${filename}&class_level=${classLevel}&encryption_id=${encryptionId}&mb_status=${mbStatus}&offset=${offset}&limit=${limit}`,
    method: 'get'
  })
}

/**
 * 一.定密依据
 * @name 1.2 获取密标文档列表
 * @param {string} companyToken
 * @param {string} accessToken
 * @param {string} filename
 * @param {string} classLevel
 * @param {string} encryptionId
 * @param {string} offset
 * @param {string} limit
 * @returns {Promise}
 */
export function getFileLog(
  accessToken: string,
  companyToken: string,
  filename: string,
  classLevel: string,
  encryptionId: string,
  offset: string,
  limit: string
): Promise<API.ResponseFileList> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb-admin/file/log?access_token=${accessToken}&company_token=${companyToken}&company_token=${filename}&company_token=${classLevel}&company_token=${encryptionId}&company_token=${offset}&company_token=${limit}`,
    method: 'get'
  })
}
