/** 密标-用户API */

import request from '../../../../util/request'
import config from '../../../../config'
import { API } from './typings'

/**
 * 一.定密依据
 * @name 1.1 获取指定目录下的定密依据和子目录
 * @param {string} companyToken
 * @param {string} access_token
 * @param {number} parentId   目录id；-1 则返回根目录下的内容；默认-1
 * @param {number} offset
 * @param {number} limit
 *  @returns {Promise}
 */
export function getAccordAndDir(
  accessToken: string,
  companyToken: string,
  parentId: number,
  offset: number,
  limit: number
): Promise<API.ResponseAccordAndDir> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb/accord/dir?access_token=${accessToken}&company_token=${companyToken}&parent_id=${parentId}&offset=${offset}&limit=${limit}`,
    method: 'get'
  })
}

/**
 * 一.定密依据
 * @name 1.2 批量获取指定ID的定密依据信息
 * @param {string} companyToken
 * @param {string} ids 多个依据id，用逗号分隔
 *  @returns {Promise}
 */
export function getAccordAndBatch(
  companyToken: string,
  ids: string
): Promise<API.ResponseAccordAndDir> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb/accord/batch?company_token=${companyToken}&ids=${ids}`,
    method: 'get'
  })
}

/**
 * 一.定密依据
 * @name 1.3 搜索定密依据
 * @param {string} accessToken
 * @param {string} companyToken
 * @param {number} offset
 * @param {number} limit
 * @param {string} keyword 搜索关键字
 * @param {number} status  状态0-正常，1-禁用，不带为全部
 *  @returns {Promise}
 */
export function getAccordSearch(
  accessToken: string,
  companyToken: string,
  offset: number,
  limit: number,
  keyword: string,
  status: number
): Promise<API.ResponseAccordSearch> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb/accord/search?access_token=${accessToken}&company_token=${companyToken}&offset=${offset}&limit=${limit}&keyword=${keyword}&status=${status}`,
    method: 'get'
  })
}

/**
 * 一.定密依据
 * @name 1.4 搜索定密依据目录
 * @param {string} accessToken
 * @param {string} companyToken
 * @param {number} offset
 * @param {number} limit
 * @param {string} keyword 搜索关键字
 *  @returns {Promise}
 */
export function getAccordcatalogSearch(
  accessToken: string,
  companyToken: string,
  offset: number,
  limit: number,
  keyword: string
): Promise<API.ResponseAccordcatalogSearch> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb/accord-catalog/search?access_token=${accessToken}&company_token=${companyToken}&offset=${offset}&limit=${limit}&keyword=${keyword}`,
    method: 'get'
  })
}

/**
 * 二.人员密级
 * @name 1.1 获取当前用户的密级
 * @param {string} accessToken
 * @param {string} companyToken
 *  @returns {Promise}
 */
export function getSememberClassMe(
  accessToken: string,
  companyToken: string
): Promise<API.ResponSememberClassMe> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb/member-class/me?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'get'
  })
}

/**
 * 三.人员角色
 * @name 1.1 获取当前用户的人员角色
 * @param {string} accessToken
 * @param {string} companyToken
 * @param {string} mbinfoguids 密标信息GUID，多个用逗号分隔，留空为全局角色
 * 角色类型备注：
 * 枚举: 0,1,2,3
 * 枚举备注: 文档起草人 定密责任人 文档签发人 密标管理员
 *  @returns {Promise}
 */
export function getRoleMe(
  accessToken: string,
  companyToken: string,
  mbinfoguids: string
): Promise<API.ResponRoleMe> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb/role/me?access_token=${accessToken}&company_token=${companyToken}&mbinfoguids=${mbinfoguids}`,
    method: 'get'
  })
}

/**
 * 三.人员角色
 * @name 1.2 获取权限范围覆盖当前用户的角色人员列表
 * @param {string} accessToken
 * @param {string} companyToken
 * @param {string} role_type 角色类型：1-定密责任人，2-文档签发人
 *  @returns {Promise}
 */
export function getRoleCover(
  accessToken: string,
  companyToken: string,
  roleType: string
): Promise<API.ResponRoleCover> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb/role/cover?access_token=${accessToken}&company_token=${companyToken}&role_type=${roleType}`,
    method: 'get'
  })
}

/**
 * 四、密级标识
 * @name 1.1 获取密级标识列表
 * @param {string} companyToken
 * @param {number} offset
 * @param {number} limit
 *  @returns {Promise}
 */
export function getClassList(
  companyToken: string,
  offset: number,
  limit: number
): Promise<API.ResponClassList> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb/class/list?company_token=${companyToken}&offset=${offset}&limit=${limit}`,
    method: 'get'
  })
}

/**
 * 五、保密类型
 * @name 1.1 获取保密类型列表
 * @param {string} companyToken
 * @param {number} offset
 * @param {number} limit
 * control_type 备注信息：
 * 枚举: 1,2,6
 * 枚举备注: 输入框 日期框 下拉框
 *  @returns {Promise}
 */
export function getEncryptionList(
  companyToken: string,
  offset: number,
  limit: number
): Promise<API.ResponEncryptionList> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb/encryption/list?company_token=${companyToken}&offset=${offset}&limit=${limit}`,
    method: 'get'
  })
}

/**
 * 六、策略
 * @name 1.1 获取策略列表
 *  @returns {Promise}
 */
export function getSettingsList(): Promise<API.ResponSettingsList> {
  // @ts-ignore
  return request({
    url: '/open/secure/v1/mb/settings/lis',
    method: 'get'
  })
}

/**
 * 六、策略
 * @name 1.2 获取指定策略
 * @param {string} accessToken
 * @param {string} companyToken
 * @param {string} name	策略名称
 *  @returns {Promise}
 */
export function getSettingsGet(
  accessToken: string,
  companyToken: string,
  name: string
): Promise<API.ResponSettingsGet> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb/settings/get?access_token=${accessToken}&companyToken=${companyToken}&name=${name}`,
    method: 'get'
  })
}

/**
 * 七、文件操作
 * @name 1.1 获取知悉范围列表
 * @param {string} accessToken
 * @param {string} companyToken
 * @param {string} offset
 * @param {string} limit
 * @param {string} mbinfoguid	密标信息GUID
 *  * operationids 权限字段备注：
 * 枚举: 2,3,4,5,6,7,8
 * 1-标密 2-定密 3-签发 4-密级变更 5-秘密解除 6-脱密 7-签发撤回
 *  @returns {Promise}
 */
export function getFileRights(
  accessToken: string,
  companyToken: string,
  offset: string,
  limit: string,
  mbinfoguid: string
): Promise<API.ResponFileRights> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb/file/rights?access_token=${accessToken}&companyToken=${companyToken}&offset=${offset}&limit=${limit}&mbinfoguid=${mbinfoguid}`,
    method: 'get'
  })
}

/**
 * 七、文件操作
 * @name 1.2 获取密标属性信息
 * @param {string} companyToken
 * @param {string} mbinfoguid	密标信息GUID

 *  @returns {Promise}
 */
export function getFileInfo(
  companyToken: string,
  mbinfoguid: string
): Promise<API.ResponFileInfo> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb/file/info?companyToken=${companyToken}&mbinfoguid=${mbinfoguid}`,
    method: 'get'
  })
}

/**
 * 七、文件操作
 * @name 1.3 获取密标历史操作记录
 * @param {string} accessToken
 * @param {string} companyToken
 * @param {string} mbinfoguid	密标信息GUID

 *  @returns {Promise}
 */
export function getFileHistory(
  accessToken: string,
  companyToken: string,
  mbinfoguid: string
): Promise<API.ResponFileHistory> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb/file/history?access_token=${accessToken}&companyToken=${companyToken}&mbinfoguid=${mbinfoguid}`,
    method: 'get'
  })
}

/**
 * 七、文件操作
 * @name 1.4密标操作
 * @param {string} accessToken
 * @param {string} companyToken
 * @param {string} fileId 文件ID
 * @param {string} companyUid	用户ID
 * @param {number[]} accord	定密依据ID数组
 * @param {object[]} accordCustom	自定义定密依据数组
 * @param {number} classLevel	密级
 * @param {object} encryption	保密类型
 * @param {object[]} informRange	知悉范围
 * @param {string} informDescription知悉描述
 * @param {number} operation操作类型 ，枚举: 1,2,3,4,5
 * 枚举备注: 1-标密 2-定密 3-签发 4-密级变更 5-秘密解除 6-脱密 7-签发撤回
 * @param {object} extra额外参数
 *  @returns {Promise}
 */
export function getFileHandle(
  accessToken: string,
  companyToken: string,
  data: API.RequestFileHandleData
): Promise<API.ResponFileHandle> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb/file/handle?access_token=${accessToken}&companyToken=${companyToken}`,
    method: 'post',
    data
  })
}

/**
 * 七、文件操作
 * @name 1.5 (应用文档)密标操作开发者
 * @param {string} companyToken
 * @param {string} fileId 文件ID
 * @param {string} companyUid	用户ID
 * @param {number[]} accord	定密依据ID数组
 * @param {object[]} accordCustom	自定义定密依据数组
 * @param {number} classLevel	密级
 * @param {object} encryption	保密类型
 * @param {object[]} informRange	知悉范围
 * @param {string} informDescription知悉描述
 * @param {number} operation操作类型 ，枚举: 1,2,3,4,5
 * 枚举备注: 1-标密 2-定密 3-签发 4-密级变更 5-秘密解除 6-脱密 7-签发撤回
 * @param {object} extra额外参数
 *  @returns {Promise}
 */
export function getFileHandleDev(
  companyToken: string,
  data: API.RequestFileHandleDevData
): Promise<API.ResponFileHandleDev> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb/file/handle-dev?companyToken=${companyToken}`,
    method: 'post',
    data
  })
}

/**
 * 七、文件操作
 * @name 1.6 获取当前用户对于指定文档能进行的密标操作列表
 * @param {string} accessToken
 * @param {string} companyToken 文件ID
 * @param {string} mbinfoguid	密标信息GUID
 * 操作列表：
 * 1-标密
 * 2-定密
 * 3-签发
 * 4-密级变更
 * 5-秘密解除
 * 6-脱密
 * 7-签发撤回
 * 8-申请定密
 * 9-申请签发
 * 10-申请密级变更
 * 11-申请秘密解除
 * 12-申请脱密
 * @returns {Promise}
 */
export function getFileActions(
  accessToken: string,
  companyToken: string,
  mbinfoguid: string
): Promise<API.ResponFileActions> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb/file/actions?access_token=${accessToken}&company_token=${companyToken}&mbinfoguid=${mbinfoguid}`,
    method: 'post'
  })
}

/**
 * 七、文件操作
 * @name 1.7 标密状态文档另存为安全文档
 * @param {string} accessToken
 * @param {string} companyToken 文件ID
 * @param {string} fileId	文件ID
 * @param {string} groupId	团队ID
 * @returns {Promise}
 */
export function getFileDraftedSaveAs(
  accessToken: string,
  companyToken: string,
  fileId: string,
  groupId: string
): Promise<API.ResponFileDraftedSaveAs> {
  // @ts-ignore
  return request({
    url: `/open/secure/v1/mb/file/drafted-save-as?access_token=${accessToken}&company_token=${companyToken}&file_id=${fileId}&group_id=${groupId}`,
    method: 'post'
  })
}
