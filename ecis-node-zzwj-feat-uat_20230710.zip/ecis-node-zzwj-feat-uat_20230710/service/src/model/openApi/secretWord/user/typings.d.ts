/* eslint-disable camelcase */

/**
 * 密标文档协同管理相关接口
 **/

export namespace API {
  /** 公共返回值 */
  interface ResponseApi {
    result: number
    msg?: string
  }

  /** 获取指定目录下的定密依据和子目录 /secure/v1/mb/accord/dir */
  /** 批量获取指定ID的定密依据信息 /secure/v1/mb/accord/batch */
  interface ResponseAccordAndDir extends ResponseApi {
    data?: {
      list?: [
        {
          id: number
          value: string
          accord_class: number
          accord_class_name: string
          type?: number
          id_path?: string
        }
      ]
    }
  }

  /** 搜索定密依据 /secure/v1/mb/accord/search */
  interface ResponseAccordSearch extends ResponseApi {
    data?: {
      total: number
      list?: [
        {
          id: number
          parent_id: number
          value: string
          accord_class: number
          accord_class_name: string
          id_path: string
          name_path: string
          status: number
          sort: number
          parent_id: number
        }
      ]
    }
  }

  /** 搜索定密依据目录 /secure/v1/mb/accord-catalog/search */
  interface ResponseAccordcatalogSearch extends ResponseApi {
    data?: {
      total: number
      list?: [
        {
          id: number
          value: string
          status: number
          sort: number
          parent_id: number
        }
      ]
    }
  }

  /** 获取当前用户的密级 /secure/v1/mb/member-class/me */
  interface ResponSememberClassMe extends ResponseApi {
    data?: [
      {
        mb_class_name: string
        mb_class: number
      }
    ]
  }

  /** 获取当前用户的人员角色 /secure/v1/mb/role/me */
  interface ResponRoleMe extends ResponseApi {
    data: [
      {
        mbinfoguid: string
        role_type: string[]
      }
    ]
  }

  /** 获取权限范围覆盖当前用户的角色人员列表 /secure/v1/mb/role/cover */
  interface ResponRoleCover extends ResponseApi {
    data: {
      users: [
        {
          company_uid: string
          user_name: string
        }
      ]
    }
  }

  /** 获取密级标识列表 /secure/v1/mb/class/list */
  interface ResponClassList extends ResponseApi {
    data: {
      total: string
      list: [
        {
          id: number
          name: string
          identifier: string
          level: number
        }
      ]
    }
  }

  /** 获取保密类型列表 /secure/v1/mb/encryption/list */
  interface ResponEncryptionList extends ResponseApi {
    data: {
      total: string
      list: [
        {
          id: number
          name: string
          control_type: number
          control_value: string
          levels: [
            {
              level: number
              level_name: string
            }
          ]
        }
      ]
    }
  }

  /** 获取策略列表 /secure/v1/mb/settings/list */
  interface ResponSettingsList extends ResponseApi {
    data: [
      {
        name: string
        value: string
      }
    ]
  }

  /** 获取指定策略  /secure/v1/mb/settings/get */
  interface ResponSettingsGet extends ResponseApi {
    data: {
      name: string
      value: string
    }
  }

  /** 获取知悉范围列表  /secure/v1/mb/file/rights */
  interface ResponFileRights extends ResponseApi {
    data: {
      docrights: [
        {
          operationids: number[]
          principalaccount: string
          principalavatar: string
          principalid: string
          principaltitle: string
          principaltype: number
        }
      ]
      hasnextpage: boolean
    }
  }

  /** 获取密标属性信息  /secure/v1/mb/file/info */
  interface ResponFileInfo extends ResponseApi {
    data: {
      docrights: [
        {
          company_name: string
          file_name: string
          mb_status: string
          accord: [
            {
              value: string
              id: number
            }
          ]
          accord_custom: string[]
          encryption: {
            name: string
            value: string
            id: number
          }
          inform_range: [
            {
              principaltype: number
              principaltitle: string
              operationids: number[]
              principalid: string
            }
          ]
          inform_description: string
          classified: {
            name: string
            level: number
          }
          remove_info: {
            name: string
            company_uid: string
            time: number
          }
          commit_info: {
            name: string
            company_uid: string
            time: number
          }
          level_change_info: {
            name: string
            company_uid: string
            time: number
          }
          decrypt_info: {
            name: string
            company_uid: number
            time: number
          }
          draft_info: {
            name: string
            company_uid: string
            time: number
          }
          issue_info: {
            name: string
            company_uid: string
            time: number
          }
          extra: {
            issue_copy_number: string
            issue_number: string
            reason: string
          }
          mb_guid: string
          mb_info_guid: string
        }
      ]
      hasnextpage: boolean
    }
  }

  /** 获取密标历史操作记录  /secure/v1/mb/file/history */
  interface ResponFileHistory extends ResponseApi {
    data: [
      {
        company_name: string
        file_name: string
        mb_status: number
        accord: [
          {
            value: string
            id: number
          }
        ]
        accord_custom: string[]
        encryption: {
          name: string
          value: string
          id: number
        }
        inform_range: [
          {
            principaltype: number
            principaltitle: string
            operationids: number[]
            principalid: string
          }
        ]
        inform_description: string
        classified: {
          name: string
          level: number
        }
        remove_info: {
          name: string
          company_uid: string
          time: number
        } | null
        commit_info: {
          name: string
          company_uid: string
          time: number
        } | null
        level_change_info: {
          name: string
          company_uid: string
          time: number
        } | null
        decrypt_info: {
          name: string
          company_uid: string
          time: number
        } | null
        draft_info: {
          name: string
          company_uid: string
          time: number
        } | null
        issue_info: {
          name: string
          company_uid: string
          time: number
        } | null
        extra: {
          issue_copy_number: string
          issue_number: string
          reason: string
        } | null
        mb_guid: string
        mb_info_guid: string
      }
    ]
  }

  /** 密标操作  secure/v1/mb/file/handle  data参数 */
  interface RequestFileHandleData {
    file_id: string
    group_id: string
    accord: string
    class_level: string
    accord_custom: string[]
    encryption: {
      id: number
      value: string
    }
    inform_range: {
      operationids: number[]
      principalid: string
      principaltype: number
    }
    inform_description: string
    operation: string
    extra: {
      reason: string
      issue_number: string
      issue_copy_number: string
    }
  }

  /** 密标操作  secure/v1/mb/file/handle */
  interface ResponFileHandle extends ResponseApi {
    data: {
      mb_guid: string
      mb_info_guid: string
      document_id: number
    }
  }

  /** (应用文档)密标操作开发者  /secure/v1/mb/file/handle-dev  data参数 */
  interface RequestFileHandleDevData {
    file_id: string
    company_uid: string
    accord: number[]
    accord_custom: string[]
    class_level: string
    encryption: {
      id: number
      value: string
    }
    inform_range: {
      operationids: number[]
      principalid: string
      principaltype: number
    }
    inform_description: string
    operation: string
    extra: {
      reason: string
      issue_number: string
      issue_copy_number: string
    }
  }

  /** (应用文档)密标操作开发者  /secure/v1/mb/file/handle-dev */
  interface ResponFileHandleDev extends ResponseApi {
    data: {
      mb_guid: string
      mb_info_guid: string
      document_id: number
    }
  }

  /** 获取当前用户对于指定文档能进行的密标操作列表  /secure/v1/mb/file/actions */
  interface ResponFileActions extends ResponseApi {
    data: {
      actions: number[]
    }
  }

  /** 标密状态文档另存为安全文档  /secure/v1/mb/file/drafted-save-as */
  interface ResponFileDraftedSaveAs extends ResponseApi {
    data: {
      document_id: number
    }
  }
}
