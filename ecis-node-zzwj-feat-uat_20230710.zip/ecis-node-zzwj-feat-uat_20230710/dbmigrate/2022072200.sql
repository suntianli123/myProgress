SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `middle_notify_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` varchar(2000) NOT NULL COMMENT '人员Id',
  `second_org_id` varchar(500) DEFAULT NULL COMMENT '二级部门Id',
  `is_fit` varchar(500) DEFAULT NULL COMMENT '是否属于同一单位(0: 是, 1: 不是)',
  `is_premiss` varchar(500) DEFAULT NULL COMMENT '超管设置',
  `group_id` varchar(500) DEFAULT NULL COMMENT '团队Id',
  `group_name` varchar(500) DEFAULT NULL COMMENT '团队名称',
  `description` varchar(500) DEFAULT NULL COMMENT '描述',
  `creat_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `group_id` (`group_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;