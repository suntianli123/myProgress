import { Context } from 'koa'
import config from '../../config'
import { sdkInstance } from '../../grpc/sdk'
import { resJson, resErrJson } from '../../util/msgCode'
import { logger } from '../../server'
import { getSQLSelResult } from '../common'
import { currentTime } from '../../util/momentTime'
import { handleCheckGroup, handleMessageGroup } from '.'

/**
 * 更新团队解散时间
 */
export async function updatetime(ctx: Context) {
    let res
    try {
      const { batchNumber, membertime, grouptime } = ctx.request.body
      /* 获取当前时间 */
      const time = await currentTime()
      if (!batchNumber) {
        throw resErrJson('获取批次号失败')
      }
      const groupSQLResult: any = await sdkInstance.middleware.mysql.select(
        config.dbName,
        `SELECT * FROM middle_group WHERE is_delete=0 AND batch_number=?`,
        [batchNumber]
      )
      const groupData: any = await getSQLSelResult(groupSQLResult)
      if (groupData.length == 0) {
        throw resErrJson('没有匹配批次号的团队')
      }
      const updateMiddle = await sdkInstance.middleware.mysql.update(
        config.dbName,
        `UPDATE middle_group SET member_endtime=?, group_endtime=?,update_time=? WHERE is_delete=0 AND batch_number=?`,
        [membertime, grouptime, time, batchNumber]
      )
      logger.info({ msg: `修改解散时间－中间表，updateMiddle:${JSON.stringify(updateMiddle)}, membertime: ${membertime}, batchNumber: ${batchNumber}` })
      /* 返回结果判断 */
      if (updateMiddle.result !== 'ok') {
        logger.warn({ msg: `修改解散时间－中间表失败，updateMiddle:${JSON.stringify(updateMiddle)}, membertime: ${membertime}, grouptime: ${grouptime}` })
        throw resErrJson('修改失败')
      }
      if (grouptime && groupData[0].group_endtime != grouptime) {
        /* 更新中间表 */
        const upData = await sdkInstance.middleware.mysql.update(
          config.dbName,
          'UPDATE middle_group SET message_time=?, update_time=? WHERE is_delete=0 AND group_id=?',
          ['', time, groupData[0].group_id]
        )
        logger.info({
          msg: `清除团队中间表的消息推送时间:${batchNumber}, upData: ${JSON.stringify(upData)}`
        })
      }
      res = {
        result: 0,
        msg: "修改成功"
      }
    } catch (e) {
      /** 格式化错误信息-记录错误日志 */
      const errJson = resErrJson(e)
      // 错误返回值
      res = errJson
    }
    ctx.status = 200
    /* 加密返回数据 */
    ctx.body = res
    // ctx.body = aesEncryption(res)
    return ctx
}

/**
 * 查询团队解散时间
 */
export async function getgrouptime(ctx: Context) {
    let res
    try {
      const { limit, page = 0 } = ctx.query
      const offset: any = Number(page) * Number(limit)
      const groupSQLResult: any = await sdkInstance.middleware.mysql.select(
        config.dbName,
        `SELECT * FROM middle_group WHERE is_delete=0 order BY create_time desc LIMIT ${limit} OFFSET ${offset}`,
        []
      )
      const groupData: any = await getSQLSelResult(groupSQLResult)

      const totalData:any = await sdkInstance.middleware.mysql.select(
        config.dbName,
        `SELECT count(0) FROM middle_group WHERE is_delete=0`,
        []
      )
      let countNum: any = await getSQLSelResult(totalData)
      countNum = countNum[0] && countNum[0]['count(0)']
      res = {
        data: groupData,
        total: countNum,
        result: 0
      }
    } catch (e) {
      /** 格式化错误信息-记录错误日志 */
      const errJson = resErrJson(e)
      // 错误返回值
      res = errJson
    }
    ctx.status = 200
    /* 加密返回数据 */
    ctx.body = res
    // ctx.body = aesEncryption(res)
    return ctx
}

/**
 * 查询团队信息
 */
export async function searchgroup(ctx: Context) {
  let res
  try {
    const { batchNumber,limit = 10, page = 0 } = ctx.query
    const offset: any = Number(page) * Number(limit)

    let searchSql: any;
    if (batchNumber) {
      searchSql = `SELECT * FROM middle_group WHERE is_delete=0 AND batch_number=? order BY create_time desc LIMIT ${limit} OFFSET ${offset}`
    } else {
      searchSql = `SELECT * FROM middle_group WHERE is_delete=0 order BY create_time desc LIMIT ${limit} OFFSET ${offset}`
    }
    const groupSQLResult = await sdkInstance.middleware.mysql.select(
      config.dbName,
      searchSql,
      [batchNumber]
    )
    const groupData = await getSQLSelResult(groupSQLResult)

    const totalData:any = await sdkInstance.middleware.mysql.select(
      config.dbName,
      `SELECT count(0) FROM middle_group WHERE is_delete=0`,
      []
    )
    let countNum: any = await getSQLSelResult(totalData)
    countNum = countNum[0] && countNum[0]['count(0)']
    res = {
      data: groupData,
      total: batchNumber ? groupData.length : countNum,
      result: 0
    }
  } catch (e) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(e)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  /* 加密返回数据 */
  ctx.body = res
  // ctx.body = aesEncryption(res)
  return ctx
}



async function asd (i: number) {
  const time = await currentTime()
    console.log(`第${i}, 时间:${time}`)
    sdkInstance.middleware.mysql.insert(
      config.dbName,
      'INSERT INTO middle_group (group_id, batch_number, own_id, user_id, start_time, end_time, create_time, update_time, is_delete, member_endtime, group_endtime) VALUES (?, ?, ?, ?, ?, ?, now(), now(), ?, ?, ?)',
      [`group${i}`, `202400${i}`, `0DoPeLb3wawdMDE`, `111111`, time, time, 0, 48, 72]
    )
}
export async function testgroup(ctx: Context) {
    let res
    try {
      const { testType } = ctx.query
      // for (let i=1; i<30; i++) {
      //   setTimeout( ()=> {
      //     asd( i );
      //   }, i*1000 );
      // }
      if (testType == '1') {
        await handleMessageGroup(['72','48','24','12','6','3'])
      } else if (testType == '2') {
        for (let i=1; i<30; i++) {
          setTimeout( ()=> {
            asd( i );
          }, i*1000 );
        }
      } else {
        handleCheckGroup()
      }
      res = resJson()
    } catch (e) {
      /** 格式化错误信息-记录错误日志 */
      const errJson = resErrJson(e)
      // 错误返回值
      res = errJson
    }
    ctx.status = 200
    /* 加密返回数据 */
    ctx.body = res
    // ctx.body = aesEncryption(res)
    return ctx
}
