import { getUserByAlias } from '.'
import config from '../../config'
import {
  batchActiveDepts,
  batchThirdBindDepts,
  deptsThirdBind
} from '../../model/openApi/company'
import {
  createGroupAdmin,
  updateGroupAdmin
} from '../../model/openApi/companyFileAdmin'
import { GroupType } from '../../model/openApi/companyFileAdmin/typings'
import { logger } from '../../server'
import { resErrJson } from '../../util/msgCode'
import sdkInstance from '../../util/sdk'
import { handleActiveUpdate } from '../user/user'

interface CreateGroupParams {
  companyToken: string
  operatorId: string
  batchNumber: string
  companyUid: string
  groupType: GroupType
  IDCard: string
  startTime: string
  endTime: string
}

interface UpdateGroupParams {
  companyToken: string
  operatorId: string
  batchNumber: string
  companyUid: string
  groupId: string
  IDCard: string
  startTime: string
  endTime: string
}

export const getCompanyUidByIDCard = async (
  companyToken: string,
  IDCard: string
) => {
  let companyUid = ''
  // 通过三方id查找用户
  const thirdUserInfo = await batchThirdBindDepts(companyToken, {
    third_union_ids: IDCard,
    status: 'active,notactive,disabled'
  })
  logger.info(
    `通过IDCard获取用户信息, IDCard: ${IDCard}, result: ${JSON.stringify(
      thirdUserInfo
    )}`
  )
  let userInfo
  if (
    thirdUserInfo &&
    thirdUserInfo.data &&
    Array.isArray(thirdUserInfo.data.company_users) &&
    thirdUserInfo.data.company_users.length > 0
  ) {
    userInfo = thirdUserInfo.data.company_users[0]
    companyUid = userInfo.company_uid
  } else {
    // 未关联三方id，通过IDCard去企业用户列表匹配用户别名字段alias_name
    userInfo = await getUserByAlias(IDCard)
    if (userInfo) {
      companyUid = userInfo.company_uid
      // 绑定三方id
      await deptsThirdBind(companyToken, companyUid, {
        third_union_id: IDCard
      })
    }
  }
  if (!companyUid) {
    throw resErrJson(`获取牵头人信息失败, IDCard: ${IDCard}`)
  }
  const userStatus = userInfo.status
  if (userStatus === 'notactive') {
    // 激活
    await batchActiveDepts(companyToken, [companyUid])
  } else if (userStatus === 'disabled') {
    // 启用
    await handleActiveUpdate({
      company_uid: companyUid
    })
  }
  return companyUid
}

export const handleCreateGroup = async (params: CreateGroupParams) => {
  const {
    companyToken,
    operatorId,
    batchNumber,
    companyUid,
    groupType,
    IDCard,
    startTime,
    endTime
  } = params
  if (!startTime || !endTime) {
    throw resErrJson(
      `获取评标开始/结束时间失败, data: ${JSON.stringify(params)}`
    )
  }
  const createGroupResult = await createGroupAdmin(companyToken, {
    operator_id: operatorId,
    name: batchNumber,
    owner_id: companyUid,
    type: groupType
  })
  if (createGroupResult.result === 0) {
    logger.info(`使用批次号: ${batchNumber}, 创建团队成功`)
  } else {
    throw resErrJson(
      `调用创建团队接口失败, 批次号: ${batchNumber}, reason：${JSON.stringify(
        createGroupResult
      )}`
    )
  }
  const groupId = createGroupResult.group.id
  const insertMiddleGroup = await sdkInstance.middleware.mysql.insert(
    config.dbName,
    'INSERT INTO middle_group (group_id, batch_number, own_id, user_id, start_time, end_time, create_time, update_time, is_delete, member_endtime, group_endtime) VALUES (?, ?, ?, ?, ?, ?, now(), now(), ?, ?, ?)',
    [groupId, batchNumber, companyUid, IDCard, startTime, endTime, 0, 48, 168]
  )
  /* 返回结果判断 */
  if (insertMiddleGroup.result !== 'ok') {
    throw resErrJson(
      `新增团队表失败, reason: ${JSON.stringify(insertMiddleGroup)}`
    )
  } else {
    logger.info(`新增团队表, 批次号: ${batchNumber}`)
  }
  return groupId
}

export const handleUpdateGroup = async (params: UpdateGroupParams) => {
  const {
    companyToken,
    operatorId,
    batchNumber,
    companyUid,
    groupId,
    IDCard,
    startTime,
    endTime
  } = params
  const updateGroupResult = await updateGroupAdmin(companyToken, groupId, {
    operator_id: operatorId,
    owner_id: companyUid
  })
  if (updateGroupResult.result === 0) {
    logger.info(`修改团队信息成功: ${batchNumber}`)
  } else {
    logger.info(
      `调用修改团队信息接口失败, 批次号: ${batchNumber}, reason：${JSON.stringify(
        updateGroupResult
      )}`
    )
  }
  const updateMiddleGroup = await sdkInstance.middleware.mysql.update(
    config.dbName,
    `UPDATE middle_group SET own_id = ?, user_id = ?, ${
      startTime ? `start_time = '${startTime}', ` : ''
    }${
      endTime ? `end_time = '${endTime}', ` : ''
    }update_time = now() WHERE group_id = ?`,
    [companyUid, IDCard, groupId]
  )
  if (updateMiddleGroup.result !== 'ok') {
    logger.info(
      `更新团队表失败, reason: ${JSON.stringify(updateMiddleGroup)}`
    )
  } else {
    logger.info(`更新团队表, 批次号: ${batchNumber}`)
  }
}
