import { getAccessToken } from './../authToken/index'
import config from '../../config'
import { sdkInstance } from '../../grpc/sdk'
import { logger } from '../../ins'
import {
  batchActiveDepts,
  batchThirdBindDepts,
  companyUsersEnable,
  deptsThirdBind,
  getCompanyUsers
} from '../../model/openApi/company'
import {
  createGroupAdmin,
  deleteGroup,
  deleteGroupMember,
  getGroupMember,
  insertGroupMember,
  updateGroupAdmin
} from '../../model/openApi/companyFileAdmin'
import { userMap } from '../../util'
import { currentTime } from '../../util/momentTime'
import { resErrJson } from '../../util/msgCode'
// import query from '../../util/mysql'
import { getCompanyToken } from '../authToken/func'
import { getSQLSelResult } from '../common'
import {
  activeUpdateMiddle,
  handleActiveUpdate,
  handleUserDisable
} from '../user/user'
import { getUserOpenId } from '../userinit'
import { MemberList } from '../../model/openApi/companyFileAdmin/typings'
import {
  getCompanyUidByIDCard,
  handleCreateGroup,
  handleUpdateGroup
} from './group'
import { API } from '../../model/openApi/company/typings'
import { Context } from 'koa'
import axios from 'axios'
import moment = require('moment')

interface IUserGroupThird {
  batchNumber: string // 批次号
  IDCard: string // 项目经理身份证号码 传牵头项目经理（如果有）
  startTime: string // 评标开始时间 批次时间
  endTime: string // 评标结束时间 批次时间
}

interface IUserGroupThirdResult extends IUserGroupThird {
  users: Array<{
    id: string
    loginName: string
    name: string
    dept: Array<{
      dept_id: string
    }>
  }>
}

type IMiddleUser = Array<{
  id: number
  user_id: string
  nick_name: string
  company_uid: string
  create_time: string
  update_time: string
  create_user: string
  update_user: string
  is_delete: number
}>

type IMiddleGroup = Array<{
  id: number
  group_id: string
  batch_number: string
  own_id: string
  user_id: string
  start_time: string
  end_time: string
  create_time: string
  update_time: string
  is_delete: number
}>

export const handleGroupNotice = async (userGroup: IUserGroupThird) => {
  const { batchNumber, IDCard, startTime, endTime } = userGroup
  if (!batchNumber) {
    throw resErrJson(`获取批次号失败, data: ${JSON.stringify(userGroup)}`)
  }
  const companyToken = await getCompanyToken()
  const companyUid = await getCompanyUidByIDCard(companyToken, IDCard)
  const groupResult = await sdkInstance.middleware.mysql.select(
    config.dbName,
    'SELECT * FROM middle_group WHERE batch_number = ? AND is_delete = 0',
    [batchNumber]
  )
  // 中间表团队信息
  const groupInfo: IMiddleGroup = await getSQLSelResult(groupResult)
  // 超管company_uid
  const operatorId = await getAdminUid()
  const params = {
    companyToken,
    operatorId,
    batchNumber,
    companyUid,
    IDCard,
    startTime,
    endTime
  }
  if (groupInfo.length === 0) {
    await handleCreateGroup({
      ...params,
      groupType: 'corpnormal'
    })
  } else {
    const groupId = groupInfo[0].group_id
    await handleUpdateGroup({
      ...params,
      groupId
    })
    /* 获取当前时间 */
    const time = await currentTime()

    const endStr: any = moment(groupInfo[0].end_time).format('YYYY-MM-DD HH:mm:ss')
    logger.info({
      msg: `清除消息推送转换的时间:${endStr}, groupInfo: ${JSON.stringify(groupInfo)}`
    })
    if (endTime && endStr != endTime) {
      /* 更新中间表 */
      const upData = await sdkInstance.middleware.mysql.update(
        config.dbName,
        'UPDATE middle_group SET message_time=?, update_time=? WHERE is_delete=0 AND group_id=?',
        ['', time, groupInfo[0].group_id]
      )
      logger.info({
        msg: `清除团队中间表的消息推送时间:${batchNumber}, upData: ${JSON.stringify(upData)}`
      })
    }
  }
}

export const handleGroupChange = async (userGroup: IUserGroupThirdResult) => {
  const { batchNumber, IDCard, startTime, endTime, users } = userGroup
  if (!batchNumber) {
    throw resErrJson(`获取批次号失败, data: ${JSON.stringify(userGroup)}`)
  }
  const companyToken = await getCompanyToken()
  const companyUid = await getCompanyUidByIDCard(companyToken, IDCard)
  const groupResult = await sdkInstance.middleware.mysql.select(
    config.dbName,
    'SELECT * FROM middle_group WHERE batch_number = ? AND is_delete = 0',
    [batchNumber]
  )
  // 中间表团队信息
  const groupInfo: IMiddleGroup = await getSQLSelResult(groupResult)
  // 超管company_uid
  const operatorId = await getAdminUid()
  const params = {
    companyToken,
    operatorId,
    batchNumber,
    companyUid,
    IDCard,
    startTime,
    endTime
  }
  const accessToken = await getAccessToken(IDCard)
  // 三方id集合
  const userIds = users.map(user => user.id || '').filter(id => id)
  // const userInfoResult = await sdkInstance.middleware.mysql.select(
  //   config.dbName,
  //   'SELECT * FROM middle_users WHERE user_id in (?)',
  //   [userIds]
  // )
  // // wps账号信息
  // const userInfo: IMiddleUser = await getSQLSelResult(userInfoResult)
  const thirdUserInfo = await batchThirdBindDepts(companyToken, {
    third_union_ids: userIds.join(),
    status: 'active,notactive,disabled'
  })
  if (thirdUserInfo.result !== 0) {
    throw resErrJson(`获取成员信息失败, ${JSON.stringify(thirdUserInfo)}`)
  }
  const userInfo = thirdUserInfo.data.company_users
  if (groupInfo.length === 0) {
    const groupId = await handleCreateGroup({
      ...params,
      groupType: 'corpnormal'
    })
    await handleInsertMember(groupId, userInfo, accessToken, companyToken)
  } else {
    const groupId = groupInfo[0].group_id
    await handleUpdateGroup({
      ...params,
      groupId
    })
    await updateGroupMember(groupId, userInfo, accessToken, companyToken)
    /* 获取当前时间 */
    const time = await currentTime()
    const endStr: any = moment(groupInfo[0].end_time).format('YYYY-MM-DD HH:mm:ss')
    logger.info({
      msg: `清除消息推送转换的时间:${endStr}, groupInfo: ${JSON.stringify(groupInfo)}`
    })
    if (endTime && endStr != endTime) {
      /* 更新中间表 */
      const upData = await sdkInstance.middleware.mysql.update(
        config.dbName,
        'UPDATE middle_group SET message_time=?, update_time=? WHERE is_delete=0 AND group_id=?',
        ['', time, groupInfo[0].group_id]
      )
      logger.info({
        msg: `清除团队中间表的消息推送时间:${batchNumber}, upData: ${JSON.stringify(upData)}`
      })
    }
  }
}

export const getAdminUid = async () => {
  const companyToken = await getCompanyToken()
  const offset = 0
  let operator_id
  do {
    const res = await getCompanyUsers(
      companyToken,
      offset * 1000,
      1000,
      'active'
    )
    const { result, company_users } = res
    const operator =
      company_users &&
      company_users.find(
        items => items.role_id && items.role_id.toString() === '1'
      )

    operator_id = operator && operator.company_uid
  } while (!operator_id)
  logger.info({
    msg: '超级管理员uid',
    body: operator_id
  })
  return operator_id
}

export const getUserByAlias = async (idCard: string) => {
  const companyToken = await getCompanyToken()
  const offset = 0
  let companyInfo
  do {
    const res = await getCompanyUsers(
      companyToken,
      offset * 1000,
      1000,
      'active,notactive,disabled'
    )
    const { result, company_users } = res
    if (result !== 0) throw resErrJson('获取企业成员失败')
    const operator =
      company_users && company_users.find(items => items.alias_name === idCard)

    companyInfo = operator
  } while (!companyInfo)
  logger.info({
    msg: '项目经理Uid',
    uid: companyInfo,
    idCard
  })
  return companyInfo
}

/**
 *
 * @param memberList 团队已有成员列表
 * @param userInfo 当前批次成员信息，查中间表后所得
 * @returns insertMembers, deleteMembers
 */
const handleMemberCheck = async (
  memberList: MemberList,
  userInfo: API.UserInfoByUnion
) => {
  const insertMembers: API.UserInfoByUnion = []
  const deleteMembers: MemberList = []
  for (const user of userInfo) {
    const existInGroup = memberList.some(
      member => member.company_uid === user.company_uid
    )
    if (!existInGroup) insertMembers.push(user)
  }
  for (const member of memberList) {
    const existInThird = userInfo.some(
      user => user.company_uid === member.company_uid
    )
    const userSqlRes = await sdkInstance.middleware.mysql.select(
      config.dbName,
      'SELECT * FROM middle_users WHERE is_delete !=1 AND company_uid=?',
      [member.company_uid]
    )
    const userData: any = await getSQLSelResult(userSqlRes)
    let userFlag: any = true;
    if (userData.length == 0) {
      userFlag = false
    } 
    if (!existInThird && userFlag) deleteMembers.push(member)
  }
  return {
    insertMembers,
    deleteMembers
  }
}

const handleInsertMember = async (
  groupId: string,
  userInfo: API.UserInfoByUnion,
  accessToken: string,
  companyToken: string
) => {
  // 禁用状态用户
  const disableUsers = userInfo.filter(user => user.status === 'disabled')
  // 加入团队前启用
  const activeCompanyUids = disableUsers.map(user => user.company_uid)
  if (activeCompanyUids.length > 0) {
    const enableResult = await companyUsersEnable(
      companyToken,
      activeCompanyUids.join()
    )
    if (enableResult.result !== 0) {
      logger.warn(
        `启用成员失败, user: ${JSON.stringify(
          userInfo.filter(user => user.status === 'disabled')
        )}, reason: ${JSON.stringify(enableResult)}`
      )
    }
    const time = currentTime()
    // 更新中间表成员状态
    for (const disUser of disableUsers) {
      await activeUpdateMiddle(time, disUser)
    }
  }
  const companyUids = userInfo.map(user => user.company_uid).join(',')
  logger.info(`团队: ${groupId}, 添加成员: ${companyUids}`)
  const addGroupMemberResult = await insertGroupMember(
    groupId,
    accessToken,
    companyToken,
    companyUids
  )
  if (addGroupMemberResult.result !== 0) {
    logger.warn(
      `添加团队成员失败, groupId: ${groupId}, reason: ${JSON.stringify(
        addGroupMemberResult
      )}`
    )
  }

  for (let user of userInfo) {
    const userSqlRes = await sdkInstance.middleware.mysql.select(
      config.dbName,
      'SELECT * FROM middle_users WHERE is_delete !=1 AND company_uid=?',
      [user.company_uid]
    )
    const userData: any = await getSQLSelResult(userSqlRes)
    if (userData.length == 0) {
      logger.warn(`用户中间表查询失败，${JSON.stringify(user)}`)
      continue
    }
    if (userData[0]?.group_ids && userData[0]?.group_ids.includes(groupId)) {
      logger.info(`用户中间表团队已存在，${JSON.stringify(user)}`)
      continue
    }
    const groupIds = userData[0].group_ids ? `${userData[0].group_ids},${groupId}` : groupId
    const updateMiddleUser = await sdkInstance.middleware.mysql.update(
      config.dbName,
      'UPDATE middle_users SET group_ids=? WHERE company_uid=?',
      [groupIds, user.company_uid]
    )
    logger.info({ msg: `更新用户表-中间表:${JSON.stringify(updateMiddleUser)}` })
  }
}

const handleDeleteMember = async (
  groupId: string,
  memberList: MemberList,
  accessToken: string,
  companyToken: string
) => {
  const companyUids = memberList.map(member => member.company_uid)
  const userInfoResult = await sdkInstance.middleware.mysql.select(
    config.dbName,
    'SELECT * FROM middle_users WHERE company_uid in (?)',
    [companyUids]
  )
  // wps账号信息
  const userInfo: IMiddleUser = await getSQLSelResult(userInfoResult)
  logger.info(
    `团队: ${groupId}, 删除成员: ${memberList
      .map(member => member.company_uid)
      .join()}`
  )
  // 给用户表添加团队id
  for (const member of memberList) {
    const deleteGroupMemberResult = await deleteGroupMember(
      groupId,
      member.company_uid,
      accessToken,
      companyToken
    )
    if (deleteGroupMemberResult.result !== 0) {
      logger.warn(
        `移除团队成员失败, groupId: ${groupId}, reason: ${JSON.stringify(
          deleteGroupMemberResult
        )}`
      )
      continue
    } else {
      if (userInfo.some(user => user.company_uid === member.company_uid)) {
        const userItem: any = userInfo.filter((item: any) => item.company_uid == member.company_uid)
        let groupIds: any = [];
        if (userItem.length > 0 && userItem[0]?.group_ids) {
          groupIds = userItem[0]?.group_ids.split(',')
          groupIds = groupIds.filter((item: any) => item != groupId)
          groupIds = groupIds.join()
          logger.info(`团队移除成员成功, groupId: ${groupId}`)
          const updateMiddleUser = await sdkInstance.middleware.mysql.update(
            config.dbName,
            'UPDATE middle_users SET group_ids=? WHERE company_uid=?',
            [groupIds, member.company_uid]
          )
          logger.info({ msg: `更新用户表-中间表:${JSON.stringify(updateMiddleUser)}` })
        }
        if (groupIds.length == 0) {
          await handleUserDisable(member)
        }
      }
    }
  }
}

const updateGroupMember = async (
  groupId: string,
  userInfo: API.UserInfoByUnion,
  accessToken: string,
  companyToken: string
) => {
  // 获取团队成员列表
  const memberListRes = await getGroupMember(groupId, accessToken, companyToken)
  if (memberListRes.result !== 0) {
    logger.warn(
      `获取团队成员列表失败, groupId: ${groupId}, reason: ${JSON.stringify(
        memberListRes
      )}`
    )
    return
  }
  const { insertMembers, deleteMembers } = await handleMemberCheck(
    memberListRes.data.filter(member => member.role === 'member'),
    userInfo
  )
  insertMembers.length &&
    (await handleInsertMember(
      groupId,
      insertMembers,
      accessToken,
      companyToken
    ))
  deleteMembers.length &&
    (await handleDeleteMember(
      groupId,
      deleteMembers,
      accessToken,
      companyToken
    ))
}

export const handleCheckGroup = async () => {
  // 评标结束后48小时，将评标专家和招标人代表同时移出所在团队
  const removeMemberGroups = await getGroupByHours('member_endtime')
  const companyToken = await getCompanyToken(true)
  logger.info(
    `需要移除成员的团队: ${removeMemberGroups.length
    }个, batchNumber: ${removeMemberGroups
      .map(group => group.batch_number)
      .join()}`
  )
  for (const group of removeMemberGroups) {
    const { group_id, user_id } = group
    const accessToken = await getAccessToken(user_id)
    const memberListResult = await getGroupMember(
      group_id,
      accessToken,
      companyToken
    )
    if (memberListResult.result !== 0) {
      if (memberListResult.result === 10301004) {
        logger.info(`团队不存在, 更新中间表状态 ${JSON.stringify(group)}`)
        const time = currentTime()
        const updateMiddleGroup = await sdkInstance.middleware.mysql.update(
          config.dbName,
          'UPDATE middle_group SET is_delete = 1, update_time = ? WHERE group_id = ?',
          [time, group_id]
        )
        if (updateMiddleGroup.result !== 'ok') {
          logger.warn(
            `更新团队表失败, reason: ${JSON.stringify(updateMiddleGroup)}`
          )
        }
        continue
      } else {
        logger.warn(
          `获取团队成员列表失败, groupId: ${group_id}, reason: ${JSON.stringify(
            memberListResult
          )}`
        )
        continue
      }
    }
    await handleDeleteMember(
      group_id,
      memberListResult.data.filter(member => member.role !== 'creator'),
      accessToken,
      companyToken
    )
  }
  // 评标结束时间后72小时，团队自动解散
  const deleteGroups = await getGroupByHours('group_endtime')
  logger.info(
    `需要解散的团队: ${deleteGroups.length}个, batchNumber: ${deleteGroups
      .map(group => group.batch_number)
      .join()}`
  )
  for (const group of deleteGroups) {
    const { group_id, user_id, batch_number } = group
    const time = currentTime()
    const accessToken = await getAccessToken(user_id)
    if (!accessToken) continue
    const deleteGroupResult = await deleteGroup(
      group_id,
      accessToken,
      companyToken
    )
    if (deleteGroupResult.result !== 0) {
      logger.warn(
        `解散团队失败,  batchNumber: ${batch_number}, reason: ${JSON.stringify(
          deleteGroupResult
        )}`
      )
      continue
    } else {
      logger.info(`解散团队,  batchNumber: ${batch_number}`)
    }
    const updateMiddleGroup = await sdkInstance.middleware.mysql.update(
      config.dbName,
      'UPDATE middle_group SET is_delete = 1, update_time = ? WHERE group_id = ?',
      [time, group_id]
    )
    if (updateMiddleGroup.result !== 'ok') {
      logger.warn(
        `更新团队表失败, reason: ${JSON.stringify(updateMiddleGroup)}`
      )
    }
  }
}

const getGroupByHours = async (hours: any) => {
  const sql = `SELECT * FROM middle_group WHERE DATEDIFF(CURDATE(), DATE(end_time)) * 24 + (TIME_TO_SEC(NOW()) - TIME_TO_SEC(end_time)) / 60 / 60 >= ${hours} AND is_delete = 0`
  const groupInfoSQL = await sdkInstance.middleware.mysql.select(
    config.dbName,
    sql,
    []
  )
  const groupInfo = await getSQLSelResult(groupInfoSQL)
  return groupInfo
}

const getMessageByHours = async (hours: any) => {
  /* 
    团队在表中end_time时间字段的'72'小时后解散团队（72'小时是可以配置的，这里是拿来举例）,
    消息推送在解散团队前（'72','48','24','12','6','3'）小时进行推送。
    sql判断中(..)>0是在72小时时会出现-0.123的情况，用TRUNCATE会将值变为0，消息推送推提前触发，在48、24不会出现.
    DATEDIFF(CURDATE(), DATE(end_time)) * 24： 是年月日换算成小时（2024-10-10）
    TIME_TO_SEC(NOW()) - TIME_TO_SEC(end_time)) / 60 / 60： 是时分秒换算成小时（14:00:00）
    逻辑：当前时间-end_time时间 = 72-消息推送时间（'72','48','24','12','6','3'）
    为0是72小时进行消息推送，为24是48小时进行推送，为48是24小时进行推送
  */ 
  const sql = `SELECT * FROM middle_group WHERE ((DATEDIFF(CURDATE(), DATE(end_time)) * 24 + (TIME_TO_SEC(NOW()) - TIME_TO_SEC(end_time)) / 60 / 60)) > 0 AND TRUNCATE((DATEDIFF(CURDATE(), DATE(end_time)) * 24 + (TIME_TO_SEC(NOW()) - TIME_TO_SEC(end_time)) / 60 / 60), 0) = group_endtime - ${hours} AND is_delete = 0`
  logger.info({ msg: `${hours}小时的消息推送sql: ${sql}` })
  const groupInfoSQL = await sdkInstance.middleware.mysql.select(
    config.dbName,
    sql,
    []
  )
  const groupInfo = await getSQLSelResult(groupInfoSQL)
  return groupInfo
}

// 根据用户ID获取用户信息
export const encryptUserDept = async (ctx: Context) => {
  let res
  try {
    const userId = ctx.query.userId || ''
    if (!userId) {
      throw Error('id不能为空')
    }
    const params = {
      queryStr: `raw_text=${userId}`
    }
    // 加密comp_uid获得company_uid
    const result = await sdkInstance.service.wpsopen.getIdConfuse(params)
    if (
      result &&
      result.result === 'ok' &&
      result.data &&
      result.data.confuse_result
    ) {
      logger.warn(`加密用户获取成功 ${JSON.stringify(result)}`)
      const SQLResult = await sdkInstance.middleware.mysql.select(
        config.dbName,
        'SELECT * FROM middle_users WHERE is_delete !=1 AND company_uid=?',
        [result?.data?.confuse_result]
      )
      const userMiddle = await getSQLSelResult(SQLResult)
      if (userMiddle && userMiddle.length > 0) {
        res = {
          result: '1',
          msg: '存在部门中',
          company_uid: result?.data?.confuse_result,
          userInfo: userMiddle
        }
      } else {
        res = {
          result: '0',
          msg: '不在部门中',
          company_uid: result?.data?.confuse_result
        }
      }
    } else {
      logger.warn(`加密用户ID失败! ${userId} errMsg: ${result.msg}`)
      throw Error(JSON.stringify(result))
    }
  } catch (error) {
    console.log(error)
    logger.error(`加密用户id失败, ${JSON.stringify(error)}`)
    res = resErrJson({ msg: '加密用户id失败' })
  }
  ctx.status = 200
  ctx.body = res
}


// 按时间消息推送
export const handleMessageGroup = async (hourArr: any) => {
  const time = await currentTime()
  for (const hour of hourArr) {
    const messageGroups = await getMessageByHours(hour)
    logger.info(
      `${hour}小时需要消息的团队: ${messageGroups.length
      }个, batchNumber: ${messageGroups
        .map(group => group.batch_number)
        .join()}`
    )
    for (const group of messageGroups) {
      const { batch_number, group_id, user_id, group_endtime, message_time } = group
      if (message_time && message_time == hour) {
        logger.info({
          msg: `${hour}小时内已推送过消息:${JSON.stringify(group)}`
        })
        continue
      }
      const upMessageData = await sdkInstance.middleware.mysql.update(
        config.dbName,
        'UPDATE middle_group SET message_time=?,  update_time=? WHERE is_delete=0 AND group_id=?',
        [hour, time, group_id]
      )
      logger.info({
        msg: `修改团队消息推送时间-中间表:${batch_number}, ${hour}小时`
      })
      /* 如果错误，抛出错误 */
      if (upMessageData.result !== 'ok') {
        logger.info({ msg: `更新团队消息推送时间失败：${JSON.stringify(group)}` })
      }
      const getUrl = `${config.domain}/c/ACCOUNTHNZB/api/v1/message/push?userId=${user_id}&batch_number=${batch_number}&group_endtime=${group_endtime}&endTime=${hour}`
      const messageResult: any = await axios.get(getUrl)
      logger.info(`messageResult消息推送结果: ${JSON.stringify(messageResult.data)}`)
    }
  }
}