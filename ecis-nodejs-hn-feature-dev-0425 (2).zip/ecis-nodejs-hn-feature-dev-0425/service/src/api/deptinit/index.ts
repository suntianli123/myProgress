import { Context } from 'koa'
import axios from 'axios'
import config from '../../config'
// import sdkInstance from '../../util/sdk'
import { sdkInstance } from '../../grpc/sdk'
import { resJson, resErrJson } from '../../util/msgCode'
import { arrToTree, deptMapping } from '../../util/index'
import { totalDeptSync } from './totalDept'
import { logger } from '../../server'
import { getDataTotal } from '../../model/openApi/third'
const moment = require('moment')

/**
 * @path /api/userinfo
 * @param {object} Context
 * @returns {object}
 */
export async function deptSyncTotal(ctx: Context) {
  let res
  try {
    /* 部门信息 */
    // const deptData: any = await getDataTotal('/service-interfaces/api/syncOrganization/getOrganizationsAll')
    const deptData: any = (await axios.get('http://172.21.131.102:3000/mock/11/WPS/dept_hnzb')).data
    if (!deptData.length) {
      throw resErrJson({ msg: '获取三方部门数据失败。' })
    }
    const deptList = await deptMapping(deptData, {
      departmentId: 'companyId',
      parentId: 'parent_company_id',
      department: 'companyName',
      order: 'tree_index',
      // 状态（0：启用 1：停用 2：禁用 3：锁定）
      disable: 'STATUS',
      // 删除标志（101：未删除 102:已删除）
      status: 'del_flag'
    })
    const deptFilter = deptList.filter(
      dept =>
        dept.status !== '102' &&
        !(dept.disable === '1' || dept.disable === '2' || dept.disable === '3')
    )

    const depts = await arrToTree(deptFilter)

    // /* 全量同步部门 */
    await totalDeptSync(depts, deptFilter)
    res = resJson()
  } catch (e) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(e)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  /* 加密返回数据 */
  ctx.body = res
  // ctx.body = aesEncryption(res)
  return ctx
}
