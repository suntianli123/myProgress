import { Context } from "koa";
import { batchThirdBindDepts } from "../../model/openApi/company";
import { getCompanyToken } from "../authToken/func";
import { logger } from "../../ins";
import { getDecrypt } from "../../util/utils";
import { sdkInstance } from "../../grpc/sdk";
import { encryptUserId, getCompUsers } from "../user";
import config from "../../config";
import { resErrJson, resJson } from "../../util/msgCode";
import moment = require("moment");

export async function messagePush(ctx: Context) {
  let res: any = ''
  try {
    const { userId, batch_number, endTime } = ctx.query


    /** 获取企业token */
    const companyToken = await getCompanyToken()
    const params: any = {
      status: 'active',
      third_union_ids: userId
    }
    // 批量通过third_union_id查询企业成员
    const thirduserData = await batchThirdBindDepts(companyToken, params)
    logger.info({
      msg: '批量通过third_union_id查询企业成员',
      thirduserData
    })
    if (thirduserData.result != 0) throw new Error("三方用户id不存在");

    // 获取开放平台用户id
    const company_uid = thirduserData.data.company_users[0].company_uid

    // 通过开放平台用户id获取云文档id
    const comp_uid = await getDecrypt(company_uid)
    logger.info({
      msg: '通过开放平台用户id获取云文档comp_uid',
      comp_uid
    })
    // 获取企业用户信息
    const userData = await getCompUsers(comp_uid)
    // const endTime:any = moment(end_time).add(Number(group_endtime),'hours').format('YYYY-MM-DD HH:mm:ss')
    const msgData: any = {
      "uid": `${userData.userid}`,
      "template": {
        "msgbox": {
          "title": `${batch_number}团队`,
          "desc": `您的团队将在 ${endTime} 小时后解散，请及时处理团队文档` // 您的团队将于: ${} 解散，请及时处理团队文件及相关数据
        }
      },
      "event": {
        "type": "app_msg_create",
        "data": {
          "avatar": [
            "https://qn.cache.wpscdn.cn/kdocs/cloud/icon/wps+.png"
          ],
          "file_name": "" // batch_number
        }
      }
    }

    const msgPushData = await sdkInstance.service.msgCenter.pushMsg(msgData)
    logger.info({
      msg: '消息推送结果',
      msgPushData
    })
    if (msgPushData.result == 'ok') {
      res = resJson({ msg: '消息推送成功' })
    } else {
      res = resErrJson({ msg: '消息推送失败' })
    }

  } catch (error) {
    const msg = error.message || error.msg
    res = resErrJson({ msg: '消息推送失败', data: msg, result: 'error' })
  }

  ctx.body = res
  ctx.status = 200
  return ctx
}

// 判断团队是否为招标团队
export async function groupType(ctx: Context) {
  let res: any
  try {
    const id = ctx.query.id
    // 加密团队id
    const groupId = await encryptUserId(`${id}`)
    // 获取中间表所有用户
    const SQLResultGroup: any = await sdkInstance.middleware.mysql.select(
      config.dbName,
      'SELECT * FROM middle_group WHERE is_delete=0 AND group_id = ?',
      [groupId]
    )
    logger.info({
      msg: '查询数据库结果',
      SQLResultGroup
    })
    /* 返回结果判断 */
    if (SQLResultGroup.result !== 'ok') throw Error('查询团队中间表失败。')
    const GroupData: any =
      SQLResultGroup.data &&
        SQLResultGroup.data.rows &&
        Array.isArray(SQLResultGroup.data.rows)
        ? SQLResultGroup.data.rows
        : []
    if (GroupData.length) {
      res = {
        msg: '该团队是招标团队',
        code: 0
      }
    } else {
      res = {
        msg: '该团队不是招标团队',
        code: 1
      }
    }
  } catch (error) {
    const msg = error.message || error.msg
    res = resErrJson({ msg: '查询团队失败', data: msg, code: 1 })
  }
  // 0： 招标团队 1：普通团队
  ctx.body = res
  ctx.status = 200
  return ctx
}