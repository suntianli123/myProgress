import { Context } from 'koa'
import config from '../../config'
import { resErrJson } from '../../util/msgCode'
import axios from 'axios'
import { logger } from '../../server'
import { accessTokenToUser, codeToAccessToken } from '../../model/openApi/third'

/**
 * @path     /api/v1/authorization/redirectToWps
 * @param    {object} Context
 * @returns  {object}
 */
export async function redirectToWps(ctx: Context) {
  logger.info({ message: `redirectToWps参数:${JSON.stringify(ctx.query)}` })
  const { code, redirect_uri } = ctx.query
  let url
  const redirectUriSet: any = redirect_uri
  logger.info({ message: `redirectUri参数:${redirectUriSet}` })
  if (code) {
    ctx.cookies.set('wps_sid', undefined)
    let cb: string = `${config.domain}/kdocs`
    cb = ctx.cookies.get('REDIRECT_URI') ? ctx.cookies.get('REDIRECT_URI') : cb
    const redirectUri: string =
      `${config.domain}/oauth-svr/oauth/v1/code?app_id=${config.appID}&is_platform_code_signin=true&cb=${encodeURIComponent(cb)}`
    const state = ctx.cookies.get('_WPS_OAUTH_STATE_') || ctx.query._WPS_OAUTH_STATE_ || new Date().getTime()
    ctx.cookies.set('_WPS_OAUTH_STATE_', `${state}`)
    url = redirectUri + '&state=' + state + '&code=' + code
    logger.info({ message: `redirectToWps跳转前:${url}` })
  } else {
    let cb
    const splitArr = redirectUriSet ? redirectUriSet.split('cb=') : []
    if (splitArr.length && splitArr.length >= 2) {
      cb = splitArr[1].split('&is_platform')[0]
    }
    ctx.cookies.set('REDIRECT_URI', (cb ? decodeURIComponent(cb.toString()) : undefined))
    // wps-跳转到-第三方登录页面
    const toWpsUrl = `${config.domain}/c/${config.cid}/${config.appid}/api/v1/authorization/redirectToWps`
    const state = ctx.cookies.get('_WPS_OAUTH_STATE_') || ctx.query._WPS_OAUTH_STATE_ || new Date().getTime()
    // 三方地址-具体根据三方接口修改
    url = `${config.third.domain}/service-portal/login?redirect=${toWpsUrl}&state=${state}`

    logger.info({ message: `wps-跳转到-第三方登录页面:${url}` })
  }
  // 重定向
  ctx.status = 302
  ctx.redirect(url)
}

/**
 * @path     /api/v1/authorization/callback
 * @param   {object} Context
 * @returns {object}
 */
export async function callback(ctx: Context) {
  let res
  try {
    logger.info({ message: `callback参数:${JSON.stringify(ctx.query)}` })
    const { code, redirect_uri } = ctx.query

    const result = await codeToAccessToken(`${code}`)
    // logger.info({ message: `result:${JSON.stringify(result)}` })

    logger.info({ message: `access_token result:${JSON.stringify(result)}` })
    // const result = resData.data

    const body = {
      access_token: result.data,
    }
    res = body
  } catch (e) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(e)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  ctx.body = res
  return ctx
}

/**
 * @path     /api/v1/authorization/userInfo
 * @param    {object} Context
 * @returns  {object}
 */
export async function userInfo(ctx: Context) {
  let res
  try {
    logger.info({ message: `userInfo参数:${JSON.stringify(ctx.query)}` })
    const { access_token } = ctx.query

    const resData: any = await accessTokenToUser(`${access_token}`)
    // logger.info({ message: `userInfo返回数据:${JSON.stringify(userInfo)}` })

    logger.info({ message: `userInfo result: ${JSON.stringify(resData)}` })
    const result = resData.data

    res = {
      access_token,
      user_name: result.userName,
      union_id: `${result.accountId}`
    }
    logger.info({ message: `body返回数据:${JSON.stringify(res)}` })
  } catch (e) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(e)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  ctx.body = res
  return ctx
}
