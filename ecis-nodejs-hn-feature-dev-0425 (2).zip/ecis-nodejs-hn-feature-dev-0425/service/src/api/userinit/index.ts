import { Context } from 'koa'
import axios from 'axios'
import config from '../../config'
// import sdkInstance from '../../util/sdk'
import { sdkInstance } from '../../grpc/sdk'
import { resJson, resErrJson } from '../../util/msgCode'
import { totalUserSync } from './totalUser'
import { userMap } from '../../util/index'
import { logger } from '../../server'
import { getSQLSelResult } from '../common'
import { getDataTotal } from '../../model/openApi/third'
import { OpenGetIdConfuseParams } from '../../../ecissdk/model/data'

const moment = require('moment')

/**
 * @path /api/userinfo
 * @param {object} Context
 * @returns {object}
 */
export async function userSyncTotal(ctx: Context) {
  let res
  try {
    /* 客户接口 - start */
    // const [userHN, userGYS, userZJ, userOrgs] = await Promise.all([
    //   getDataTotal('/service-interfaces/api/syncBidding/getStaffs'),
    //   getDataTotal('/service-interfaces/api/syncSupplier/getSupplierUsers'),
    //   getDataTotal('/service-interfaces/api/syncExpert/getExperts'),
    //   getDataTotal('/service-interfaces/api/syncOrgUser/relation')
    // ])
    // const userData = [...userHN, ...userGYS, ...userZJ]
    /* 客户接口 - end */

    /* 本地mock - start */
    const [userResult, userOrgResult] = await Promise.all([
      axios.get('http://172.21.131.102:3000/mock/11/WPS/user_hnzb'),
      axios.get('http://172.21.131.102:3000/mock/11/WPS/user_dept_hnzb')
    ])
    const userData: any[] = userResult.data
    const userOrgs: any[] = userOrgResult.data
    /* 本地mock - end */

    userData.forEach(user => {
      user.companyList = userOrgs.filter(
        userOrg => user.accountId === userOrg.accountId
      )
    })
    if (!userData.length) {
      throw resErrJson({ msg: '获取三方用户数据失败。' })
    }
    const users = await getUserFormat(userData)
    await totalUserSync(users)
    res = resJson()
  } catch (e) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(e)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  /* 加密返回数据 */
  ctx.body = res
  // ctx.body = aesEncryption(res)
  return ctx
}

/**
 *
 * @returns 中间表的全量部门数据
 */
export async function getAllDeptFromDB(): Promise<any[]> {
  const SQLResult = await sdkInstance.middleware.mysql.select(
    config.dbName,
    'SELECT * FROM middle_dept',
    []
  )
  return await getSQLSelResult(SQLResult)
}

async function getUserFormat(userList: any) {
  const sqlDeptList = await getAllDeptFromDB()
  for (const user of userList) {
    if (user.companyList.length) {
      const dept = []
      for (const group of user.companyList) {
        const deptTemp = sqlDeptList.filter(
          (sqlDept: any) => group.companyId === sqlDept.ori_dept_id
        )
        if (deptTemp.length !== 0) {
          for (const deptItem of deptTemp) {
            dept.push({
              ...deptItem,
              departmentId: deptItem.ori_dept_id
            })
          }
          user.dept = dept
        }
      }
    }
  }
  const userData = await userMap(userList, {
    id: 'idCard',
    loginName: 'idCard',
    name: 'name',
    // 锁定状态：默认101未锁定，102已锁定
    // disable: 'lockStatus',
    // 停用启动状态：默认101停用，102启用
    // status: 'status',
    dept: 'dept'
  })
  return userData
}

/**
 *
 * @returns 中间表的全量用户部门关系
 */
export async function getAllUserDeptFromDB(): Promise<any[]> {
  const deptCount: any = await sdkInstance.middleware.mysql.select(
    config.dbName,
    'SELECT count(0) FROM middle_user_dept WHERE is_delete=0',
    []
  )
  logger.info({ deptCount: `中间表部门数量：${JSON.stringify(deptCount)}` })
  let count: any = await getSQLSelResult(deptCount)
  count = count[0] && count[0]['count(0)']
  let SQLDeptList = []
  if (count < 8000) {
    const SQLResult: any = await sdkInstance.middleware.mysql.select(
      config.dbName,
      'SELECT * FROM middle_user_dept WHERE is_delete=0',
      []
    )
    SQLDeptList = await getSQLSelResult(SQLResult)
  } else {
    let temp: any[] = []
    const size = 8000
    for (let page = 0; page < count / size; page++) {
      const SQLResult = await sdkInstance.middleware.mysql.select(
        config.dbName,
        'SELECT * FROM middle_user_dept WHERE is_delete=0 LIMIT ?,?',
        [page * size, size]
      )
      temp = await getSQLSelResult(SQLResult)
      SQLDeptList.push(...temp)
      temp = []
    }
  }
  return SQLDeptList
}

export const getIdConfuse = async (ctx: Context) => {
  let res
  try {
    const userId = ctx.query.userId || ''
    if (!userId) {
      throw Error('id不能为空')
    }
    const params: OpenGetIdConfuseParams = {
      queryStr: `raw_text=${userId}`
    }
    // 加密comp_uid获得company_uid
    const result = await sdkInstance.service.wpsopen.getIdConfuse(params)
    if (
      result &&
      result.result === 'ok' &&
      result.data &&
      result.data.confuse_result
    ) {
      res = result
    } else {
      logger.warn(`加密用户ID失败! ${userId} errMsg: ${result.msg}`)
      throw Error(JSON.stringify(result))
    }
  } catch (error) {
    console.log(error)
    logger.error(`加密用户id失败, ${JSON.stringify(error)}`)
    res = resErrJson({ msg: '加密用户id失败' })
  }
  ctx.status = 200
  ctx.body = res
}

export const getUserOpenId = async (id: string) => {
  let res = ''
  const params: OpenGetIdConfuseParams = {
    queryStr: `raw_text=${id}`
  }
  // 加密comp_uid获得company_uid
  const result = await sdkInstance.service.wpsopen.getIdConfuse(params)
  if (
    result &&
    result.result === 'ok' &&
    result.data &&
    result.data.confuse_result
  ) {
    res = result.data.confuse_result
  }
  return res
}
