import { Context } from 'koa'
import axios from 'axios'
import config from '../../config'
// import sdkInstance from '../../util/sdk'
import { sdkInstance } from '../../grpc/sdk'
import { resJson, resErrJson } from '../../util/msgCode'
import { handleUserSync } from './user'
import { userMap } from '../../util/index'
import { logger } from '../../server'
import { getSQLSelResult } from '../common'
import { handleGroupChange, handleGroupNotice } from '../group'
import {
  GetCompUsersParams,
  OpenGetIdConfuseParams
} from '../../../ecissdk/model/data'
import { batchGetCompanyUsers } from '../../model/openApi/company'
import { getCompanyToken } from '../authToken/func'
import request from '../../util/request'
import { getCompanyRootDepts } from '../dept/dept'
import { API } from '../../model/openApi/company/typings'
import { currentTime } from '../../util/momentTime'

const https = require('https')

const agent = new https.Agent({
  rejectUnauthorized: false,
  insecureHTTPParser: true
})

/* 评标信息同步入参 */
interface BatchInfoNotice {
  [key: string]: string
  // BatchNumber: string // 批次号
  // JuryName: string // 评委会名称
  // JuryNum: number // 评委会总人数
  // BidExpertNum: number // 评标专家人数
  // JuryBidNum: number // 招标人代表数
  // ContactMan: string // 联系人 - 牵头项目经理
  // ContactTel: string // 联系电话 - 牵头项目经理
  // CompanyIDCard: string // 项目经理身份证号码
  // CompanyId: string // 所在单位Id 1-华能招标有限公司；254-华能能源交通产业控股有限公司；2-中国华能集团有限公司北京招标分公司；
  // Company: string // 所在单位名称
  // BidStartDate: string // 评标开始时间
  // BidEndDate: string // 评标结束时间
  // BidAddress: string // 评标地点
  // Remarks: string // 备注
}

/* 变更通知入参 */
interface BatchInfoChange {
  [key: string]: string
  // BatchNumber: string // 批次号
  // SerialNumber: string // 状态 抽取成功-1；有变更-2
}

/* 评标专家/招标人详细信息 */
interface BatchInfoDetail {
  [key: string]: any
  // BatchNumber: string // 批次号
  // JuryName: string // 评委会名称
  // JuryNum: number // 评委会总人数
  // BidExpertNum: number // 评标专家人数
  // JuryBidNum: number // 招标人代表数
  // ContactMan: string // 联系人 - 牵头项目经理
  // ContactTel: string // 联系电话 - 牵头项目经理
  // CompanyIDCard: string // 项目经理身份证号码
  // CompanyId: string // 所在单位Id 1-华能招标有限公司；254-华能能源交通产业控股有限公司；2-中国华能集团有限公司北京招标分公司；
  // Company: string // 所在单位名称
  // BidStartDate: string // 评标开始时间
  // BidEndDate: string // 评标结束时间
  // BidAddress: string // 评标地点
  // Remarks: string // 备注
  // 评标专家(招标人代表)信息
  // [key: string]: Array<{
  //   IDCard: string // 专家(招标人代表)身份证号码
  //   Name: string // 专家(招标人代表)名称
  //   Age: number // 专家(招标人代表)年龄
  //   MobilePhone: string // 专家(招标人代表)手机号码
  // }>
}

interface MemberResult {
  members: Array<{
    id: number
    email: string
    comp_id: number
    comp_uid: string
    company_uid?: string
    department: string
    phone: string
    status: string
    name: string
    role: number
    avatar: string
    dept_path: string
    highlight: {
      user_name: Array<string>
    }
    mtime: number
  }>
  result: string
  total: number
}

/* 根据身份证号判断专家和招标人代表 */
const _IDRe18 =
  /^([1-6][1-9]|50)\d{4}(18|19|20)\d{2}((0[1-9])|10|11|12)(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/
const _IDre15 =
  /^([1-6][1-9]|50)\d{4}\d{2}((0[1-9])|10|11|12)(([0-2][1-9])|10|20|30|31)\d{3}$/
// 无权限-校验规则
const noPermissionReg = [_IDRe18, _IDre15]
// 有权限-校验规则 TODO
const permissionReg = [_IDRe18, _IDre15]

/**
 * @path /batchNotice
 * @param {object} Context
 * @returns {object}
 */
export async function batchNotice(ctx: Context) {
  let res
  try {
    logger.info(`ctx: ${JSON.stringify(ctx)}`)
    const batchPath = config.data.batchPath
    logger.info(`创建团队入参: ${JSON.stringify(ctx.request.body)}`)
    const batchInfo: BatchInfoNotice =
      getDataByPath(batchPath, ctx) || ctx.request.body

    await handleSyncByBatchNotice(batchInfo)
    res = resJson()
  } catch (e) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(e)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  /* 加密返回数据 */
  ctx.body = res
  // ctx.body = aesEncryption(res)
  return ctx
}

const handleSyncByBatchNotice = async (batchInfo: BatchInfoNotice) => {
  logger.info(`keys: ${JSON.stringify(config.data.keys)}`)
  const { batchNumberKey, IDCardKey, startTimeKey, endTimeKey } =
    config.data.keys
  const batchNumber = batchInfo[batchNumberKey]
  const IDCard = batchInfo[IDCardKey]
  const startTime = batchInfo[startTimeKey]
  const endTime = batchInfo[endTimeKey]
  if (!batchNumber) throw resErrJson('获取批次号失败')
  if (!IDCard) throw resErrJson('项目经理身份证号码失败')
  if (!startTime) throw resErrJson('评标开始时间失败')
  if (!endTime) throw resErrJson('评标结束时间失败')
  const batchInfoInput = {
    batchNumber,
    IDCard,
    startTime,
    endTime
  }
  logger.info(`create group info: ${JSON.stringify(batchInfoInput)}`)
  await handleGroupNotice(batchInfoInput)
}

/**
 * @path /batchChange
 * @param {object} Context
 * @returns {object}
 */
export async function batchChange(ctx: Context) {
  let res
  try {
    logger.info(`ctx: ${JSON.stringify(ctx)}`)
    logger.info(`修改团队入参: ${JSON.stringify(ctx.request.body)}`)
    await handleSyncByBatchChange(ctx)
    res = resJson()
  } catch (e) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(e)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  /* 加密返回数据 */
  ctx.body = res
  // ctx.body = aesEncryption(res)
  return ctx
}

/**
 * @path /pullMemberByGroupId
 * @param {object} Context
 * @returns {object}
 */
export async function pullMemberByGroupId(ctx: Context) {
  let res
  try {
    // logger.info(`ctx: ${JSON.stringify(ctx)}`)
    const { group_id } = ctx.query

    const batchNumber = await getBatchById(`${group_id}`)
    const {
      keys: { batchNumberKey }
    } = config.data
    const body: BatchInfoChange = {}
    body[batchNumberKey] = batchNumber
    ctx.request.body = body
    await handleSyncByBatchChange(ctx)
    res = resJson()
  } catch (e) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(e)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  /* 加密返回数据 */
  ctx.body = res
  // ctx.body = aesEncryption(res)
  return ctx
}

/**
 * @path /removeMiddleGroup
 * @param {object} Context
 * @returns {object}
 */
export const removeMiddleGroup = async (ctx: Context) => {
  let res
  try {
    const { group_id } = ctx.params
    const groupId = await encryptUserId(group_id)
    const time = currentTime()
    const removeSQLResult = await sdkInstance.middleware.mysql.update(
      config.dbName,
      'UPDATE middle_group SET is_delete = 1, update_time = ? WHERE group_id = ?',
      [time, groupId]
    )
    if (removeSQLResult.result !== 'ok') {
      throw resErrJson({
        msg: `中间表团队移除失败, ${JSON.stringify(removeSQLResult)}`
      })
    }
    res = resJson()
  } catch (e) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(e)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  /* 加密返回数据 */
  ctx.body = res
  // ctx.body = aesEncryption(res)
  return ctx
}

/**
 * @path /getGroupFromMiddle
 * @param {object} Context
 * @returns {object}
 */
export const getGroupFromMiddle = async (ctx: Context) => {
  let res
  try {
    const { group_id } = ctx.query
    const groupId = await encryptUserId(`${group_id}`)
    const groupSQLResult = await sdkInstance.middleware.mysql.select(
      config.dbName,
      'SELECT * FROM middle_group WHERE group_id = ? AND is_delete = 0',
      [groupId]
    )
    if (groupSQLResult.result !== 'ok') {
      throw resErrJson({
        msg: `中间表团队移除失败, ${JSON.stringify(groupSQLResult)}`
      })
    }
    const data = await getSQLSelResult(groupSQLResult)
    res = {
      code: '1000',
      group: data.length > 0 ? '0' : '1'
    }
  } catch (e) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(e)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  /* 加密返回数据 */
  ctx.body = res
  // ctx.body = aesEncryption(res)
  return ctx
}

const handleSyncByBatchChange = async (ctx: Context) => {
  logger.info(`keys: ${JSON.stringify(config.data.keys)}`)
  const {
    keys: { batchNumberKey, IDCardKey, startTimeKey, endTimeKey },
    batchPath,
    detailPath,
    detailBidExpertPath,
    detailJuryBidPath
  } = config.data
  const batchInfo: BatchInfoChange =
    getDataByPath(batchPath, ctx) || ctx.request.body
  const batchNumber = batchInfo[batchNumberKey]
  // const batchNumber: any = ctx.query.BatchNumber
  if (!batchNumber) throw resErrJson('获取批次号失败')
  // const encode = Buffer.from(`${batchNumber}`).toString('base64')
  // const { getThirdInfo, thirdInfoMethod } = config.URL

  const bodyParam = {
    batchNumber: batchNumber
  }
  logger.info(`domain: ${config.domain}, body: ${JSON.stringify(bodyParam)}`)
  const userResult: any = await axios.post(`${config.domain}/c/accounthnzbch/api/hnzb/notice_data`, bodyParam, {
    headers: {
      'Content-Type': 'application/json'
    }
  })


  // const userResult: any = await axios.post('https://api.jczxw.cn/mock/11/wps/user_hnzb')

  logger.info(`userResultjava结果: ${JSON.stringify(userResult.data)}`)

  if (!userResult?.data || !userResult?.data?.data) {
    throw resErrJson('通过批次号获取信息失败')
  }
  const batchInfoDetail: BatchInfoDetail = getDataByPath(
    detailPath,
    userResult.data
  )
  const IDCard = batchInfoDetail.companyIDCard
  const startTime = batchInfoDetail.bidStartDate
  const endTime = batchInfoDetail.bidEndDate
  logger.info(`IDCard: ${IDCard},startTime: ${startTime},endTime: ${endTime}`)
  // 专家信息
  const bidExpertData: Array<{
    [key: string]: string
  }> = Array.isArray(batchInfoDetail[detailBidExpertPath])
    ? batchInfoDetail[detailBidExpertPath]
    : []
  // 招标人代表信息
  const juryBidData: Array<{
    [key: string]: string
  }> = Array.isArray(batchInfoDetail[detailJuryBidPath])
    ? batchInfoDetail[detailJuryBidPath]
    : []
  const userData = bidExpertData
    .map(data => ({
      isExpert: '1', // 评标人专家
      ...data
    }))
    .concat(
      juryBidData.map(data => ({
        isExpert: '0', // 评标人代表
        ...data
      }))
    )
  if (!userData || !userData.length) {
    throw resErrJson({ msg: '获取评标专家及招标人失败。' })
  }
  const users = await getUserFormat(userData)
  await handleUserSync(users)
  await handleGroupChange({
    batchNumber,
    IDCard,
    startTime,
    endTime,
    users
  })
}

/**
 *
 * @returns 中间表的全量部门数据
 */
export async function getAllDeptFromDB(): Promise<any[]> {
  const SQLResult = await sdkInstance.middleware.mysql.select(
    config.dbName,
    'SELECT * FROM middle_dept',
    []
  )
  return await getSQLSelResult(SQLResult)
}

async function getUserFormat(userList: any): Promise<
  Array<{
    id: string
    loginName: string
    name: string
    dept: Array<{
      dept_id: string
    }>
  }>
> {
  const rootId = await getCompanyRootDepts()
  for (const user of userList) {
    // 区分专家和招标人代表的条件
    const deptId =
      user.isExpert === '1'
        ? config.department.expertDept
        : user.isExpert === '0'
          ? config.department.juryDept
          : rootId
    user.dept = [
      {
        dept_id: deptId
      }
    ]
  }
  const { id, name } = config.data.memberKeys
  const userData = await userMap(userList, {
    id,
    loginName: id,
    name,
    // 锁定状态：默认101未锁定，102已锁定
    // disable: 'lockStatus',
    // 停用启动状态：默认101停用，102启用
    // status: 'status',
    dept: 'dept'
  })
  return userData
}

const getDataByPath = (target: string, source: any): any =>
  target.split('.').reduce((prev, next) => {
    prev = prev[next]
    return prev
  }, source)

export const getUserInfoById = async (ctx: Context) => {
  let res
  try {
    const { comp_uid: compUid } = ctx.query
    if (!compUid) {
      throw resErrJson('用户id为空')
    }
    const userInfo = await getInfoById(`${compUid}`)
    const { companyUid } = userInfo
    const companyToken = await getCompanyToken(true)
    // const userMiddleInfo = await getUserMiddleByCompanyUid(companyUid)
    const companyUser = await batchGetCompanyUsers(
      companyToken,
      companyUid,
      'active,notactive,disabled'
    )
    if (!companyUser.company_users.length) {
      logger.warn('根据companyUid未获取到用户信息')
    }
    // 新建团队权限 0-有权限 1-无权限
    // const permission = permissionCheck(companyUser.company_users[0].third_union_id)
    const permission = permissionCheck(companyUser.company_users)
    res = {
      permission
    }
    // res = resJson()
  } catch (e) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(e)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  /* 加密返回数据 */
  ctx.body = res
  // ctx.body = aesEncryption(res)
  return ctx
}

const getInfoById = async (compUid: string) => {
  // const compUserInfo = await getCompUsers(userId)
  // const compUid = compUserInfo.comp_uid
  const companyUid = await encryptUserId(compUid)
  return {
    compUid,
    companyUid
  }
}

const getBatchById = async (id: string) => {
  const groupId = await encryptUserId(id)
  const middleGroup = await getGroupById(groupId)
  return (middleGroup && middleGroup.batch_number) || ''
}

/**
 * 获取用户信息
 * @param userId
 * @param compId
 */
export const getCompUsers = async (comp_uid: string) => {
  const params: GetCompUsersParams = {
    path: {
      comp_id: config.compId
    },
    queryStr: `comp_uid=${comp_uid}&status=1`
  }
  logger.info({
    msg: '请求参数',
    comp_uid,
    comp_id: config.compId
  })
  const result = await sdkInstance.service.dev.wpsplus.getCompUsers(params)

  logger.info({
    msg: 'getCompUsers接口返回结果',
    result
  })

  if (result && result.result === 'ok') {
    if (result.data && result.data.users && result.data.users.length > 0) {
      return result.data.users[0]
    } else {
      throw new Error(
        `根据compId:${config.compId},comp_uid:${comp_uid} 未查询到相关用户!`
      )
    }
  } else {
    throw new Error('获取用户信息失败!' + result.msg)
  }
}

export const getUserDataMsg = async(userId:any) => {
  try {
    if (!userId) {
      throw Error('id不能为空')
    }
      const SQLResult = await sdkInstance.middleware.mysql.select(
        config.dbName,
        'SELECT * FROM middle_users WHERE is_delete !=1 AND company_uid=?',
        [userId]
      )
      const userMiddle = await getSQLSelResult(SQLResult)
      if (userMiddle && userMiddle.length > 0) {
        return {
          result: '1',
          msg: '存在部门中',
          company_uid: userId,
          userInfo: userMiddle
        }
      } else {
        return {
          result: '0',
          msg: '不在部门中',
          company_uid: userId
        }
      }
  } catch (error) {
    console.log(error)
    logger.error(`加密用户id失败, ${JSON.stringify(error)}`)
    throw Error('查询用户部门失败')
  }
}

/**
 * 加密用户ID
 * @param userId
 */
export async function encryptUserId(compUid: string) {
  const params: OpenGetIdConfuseParams = {
    queryStr: `raw_text=${compUid}`
  }
  const result = await sdkInstance.service.wpsopen.getIdConfuse(params)
  logger.info({
    msg: '加密结果:',
    compUid,
    result
  })
  if (
    result &&
    result.result === 'ok' &&
    result.data &&
    result.data.confuse_result
  ) {
    return result.data.confuse_result
  } else {
    throw new Error(`加密用户或部门ID：${compUid}失败!${result.msg}`)
  }
}

// export const encryptUserId = async (id: string): Promise<any> => {
//   const result = await request.get(`/c/ACCOUNTHNZB/api/v1/getIdConfuse?userId=${id}`)
//   return result.data.confuse_result
// }

const getUserMiddleByCompanyUid = async (companyUid: string) => {
  const middleInfoResult = await sdkInstance.middleware.mysql.select(
    config.dbName,
    'SELECT * FROM middle_users WHERE company_uid = ?',
    [companyUid]
  )
  const userMiddle = await getSQLSelResult(middleInfoResult)
  return userMiddle[0]
}

const getGroupById = async (groupId: string) => {
  const middleInfoResult = await sdkInstance.middleware.mysql.select(
    config.dbName,
    'SELECT * FROM middle_group WHERE group_id = ?',
    [groupId]
  )
  const groupMiddle = await getSQLSelResult(middleInfoResult)
  return groupMiddle[0]
}

/* const permissionCheck = (thirdUnionId: string) => {
  // 新建团队权限 0-有权限 1-无权限
  let hasPermission = '0'
  if (thirdUnionId) {
    if (noPermissionReg.some(reg => reg.test(thirdUnionId))) {
      logger.info(`changed permission by regexp, ${thirdUnionId}`)
      hasPermission = '1'
    }
  }
  return hasPermission
} */

const permissionCheck = (companyUsers: API.CompanyUsers) => {
  // 新建团队权限 0-有权限 1-无权限
  let hasPermission = '1'
  if (companyUsers.length && companyUsers[0].alias_name) {
    const aliasName = companyUsers[0].alias_name
    if (permissionReg.some(reg => reg.test(aliasName))) {
      logger.info(
        `changed permission by regexp, ${companyUsers[0].name}-${aliasName}`
      )
      hasPermission = '0'
      // 超管
    } else if (companyUsers[0].role_id === 1) {
      hasPermission = '0'
    }
  }
  return hasPermission
}

export const searchMap = async (ctx: Context) => {
  const params = ctx.query
  const companyId = ctx.params.company_id
  const memberResult: MemberResult = await request.get(
    `${config.URL.driveRoute}/api/v3/search/company/${companyId}/members`,
    {
      params,
      headers: {
        cookie: ctx.request.header.cookie,
        delWpsSign: true
      }
    }
  )
  logger.info({
    type: 'get接口返回结果',
    data: memberResult,
  })
  if (memberResult.result === 'ok') {
    try {
      const expertDept = config.department.expertDept
      const juryDept = config.department.juryDept
      const searchShowList = [expertDept, juryDept]
      const companyToken = await getCompanyToken()
      const members = (memberResult && memberResult.members) || []
      const companyUids = []
      for (const member of members) {
        if (member?.avatar && !member?.avatar?.includes(config.domain)) {
          member.avatar = `${config.domain}/avatar${member.avatar}`
        }
        const companyUid = await encryptUserId(member.comp_uid)
        logger.info({
          type: 'companyUid接口返回结果',
          data: companyUid,
        })
        member.company_uid = companyUid
        if (companyUid) {
          companyUids.push(companyUid)
        }
      }
      const { result, company_users } = await batchGetCompanyUsers(
        companyToken,
        companyUids.join(),
        'active,notactive,disabled'
      )
      logger.info({
        type: 'company_users接口返回结果',
        data: company_users,
      })
      memberResult.members = members
        .map(member => {
          let {
            name,
            company_uid,
            highlight: { user_name }
          } = member
          const userInfo = company_users.find(
            user => user.company_uid === company_uid
          )
          const thirdUnionId = userInfo?.third_union_id || ''
          const depts = userInfo.depts
          logger.info({
            type: 'depts处理结果',
            data: depts,
          })
          if (depts.some(d => d.id === expertDept || d.id === juryDept)) {
            name = `${name} ${thirdUnionId.slice(0, 6)}****${thirdUnionId.slice(
              thirdUnionId.length - 4,
              thirdUnionId.length
            )}`
            user_name[user_name.length - 1] = `${
              user_name[user_name.length - 1]
            } ${name.split(' ')[1]}`
          }
          logger.info({
            type: '用户修改完成',
            name: name,
            user_name: user_name
          })
          delete member.company_uid
          return {
            ...member,
            name,
            highlight: {
              ...member.highlight,
              user_name
            },
            depts
          }
        })
        // .filter(member =>
        //   member.depts.some(dept => searchShowList.includes(dept.id))
        // )
      logger.info({
        type: '处理完的数据',
        data: memberResult,
      })
    } catch (error) {
      console.log(error)
      // resErrJson(error)
    }
  }
  ctx.body = memberResult
}
