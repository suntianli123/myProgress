import { Context } from 'koa'
import { resErrJson, sdkCheck, resJson } from '../../util/msgCode'
import { getCompanyRootDepts } from '../dept/dept'
import { getCompanyToken } from '../authToken/func'
import {
  deptsList,
  delDepts,
  getDeptsCompanyUsers,
  batchDeleteCompanyUsers,
  getCompanyUsers,
  companyUsers,
  deptsThirdBind,
  batchActiveDepts,
  batchThirdBindDepts
} from '../../model/openApi/company'
import config from '../../config'
import { logger } from '../../server'
import { getAllDeptUser, getUserAll } from './func'
import { MysqlSelResp } from '../../../ecissdk/model/data'
import { diffData } from '../../util/index'

// import sdkInstance from '../../util/sdk'
import { sdkInstance } from '../../grpc/sdk'
import axios from 'axios'
import request from '../../util/request'

const fs = require('fs')

export async function getCompanyRoot(ctx: Context) {
  const rootId = await getCompanyRootDepts()
  ctx.body = { rootId }
}

export async function addUser(ctx: Context) {
  const rootId = await getCompanyRootDepts()
  /** 获取企业token */
  const companyToken = await getCompanyToken()

  // eslint-disable-next-line camelcase
  const { login_name, password, name, third_union_id, role_id } = ctx.query

  // const userParams = {
  //   login_name: 'CD11111111',
  //   password: 'password',
  //   name: 'kevin',
  //   third_union_id: 'CD11111111',
  //   role_id: 3
  // }

  const userParams: any = {
    login_name,
    password,
    name,
    third_union_id,
    role_id: Number(role_id)
  }

  // 添加用户
  const result = await companyUsers(companyToken, userParams)

  // 激活账号
  // await batchActiveDepts(companyToken, [result.company_uid])

  // const result = await batchThirdBindDepts(companyToken, {
  //   third_union_ids: 'CD11111111'
  // })

  console.log(result)
  ctx.body = { result }
}

/**
 * @path /api/v1/removeAll 测试-删除部门和数据
 * @param {object} Context
 * @returns {object}
 */
export async function removeAll(ctx: Context) {
  let res
  try {
    const rootDeptId = await getCompanyRootDepts()
    /** 递归删除部门-异步 */
    // ctx.query.name 传入根节点下子级部门名称，以删除其所有子部门，且不影响其他部门
    if (ctx.query.name) {
      const deptName = ctx.query.name as string
      const companyToken = await getCompanyToken()
      const { result, depts } = await deptsList(companyToken, rootDeptId, 0, 1000)
      if (result !== 0) throw new Error('获取wps部门列表失败')
      const target = depts.find(item => item.name === deptName)
      if (!target) throw new Error('目标部门不存在')
      res = resJson({ msg: `开始删除${deptName}及子级部门和成员` })
      setTimeout(async () => {
        await removeDeptUserAllByDept(target.dept_id)
        await removeMiddle()
      }, 0)
    } else {
      await removeDeptUserAll(0, rootDeptId)
      res = resJson()
    }
  } catch (e) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(e)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  ctx.body = res
  return ctx
}

/**
 * @name 递归删除所有 部门 用户 部门用户关联
 * @param { string } deptId 部门id
 * @param { string } rootDeptId 根部门id 判断根部门阻止删除
 */
async function removeDeptUserAll(deptId: any, rootDeptId: any) {
  /** 获取企业token */
  const companyToken = await getCompanyToken()
  /** 获取wps部门列表 */
  // @ts-ignore
  const res = await deptsList(companyToken, `${deptId}`, 0, 1000)
  const { result, depts } = res
  if (result !== 0) {
    throw Error('获取wps部门列表失败')
  }
  /* 没有子级 可以删除 */
  if (!depts.length) {
    /* 根部门不可以删除 */
    if (deptId !== rootDeptId) {
      const companyToken = await getCompanyToken()
      /* 获取当前部门下所有用户 */
      const result: any[] = []
      await getDeptUserAll(deptId, -1, result)
      const ids = result.map(el => el.company_uid)
      let offset = 0
      while (offset * 50 < ids.length) {
        await batchDeleteCompanyUsers(
          companyToken,
          ids.slice(offset * 50, (offset + 1) * 50).join()
        )
        logger.info(`删除部门下的用户=${deptId} = ${JSON.stringify(ids)}`)
        offset++
      }
      /** 删除部门 */
      const dept = await delDepts(companyToken, deptId)
      logger.info(`删除部门=${deptId}`)

      /* 递归从顶部开始删除 */
      await removeDeptUserAll(0, rootDeptId)
    } else {
      /** 删除中间表 */
      const delDept = await sdkInstance.middleware.mysql.delete(
        config.dbName,
        'DELETE FROM middle_dept',
        []
      )
      sdkCheck(delDept)
      const delDeptUser = await sdkInstance.middleware.mysql.delete(
        config.dbName,
        'DELETE FROM middle_user_dept',
        []
      )
      sdkCheck(delDeptUser)
      const delUser = await sdkInstance.middleware.mysql.delete(
        config.dbName,
        'DELETE FROM middle_users',
        []
      )
      sdkCheck(delUser)
      logger.info('删除中间表数据')
    }
  } else {
    // 递归查找子级
    for (const itemDep of depts) {
      await removeDeptUserAll(itemDep.dept_id, rootDeptId)
    }
  }
}

async function removeDeptUserAllByDept(deptId: string) {
  /** 获取企业token */
  const companyToken = await getCompanyToken()
  /** 获取wps部门列表 */
  // @ts-ignore
  const res = await deptsList(companyToken, `${deptId}`, 0, 1000)
  const { result, depts } = res
  if (result !== 0) {
    throw Error('获取wps部门列表失败')
  }
  /* 没有子级 可以删除 */
  if (!depts.length) {
    /* 根部门不可以删除 */
    const companyToken = await getCompanyToken()
    /* 获取当前部门下所有用户 */
    const result: any[] = []
    await getDeptUserAll(deptId, -1, result)
    const ids = result.map(el => el.company_uid)
    let offset = 0
    while (offset * 50 < ids.length) {
      await batchDeleteCompanyUsers(
        companyToken,
        ids.slice(offset * 50, (offset + 1) * 50).join()
      )
      logger.info(`删除部门下的用户=${deptId} = ${JSON.stringify(ids)}`)
      offset++
    }
    /** 获取企业token */
    await delDepts(companyToken, deptId)
    logger.info(`删除部门=${deptId}`)
  } else {
    // 递归查找子级
    for (const itemDep of depts) {
      await removeDeptUserAllByDept(itemDep.dept_id)
    }
    await removeDeptUserAllByDept(deptId)
  }
}
/**
 * @name 获取部门下成员
 */
async function getDeptUserAll(deptId: any, offset: number, result: any[]) {
  offset = offset + 1
  /** 获取企业token */
  const companyToken = await getCompanyToken()
  const pageDeptUser = await getDeptsCompanyUsers(
    companyToken,
    deptId,
    offset * 1000,
    1000,
    'active,notactive,disabled'
  )
  if (pageDeptUser.result === 0 && pageDeptUser.company_users.length) {
    result.push(...pageDeptUser.company_users)
    await getDeptUserAll(deptId, offset, result)
  }
}

/**
 * @name 获取全量部门
 */
export async function getAllDept(ctx: Context) {
  let res = {}
  try {
    const rootDeptId = await getCompanyRootDepts()
    const deptList: any = []
    await getAllDeptUser(deptList, rootDeptId)
    console.log(deptList.length)
    const temp = { deptList }
    const data = JSON.stringify(temp)
    res = data
  } catch (e) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(e)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  ctx.body = res
  return ctx
}

/**
 * @name 获取全部成员
 */
export async function getAllUser(ctx: Context) {
  let res = {}
  try {
    const userList: any = []
    await getUserAll(userList, 0)
    const temp = { userList }
    const data = JSON.stringify(temp)
    res = data
  } catch (e) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(e)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  ctx.body = res
  return ctx
}

/**
 * @sqlResult sql查询接口返回信息
 * @return {result} sql结果list
 */

export async function getSQLSelResult(
  sqlResult: MysqlSelResp
): Promise<Array<any>> {
  if (sqlResult.result !== 'ok') logger.error({ msg: JSON.stringify(sqlResult) })
  return sqlResult.data &&
    sqlResult.data.rows &&
    Array.isArray(sqlResult.data.rows)
    ? sqlResult.data.rows
    : []
}

// 移除中间表数据
async function removeMiddle() {
  /** 删除中间表 */
  const delDept = await sdkInstance.middleware.mysql.delete(
    config.dbName,
    'DELETE FROM middle_dept',
    []
  )
  sdkCheck(delDept)
  const delUser = await sdkInstance.middleware.mysql.delete(
    config.dbName,
    'DELETE FROM middle_users',
    []
  )
  sdkCheck(delUser)
  const delDeptUser = await sdkInstance.middleware.mysql.delete(
    config.dbName,
    'DELETE FROM middle_user_dept',
    []
  )
  sdkCheck(delDeptUser)
  logger.info('删除中间表数据')
}

// 获取wps中所有部门信息
export const getAllDeptWPS = async (depts: Array<{
  dept_pid: string // 父部门id
  dept_id: string // 部门id
  name: string // 部门名
  ctime: number // 部门创建时间，秒为单位的时间戳
  order: number | string // 部门排序字段，值越大排序优先级越高
}>, offset = -1) => {
  offset++
  /** 获取企业token */
  const companyToken = await getCompanyToken()
  const deptResult = await deptsList(companyToken, 0, offset * 1000, 1000, true)
  if (Array.isArray(deptResult.depts) && deptResult.depts.length > 0) {
    depts.push(...deptResult.depts)
    await getAllDeptWPS(depts, offset)
  }
  return depts
}

/**
 * 用户：中间表和wps表对比
 * wps数据和中间表数据比对,针对用户在wps后台操作用户表，中间表没有更新
*/
export async function diffAllUser (ctx: Context) {
  let res = {}
  try {
    // 获取wps 所有用户
    const userList: any = []
    await getUserAll(userList, 0)
    console.log(userList.length)
    // 获取中间表所有用户
    const SQLResultAllUser: any = await sdkInstance.middleware.mysql.select(
      config.dbName,
      'SELECT * FROM middle_users WHERE is_delete!=1',
      []
    )
    const users: any =
      SQLResultAllUser.data &&
      SQLResultAllUser.data.rows &&
      Array.isArray(SQLResultAllUser.data.rows)
        ? SQLResultAllUser.data.rows
        : []
    console.log(users.length)
    res = await diffData(users, 'user_id', ['user_id', 'nick_name'], userList, 'third_union_id', ['third_union_id', 'name'])
  } catch (e) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(e)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  ctx.body = res
  return ctx
}

/**
 * 部门：中间表和wps表对比
 * wps数据和中间表数据比对,针对用户在wps后台操作用户表，中间表没有更新
*/
export async function diffAllDept (ctx: Context) {
  let res = {}
  try {
    const rootDeptId = await getCompanyRootDepts()
    const deptList: any = []
    await getAllDeptUser(deptList, rootDeptId)
    console.log(deptList.length)
    // 获取中间表所有部门
    const SQLResultAllDept: any = await sdkInstance.middleware.mysql.select(
      config.dbName,
      'SELECT * FROM middle_dept WHERE is_delete!=1',
      []
    )
    const depts: any =
    SQLResultAllDept.data &&
    SQLResultAllDept.data.rows &&
    Array.isArray(SQLResultAllDept.data.rows)
      ? SQLResultAllDept.data.rows
      : []
    console.log(depts.length)
    res = await diffData(depts, 'dept_id', ['dept_id', 'ori_dept_name', 'dept_id_pid'], deptList, 'dept_id', ['dept_id', 'name', 'dept_pid'])
  } catch (error) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(error)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  ctx.body = res
  return ctx
}

/**
 * 用户：中间表和wps表对比
 * wps数据和中间表数据比对,针对用户在wps后台操作用户表，中间表没有更新
*/
export async function diffAllUserDept (ctx: Context) {
  let res = {}
  try {
    // 获取wps 所有用户
    const userList: any = []
    await getUserAll(userList, 0)
    // 组合用户部门数据
    const tempUserDept: any = []

    for (let i = 0; i < userList.length; i++) {
      const userItem = userList[i]
      // 如果当前人存在部门,再拼装数据
      if (userItem.depts.length && userItem.third_union_id) {
        const t = {
          user_id: userItem.third_union_id,
          company_uid: userItem.company_uid,
          dept_id: '',
        }
        for (let k = 0; k < userItem.depts.length; k++) {
          t.dept_id = userItem.depts[k].id
          tempUserDept.push(t)
        }
      }
    }
    console.log('wps用户和部门关系条数', tempUserDept.length)

    // 获取中间表所有用户
    const SQLResultAllUserDept: any = await sdkInstance.middleware.mysql.select(
      config.dbName,
      'SELECT * FROM middle_user_dept WHERE is_delete!=1',
      []
    )
    const usersDept: any =
      SQLResultAllUserDept.data &&
      SQLResultAllUserDept.data.rows &&
      Array.isArray(SQLResultAllUserDept.data.rows)
        ? SQLResultAllUserDept.data.rows
        : []
    console.log('中间表用户和部门关系条数', usersDept.length)
    res = await diffData(usersDept, 'user_id', ['user_id', 'company_uid', 'dept_id'], tempUserDept, 'user_id', ['user_id', 'company_uid', 'dept_id'])
  } catch (e) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(e)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  ctx.body = res
  return ctx
}

// 取出原始签名
export const getAuthFromHeader = (header: { [key: string]: string }) => {
  const {
    'x-origin': xOrigin,
    'content-type': contentType,
    'content-md5': contentMd5,
    'x-auth': xAuth,
    date
  } = header
  return {
    'x-origin': `${xOrigin}`,
    'content-type': `${contentType}`,
    'content-md5': `${contentMd5}`,
    'x-auth': `${xAuth}`,
    date: `${date}`
  }
}

export function errEventFunc(error: any) {
  logger.info({ msg: 'error返回数据:', error })
  const e = JSON.parse(JSON.stringify(error))
  let body: any = ''
  // eslint-disable-next-line eqeqeq
  if (e.status == 403 && e.code == 'ERR_BAD_REQUEST') {
    logger.info('触发了')
    body = {
      msg: '您的操作权限不足',
      result: 'permissionDenied'
    }
  }
  logger.info({
    msg: '返回的数据为',
    body
  })
  return body
}

// get 请求
export async function handleOtherGetFunc(ctx: Context) {
  const { request: requestInstance, method, url } = ctx
  const { header }: any = requestInstance
  logger.info({
    msg: 'get请求参数为',
    method,
    body: ctx.request.body,
    query: ctx.query,
    header
  })
  const headers = getAuthFromHeader(header as { [key: string]: string })
  logger.info({
    msg: '替换后的header参数',
    headers
  })
  const newUrl = url.replace('/drive', config.baseUrl.driveBaseUrl)

  logger.info({
    type: 'newUrl',
    msg: newUrl
  })
  try {
    const companyId = ctx.params.company_id
    const params = ctx.query
    const memberResult: any = await request.get(
    `${config.URL.driveRoute}/api/v3/search/company/${companyId}/members`,
    {
      params,
      headers: {
        cookie: ctx.request.header.cookie
      }
    }
    )
    logger.info({
      type: 'get接口返回结果',
      data: memberResult,
    })
    if (memberResult && memberResult.result === 'ok' && memberResult.members) {
      memberResult.members.forEach((item: any) => {
        if (item.email && item.email.length > 0) {
          item.name = `${item.name}${item.email.slice(0, 6)}****${item.email.slice(item.email.length - 4, item.email.length)}`
          if (item.highlight && item.highlight.user_name) {
            item.highlight.user_name[item.highlight.user_name.length - 1] = `${item.highlight.user_name[item.highlight.user_name.length - 1]} ${item.email.slice(0, 6)}****${item.email.slice(item.email.length - 4, item.email.length)}`
          }
        }
      })
      memberResult.members.falter((mitem: any) => mitem.email)
    }
    logger.info({
      type: '处理完的数据',
      data: memberResult,
    })
    ctx.status = 200
    ctx.body = memberResult
  } catch (e) {
    logger.info({
      type: 'get error',
      msg: e
    })
    let msg = ''
    // eslint-disable-next-line eqeqeq
    if (e.name == 'Error' && e.message) {
      msg = e.message
    } else {
      msg = e.messsage || e.msg || e.code
    }
    ctx.body = msg
  }
  return ctx
}

// delete 请求
export async function handleOtherDeleteFunc(ctx: Context) {
  const { request: requestInstance, method, url } = ctx
  const { header }: any = requestInstance
  logger.info({
    msg: '请求参数为',
    method,
    body: ctx.request.body,
    params: ctx.query,
    header
  })
  const headers = getAuthFromHeader(header as { [key: string]: string })
  const flag = url.includes('/open')
  const newUrl = url.replace('/drive', config.baseUrl.driveBaseUrl)

  try {
    // const res = await axios({
    //   url: newUrl,
    //   method: 'delete',
    //   // params: flag ? {} : ctx.query,
    //   headers: {
    //     cookie: ctx.request.header.cookie,
    //   }
    // })
    // logger.info({
    //   type: `${url} res`,
    //   msg: res.data
    // })
    const companyId = ctx.params.company_id
    const memberResult: any = await request.delete(
      `${config.URL.driveRoute}/api/v3/search/company/${companyId}/members`,
      {
        headers: {
          cookie: ctx.request.header.cookie,
          delWpsSign: true
        }
      }
    )

    ctx.status = 200
    ctx.body = memberResult
  } catch (e) {
    logger.info({
      type: 'delete error',
      msg: e
    })
    ctx.status = e.status || 403
    const result = errEventFunc(e)
    logger.info({ msg: 'result返回参数为:', result })
    ctx.body = result || e
  }

  return ctx
}

// post请求
export async function handleOtherPostFunc(ctx: Context) {
  const { request: requestInstance, method, url } = ctx
  const { header, body, query }: any = requestInstance
  logger.info({
    msg: '请求参数为',
    method,
    body: ctx.request.body,
    params: ctx.query,
    header
  })
  const headers = getAuthFromHeader(header as { [key: string]: string })

  const newUrl = url.replace('/drive', config.baseUrl.driveBaseUrl)

  logger.info({
    type: 'newUrl',
    msg: newUrl
  })
  let res
  try {
    // res = await axios({
    //   url: newUrl,
    //   method: 'post',
    //   // params: flag ? {} : ctx.query,
    //   data: body,
    //   headers: {
    //     cookie: ctx.request.header.cookie,
    //   }
    // })
    // logger.info({
    //   type: `${url} res`,
    //   msg: res.data
    // })
    const companyId = ctx.params.company_id
    const memberResult: any = await request.post(
      `${config.URL.driveRoute}/api/v3/search/company/${companyId}/members`,
      {
        headers: {
          cookie: ctx.request.header.cookie,
          delWpsSign: true
        }
      }
    )

    ctx.body = memberResult
    ctx.status = 200
  } catch (e) {
    logger.info({
      type: 'post error',
      msg: e
    })
    ctx.status = e.status || 403
    const result = errEventFunc(e)
    logger.info({ msg: 'result返回参数为:', result })
    ctx.body = result || e
  }
  return ctx
}

// put 请求
export async function handleOtherPutFunc(ctx: Context) {
  const { request: requestInstance, method, params, url } = ctx
  const { header, querystring, body }: any = requestInstance
  logger.info({
    msg: '请求参数为',
    method,
    body: ctx.request.body,
    params: ctx.query,
    header
  })
  const headers = getAuthFromHeader(header as { [key: string]: string })
  const flag = url.includes('/open')
  const newUrl = url.replace('/drive', config.baseUrl.driveBaseUrl)

  logger.info({
    type: 'newUrl',
    msg: newUrl
  })
  try {
    // const res = await axios({
    //   url: newUrl,
    //   method: 'put',
    //   // params: flag ? {} : ctx.query,
    //   data: body,
    //   headers: {
    //     cookie: ctx.request.header.cookie,
    //   }
    // })
    // logger.info({
    //   type: `${url} res`,
    //   msg: res.data
    // })
    const companyId = ctx.params.company_id
    const memberResult: any = await request.put(
      `${config.URL.driveRoute}/api/v3/search/company/${companyId}/members`,
      {
        headers: {
          cookie: ctx.request.header.cookie,
          delWpsSign: true
        }
      }
    )

    ctx.status = 200
    ctx.body = memberResult
  } catch (e) {
    logger.info({
      type: 'put error',
      msg: e
    })
    ctx.status = e.status || 403
    const result = errEventFunc(e)
    logger.info({ msg: 'result返回参数为:', result })
    ctx.body = result || e
  }

  return ctx
}
