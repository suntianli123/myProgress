import { Context } from 'koa'
import { resJson, resErrJson } from '../../util/msgCode'
import { getCompanyToken } from './func'
import request from '../../util/request'
import config from '../../config'
import { authUserTokenByUnionId } from '../../model/openApi/authToken'
import { log } from 'winston'

/**
 * @name 前置条件-企业授权-获取companyToken
 * @path /api/authToken/companyToken
 * @param {object} Context
 * @returns {object}
 */
export async function companyToken(ctx: Context) {
  let res
  try {
    const { reset } = ctx.request.query
    /** 获取企业token */
    const token = await getCompanyToken(!!reset)
    res = resJson({ data: token })
  } catch (e) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(e)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  ctx.body = res
  return ctx
}

/**
 * @name 前置条件-企业授权-重置companyToken
 * @path /api/authToken/companyToken
 * @param {object} Context
 * @returns {object}
 */
export async function resCompanyToken(ctx: Context) {
  let res
  try {
    /** 获取企业token */
    const token = await getCompanyToken(true)
    res = resJson({ data: token })
  } catch (e) {
    /** 格式化错误信息-记录错误日志 */
    const errJson = resErrJson(e)
    // 错误返回值
    res = errJson
  }
  ctx.status = 200
  ctx.body = res
  return ctx
}

/**
 * 通过third_union_id换取授权access_token
 */
export const getAccessToken = async (thirdUnionId: string) => {
  const accessTokenRes = await authUserTokenByUnionId(thirdUnionId)
  if (accessTokenRes.result !== 0) {
    resErrJson(
      `获取access_token失败, reason: ${JSON.stringify(accessTokenRes)}`
    )
    return ''
  }
  const {
    token: { access_token }
  } = accessTokenRes
  return access_token
}
