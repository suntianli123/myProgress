// *  *  *  *  *  *
// ┬ ┬ ┬ ┬ ┬ ┬
// │ │ │ │ │  |
// │ │ │ │ │ └ day of week (0 - 7) (0 or 7 is Sun)
// │ │ │ │ └───── month (1 - 12)
// │ │ │ └────────── day of month (1 - 31)
// │ │ └─────────────── hour (0 - 23)
// │ └──────────────────── minute (0 - 59)
// └───────────────────────── second (0 - 59, OPTIONAL)

import * as schedule from 'node-schedule'
import { redisGetLock, redisReleaseLock } from '../util/redis'
import config from '../config'
import { logger } from '../server'

const scheduleDeptTask = () => {
  // 每天0时0分0秒执行一次:
  schedule.scheduleJob('0 0 0 * * *', async () => {
    // redis-key
    const lockKey = `${config.appID}-DEPT-LOCK`
    // 有效时长 单位（秒）
    const expireTime = 5 * 60
    const lockResult = await redisGetLock(lockKey, expireTime)
    try {
      if (lockResult) {
        // TODO 成功获取到锁，执行业务逻辑

      }
    } catch (e) {
      logger.warn('部门定时任务执行异常', e)
    } finally {
      if (lockResult) {
        await redisReleaseLock(lockKey)
      }
    }
    console.log('【同步部门定时任务】' + new Date())
  })
}

export default scheduleDeptTask
