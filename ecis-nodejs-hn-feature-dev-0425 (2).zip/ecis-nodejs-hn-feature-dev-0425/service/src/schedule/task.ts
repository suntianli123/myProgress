// *  *  *  *  *  *
// ┬ ┬ ┬ ┬ ┬ ┬
// │ │ │ │ │  |
// │ │ │ │ │ └ day of week (0 - 7) (0 or 7 is Sun)
// │ │ │ │ └───── month (1 - 12)
// │ │ │ └────────── day of month (1 - 31)
// │ │ └─────────────── hour (0 - 23)
// │ └──────────────────── minute (0 - 59)
// └───────────────────────── second (0 - 59, OPTIONAL)

import * as schedule from 'node-schedule'
import { redisGetLock, redisReleaseLock } from '../util/redis'
import config from '../config'
import { logger } from '../server'
import { sleep } from '../util/utils'
import { Context } from 'koa'
import { deptSyncTotal } from '../api/deptinit'
import { userSyncTotal } from '../api/userinit'
import { handleCheckGroup, handleMessageGroup } from '../api/group'

const scheduleTask = () => {
  // logger.info(`定时任务开启，${config.taskCron}`)
  // 每10分钟执行一次: '0 0/10 * * * ?'
  // 每小时执行一次:
  schedule.scheduleJob(`${config.taskCron}`, async () => {
    logger.info('【移除成员/解散团队-定时任务开始】' + new Date())
    // redis-key
    const lockKey = `${config.appID}-GROUP-CHECK`
    // 有效时长 单位（秒）
    const expireTime = 1 * 60 * 60
    const lockResult = await redisGetLock(lockKey, expireTime)
    try {
      if (lockResult) {
        logger.info(`获取到锁: ${lockKey}, 执行同步`)
        await handleCheckGroup()
        await handleMessageGroup(['72','48','24','12','6','3'])
      } else {
        logger.warn(`未获取到锁: ${lockKey}, 任务退出`)
      }
    } catch (e) {
      logger.warn('移除成员/解散团队定时任务执行异常', e)
    } finally {
      // 释放锁
      logger.info(`释放锁: ${lockKey}`)
      if (lockResult) {
        await redisReleaseLock(lockKey)
      }
    }
    logger.info('【移除成员/解散团队-定时任务结束】' + new Date())
  })
}

export default scheduleTask
