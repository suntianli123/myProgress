import { Context } from 'koa'
import config from './config'
import * as Koa from 'koa'
import * as koaLogger from 'koa-logger'
import * as koaBody from 'koa-body'
import { createLogger, format, transports } from 'winston'

/* 测试接口-Start */
import { companyToken } from './api/authToken'
import { etcd } from './api/sdk/etcd'
import { cache } from './api/sdk/cache'
import { mysql } from './api/sdk/mysql'
import { getCompanyRoot, getAllDept, getAllUser, handleOtherPostFunc, handleOtherDeleteFunc, handleOtherGetFunc, handleOtherPutFunc, getSQLSelResult } from './api/common'
/* 测试接口-End */

import { callback, redirectToWps, userInfo } from './api/authorization'
import { deptSyncTotal } from './api/deptinit/index'
import { getIdConfuse, userSyncTotal } from './api/userinit/index'
import { batchChange, batchNotice, encryptUserId, getCompUsers, getGroupFromMiddle, getUserDataMsg, getUserInfoById, pullMemberByGroupId, removeMiddleGroup, searchMap } from './api/user/index'
import scheduleTask from './schedule/task'
import { deptStock, userStock } from './api/stock'
import { getgrouptime, searchgroup, testgroup, updatetime } from './api/group/grouptime'
import { groupType, messagePush } from './api/message'
import { encryptUserDept } from './api/group'
import { redisGetLock } from './util/redis'
import { sdkInstance } from './grpc/sdk'
import { resErrJson, resJson } from './util/msgCode'
import moment = require('moment')

const Router = require('@koa/router')
const koaStatic = require('koa-static')
const path = require('path')
const { combine, timestamp, colorize, errors, splat, json } = format

// 指定日志级别
const logLevel = process.env.LOG_LEVEL || 'info'

const app = new Koa()
const router = new Router()
// 创建日志实例
const logger = createLogger({
  format: combine(
    timestamp({
      format: 'YYYY-MM-DD HH:mm:ss'
    }),
    errors({ stack: true }),
    splat(),
    json(),
    colorize({ all: true })
  ),
  defaultMeta: { appid: config.appid },
  transports: [
    new transports.Console({
      level: logLevel
    })
  ]
})

// 开发环境 ./public  生产 ../../src/public
// app.use(koaStatic(path.join(__dirname, './public')))
app.use(koaStatic(path.join(__dirname, '../../src/public')))

app.use(koaLogger())
app.use(koaBody({ multipart: true }))

/** 定时任务执行 */
const taskFlag = config.taskFlag === 'on'
taskFlag && scheduleTask()

// app.use(async (ctx, next) => {
//   ctx.set('Access-Control-Allow-Origin', '*')
//   ctx.set('Access-Control-Allow-Headers', 'Content-Type, Content-Length, Authorization, Accept, X-Requested-With , yourHeaderFeild')
//   ctx.set('Access-Control-Allow-Methods', 'PUT, POST, GET, DELETE, OPTIONS')
//   if (ctx.method == 'OPTIONS') {
//     ctx.body = 200
//   } else {
//     await next()
//   }
// })

// 本地调试使用
router.post('/api/cache', cache)
router.post('/api/mysql', mysql)

router.get('/api/v1/getCompanyRoot', getCompanyRoot)
router.get('/api/v1/getCompanyToken', companyToken)
router.get('/api/v1/common/getAllDept', getAllDept)
router.get('/api/v1/common/getAllUser', getAllUser)

router.get('/test', (ctx: any) => {
  ctx.type = 'html'
  ctx.body = '<script>alert(1)</script>'
})

// sso-redirectToWps
router.get('/api/v1/authorization/redirectToWps', redirectToWps)
// sso-callback
router.get('/api/v1/authorization/callback', callback)
// sso-userInfo
router.get('/api/v1/authorization/userInfo', userInfo)

/* 全量部门同步 */
router.get('/api/v1/deptTotal', deptSyncTotal)
/* 全量用户同步 */
router.get('/api/v1/userTotal', userSyncTotal)
/* 加密用户id */
router.get('/api/v1/getIdConfuse', getIdConfuse)
/* 部门存量处理 */
router.post('/api/v1/deptStock', deptStock)
/* 用户存量处理 */
router.post('/api/v1/userStock', userStock)

/* 接收批次推送，根据批次创建团队 */
router.post('/batchNotice', batchNotice)
/* 接收批次推送，根据批次同步团队及成员 */
router.post('/changeNotice', batchChange)
/* 根据userId获取用户信息 */
router.get('/getUserInfoById', getUserInfoById)
/* 手动更新团队成员 */
router.get('/pullMemberByGroupId', pullMemberByGroupId)
/* 手动解散团队时移除中间表记录 */
router.delete('/removeMiddleGroup/:group_id', removeMiddleGroup)
/* 查询团队是否在中间表 */
router.get('/getGroupFromMiddle', getGroupFromMiddle)
/* 根据用户ID获取用户信息 */
router.get('/api/v1/encryptUserDept', encryptUserDept)
/* 拦截成员搜索接口 */
// router.get('/drive/api/v3/search/company/:company_id/members', searchMap)
// /drive/api/v3/search/company/(.*)
router.post('/drive/api/v3/search/company/:company_id/members', handleOtherPostFunc)
router.get('/drive/api/v3/search/company/:company_id/members', searchMap)
router.delete('/drive/api/v3/search/company/:company_id/members', handleOtherDeleteFunc)
router.put('/drive/api/v3/search/company/:company_id/members', handleOtherPutFunc)

/* 更新中间表中团队信息 */
router.post('/api/v1/group/updatetime', updatetime)
/* 获取所有中间表中团队信息 */
router.get('/api/v1/group/getgrouptime', getgrouptime)
/* 搜索中间表中团队信息 */
router.get('/api/v1/group/searchgroup', searchgroup)
router.get('/api/v1/group/testgroup', testgroup)

// 消息推送
router.get('/api/v1/message/push', messagePush)
// 判断团队是否为招标团队
router.get('/api/v1/message/groupType', groupType)

router.get('/api/v1/testDept', async (ctx: Context) => {
  const key = 'async-etcd-lock-test'
  // 有效时长 单位（秒）
  const expireTime = 60 * 5
  const lockResult: any = await redisGetLock(key, expireTime)
  ctx.body = lockResult
  ctx.status = 200
})

router.post('/api/v1/messagePUsh', async (ctx: Context) => {
  let res: any
  try {
    const msgData = ctx.request.body
    const msgPushData = await sdkInstance.service.msgCenter.pushMsg(msgData)
    logger.info({
      msg: '消息推送结果',
      msgPushData
    })
    if (msgPushData.result == 'ok') {
      res = resJson({ msg: '消息推送成功' })
    } else {
      res = resErrJson({ msg: '消息推送失败' })
    }
  } catch (error) {
    res = resErrJson({ msg: '消息推送失败' })
  }
  ctx.body = res
  ctx.status = 200
  return ctx
})


// 响应etcd配置，
router.post('/inject/v2/replace/GetMetadata/:fileid', async (ctx: Context) => {

  const body: any = ctx.request.body
  try {
    const headers: any = ctx.headers
    const fileid = ctx.params.fileid

    logger.info('請求了這個接口：/inject/v2/replace/GetMetadata/{fileid}')
    logger.info({
      params: ctx.params,
      msg: 'params参数',
      url: ctx.request.url
    })

    if (!fileid) {
      return {
        result: 'ERR_BAD_FILE_ID',
        data: '文件id不可用'
      }
    }

    logger.info({
      body,
      msg: 'body参数333333'
    })
    // 文档创建者id 未加密
    // const creatorid = body.creator.deprecated_id
    // 当前用户id 未加密
    const currentUserid = body.user.deprecated_id
    // 获取当前登陆着开放平台用户id
    const currentUserInfoObj = await getCompUsers(`${currentUserid}`)
    logger.info({
      msg: '长用户id',
      currentUserInfoObj
    })

    const currentOpenUserId = await encryptUserId(`${currentUserInfoObj.comp_uid}`)
    logger.info({
      msg: '开放平台用户id',
      currentOpenUserId
    })

    const userResult: any = await getUserDataMsg(currentOpenUserId)
    if (userResult.result && userResult.result == 1) {
      // 当前文档所属团队id 未加密
      const group_id = body.file.attrs.groupid
      const groupId = await encryptUserId(`${group_id}`)

      const SQLResult = await sdkInstance.middleware.mysql.select(
        config.dbName,
        'SELECT * FROM middle_group WHERE group_id=?',
        [groupId]
      )
      const groupMiddle = await getSQLSelResult(SQLResult)

      if(groupMiddle && groupMiddle.length) {
        body.file.user_acl.move = 0
        body.file.user_acl.rename = 0
        body.file.user_acl.share = 0
      }
      
    }



    ctx.body = body
  } catch (error) {
    logger.error({
      msg: '报错信息',
      error
    })
    ctx.body = body
  }
  ctx.status = 200
  return ctx
})

app.use(router.routes())

// 单元测试-提供方法
const run = (port: number) => {
  return app.listen(port)
}

// 未捕获的Api异常
app.on('request-error', (error: Error, ctx: Context) => {
  logger.error({
    type: 'request-error',
    message: error.message,
    requestId: ctx.requestId
  })
})

// 未捕获的服务异常
app.on('server-error', (error: any) => {
  logger.error({
    type: 'server-error',
    message: error.message
  })
})

// 未捕获的异常
process.on('uncaughtException', err => {
  logger.error({ msg: `未捕获的异常:${err}` })
})

export { logger, run }
