import * as crypto from 'crypto'
import { v1, v3, v5 } from 'uuid'
import { thirdReq } from '../../../util/request'
import config from '../../../config'
import { sdkInstance } from '../../../grpc/sdk'
import { resCheck, sdkCheck } from '../../../util/msgCode'
import { checkTimer } from '../../../api/authToken/func'

/**
 * @name 通过code获取AccessToken
 * @param {string} code
 * @param {string} uri
 * @returns {Promise}
 */
export const codeToAccessToken = async (code: string, clientType = 1): Promise<any> => {
  const headers = await getThirdHeader()
  return await thirdReq.request({
    url: `/service-system/api/getToken?code=${code}`,
    method: 'POST',
    data: {
      clientType,
      clientId: config.third.clientId
    },
    headers
  })
}

/**
 * @name 通过AccessToken获取用户信息
 * @param {string} code
 * @param {string} uri
 * @returns {Promise}
 */
export const accessTokenToUser = async (token: string): Promise<any> => {
  const headers = await getThirdHeader()
  return await thirdReq.request({
    url: '/service-system/api/getAccountInfo',
    method: 'POST',
    headers: {
      ...headers,
      'x-tif-token': token
    }
  })
}

export const getDataTotal = async (url: string): Promise<any[]> => {
  let pageNum = 1
  let total = 0
  const data: any[] = []
  do {
    const headers = await getThirdHeader()
    const result: any = await thirdReq.post(
      url,
      {
        page_num: pageNum,
        page_size: 500
      },
      { headers }
    )
    if (result.result && Array.isArray(result.result.records)) {
      pageNum++
      total = result.result.total
      data.push(...result.result.records)
      console.log(result.result.records.length, data.length, total)
    }
  } while (data.length < total)
  return data
}

/**
 * 获取应用token
 */
export const getAppToken = async (): Promise<string> => {
  const {
    third: { clientId: client_id, clientSecret: client_secret }
  } = config
  return await thirdReq.post(
    '/service-auth/oauth/token',
    {
      grant_type: 'client_credentials',
      client_id,
      client_secret
    },
    {
      headers: {
        'Content-Type': 'application/json'
      }
    }
  )
}

export const getAppTokenByCache = async (reset = false) => {
  let tempToken: any = await sdkInstance.middleware.cache.get('third_app_token')
  sdkCheck(tempToken)
  if (reset || !tempToken.data.data || checkTimer(tempToken)) {
    /** 通过三方应用token */
    const resData: any = await getAppToken()
    resCheck(resData)
    const { expires_in, access_token } = resData
    // *1000转换成秒 - 提前一分钟过期
    const timestamp = new Date().getTime() + expires_in * 1000 - 1000 * 60
    const value = { value: access_token, expire: timestamp }
    const setCompanyToken = await sdkInstance.middleware.cache.set(
      'third_app_token',
      JSON.stringify(value)
    )
    sdkCheck(setCompanyToken)
    tempToken = access_token
  } else {
    tempToken = JSON.parse(tempToken.data.data).value
  }
  return tempToken
}

const getThirdHeader = async () => {
  const timestamp = new Date().getTime().toString()
  const appToken = await getAppTokenByCache()
  const nonce = v1()
  const signature = thirdSign(timestamp, appToken, nonce)
  return {
    signature,
    timestamp,
    nonce,
    Authorization: `Bearer ${appToken}`,
    'Content-Type': 'application/json'
  }
}

const thirdSign = (timestamp: string, appToken: string, nonce: string): string => {
  const shaData = `${timestamp}${appToken}${nonce},${timestamp}`
  return crypto.createHash('sha256').update(shaData).digest('hex').toUpperCase()
}
