import request from '../../../util/request'
import { API } from './typings'

/**
 * 1. 创建团队
 * @param companyToken
 * @param data
 * @returns
 */
export const createGroupAdmin = async (
  companyToken: string,
  data: API.CreateGroupAdminRequest
): Promise<API.CreateGroupAdminResponse> => {
  return await request.request({
    url: `/open/kopen/plus/v2/open/dev/groups?company_token=${companyToken}`,
    method: 'POST',
    data
  })
}

/**
 * 2. 修改团队信息
 * @param companyToken
 * @param data
 * @returns
 */
export const updateGroupAdmin = async (
  companyToken: string,
  groupId: string,
  data: API.UpdateGroupAdminRequest
): Promise<API.ResponseApi> => {
  return await request.request({
    url: `/open/kopen/plus/v2/open/dev/groups/${groupId}?company_token=${companyToken}`,
    method: 'PUT',
    data
  })
}

/**
 * 3. 删除团队
 * @param companyToken
 * @param data
 * @returns
 */
export const deleteGroup = async (
  groupId: string,
  accessToken: string,
  companyToken: string
): Promise<API.ResponseApi> => {
  return await request.request({
    url: `/open/drive/v1/corpgroups/${groupId}?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'DELETE'
  })
}

/**
 * 获取团队成员列表
 * @param groupId
 * @param accessToken
 * @param companyToken
 * @param companyUids
 * @returns
 */
export const getGroupMember = async (
  groupId: string,
  accessToken: string,
  companyToken: string
): Promise<API.GetGroupMemberResponse> => {
  return await request.request({
    url: `/open/drive/v1/corpgroups/${groupId}/members?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'GET'
  })
}

/**
 * 添加团队成员
 * @param groupId
 * @param accessToken
 * @param companyToken
 * @param companyUids
 * @returns
 */
export const insertGroupMember = async (
  groupId: string,
  accessToken: string,
  companyToken: string,
  companyUids: string
): Promise<API.ResponseApi> => {
  return await request.request({
    url: `/open/drive/v1/corpgroups/${groupId}/members?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'POST',
    data: {
      company_uids: companyUids
    }
  })
}

/**
 * 删除团队成员
 * @param groupId
 * @param companyUid
 * @param accessToken
 * @param companyToken
 * @returns
 */
export const deleteGroupMember = async (
  groupId: string,
  companyUid: string,
  accessToken: string,
  companyToken: string
): Promise<API.ResponseApi> => {
  return await request.request({
    url: `/open/drive/v1/corpgroups/${groupId}/members/${companyUid}?access_token=${accessToken}&company_token=${companyToken}`,
    method: 'DELETE'
  })
}
