/**
 * 企业团队管理（管理级）接口
 * */

export type GroupType = 'corpnormal' | 'corpdep'
export type MemberList = Array<{
  company_uid: string
  name: string
  role: string
}>
export namespace API {
  /** 公共返回值 */
  interface ResponseApi {
    result: number
    msg?: string
  }

  interface GetGroupMemberResponse extends ResponseApi {
    data: MemberList
  }

  interface CreateGroupAdminRequest {
    operator_id: string // 是 操作者company_uid，目前只支持传入超级管理员ID
    dept_id?: string // 否 部门ID，创建部门团队时为必传参数
    name?: string // 否 团队名称 创建普通团队时为必传参数。创建部门团队时，无需传入，将会使用部门名称作为部门团队的名称。限制：长度限制为120个中文，或240个英文。不支持特殊字符：`/:;*?",<>
    owner_id?: string // 否 团队拥有者company_uid 创建普通团队时为必传参数 创建部门团队时，为可选参数，如果不指定，则创建的部门团队无拥有者；如果指定，则指定的人必须在部门中。
    reason?: string // 否 创建原因 仅在创建普通团队，且企业开启了创建团队需要审批开关时，需要填写
    type: GroupType // 是 团队类型 普通企业团队: corpnormal 部门团队: corpdep
  }
  interface CreateGroupAdminResponse extends ResponseApi {
    apply?: {
      id: number
      link: string
    }
    group: {
      id: string
      name: string
      owner_id: string
      type: string
    }
  }

  interface UpdateGroupAdminRequest {
    operator_id: string // 是 操作者company_uid，目前只支持传入超级管理员ID
    owner_id?: string // 否 团队拥有者company_uid
  }
}
