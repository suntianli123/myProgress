// import * as mysql from 'mysql'
// import config from '../config'

// const connection = mysql.createPool({
//   host: `${config.database.host}`,
//   port: config.database.port,
//   database: `${config.database.database}`,
//   user: `${config.database.user}`,
//   password: `${config.database.password}`,
//   supportBigNumbers: true,
//   bigNumberStrings: true
// })

// const query = async (sql: string): Promise<any> => {
//   return await new Promise((resolve, reject) => {
//     connection.query(sql, (err, res: any) => {
//       if (err) {
//         console.log('mysql error', err)
//         // logger.error({ sql, msg: `${stringifyLoop(err)}` })
//         reject(err)
//       } else {
//         resolve(res)
//       }
//     })
//   })
// }

// export default query
