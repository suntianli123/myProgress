import axios from 'axios'
import type {
  AxiosInstance,
  AxiosRequestConfig,
  AxiosResponse,
  AxiosError
} from 'axios'
import config from '../config'
import { sign } from './wpsSign'
import { logger } from '../server'
const https = require('https')

const agent = new https.Agent({
  rejectUnauthorized: false
})

/** 创建request对象 */
const request: AxiosInstance = axios.create({
  baseURL: config.domain,
  timeout: 30000
})

/** request拦截器  */
request.interceptors.request.use(
  (conf: AxiosRequestConfig) => {
    /** WPS-3 签名 */
    if (!conf.headers.delWpsSign) {
      conf.headers = {
        ...conf.headers,
        ...sign(conf)
      }
      delete conf.headers.delWpsSign
    }
    // console.log(conf.url)
    return conf
  },
  (error: AxiosError) => {
    return Promise.reject(error)
  }
)

const interceptorsResponse = (response: AxiosResponse) => {
  // console.log(response.data)
  return response.data ? response.data : response
}

const interceptorResponseError = (error: AxiosError) => {
  const { message, config, response } = error
  if (response && response.data) {
    logger.warn({ message: `error-response-data: ${JSON.stringify(response.data)}` })
    logger.warn({ message: `error-config-data: ${JSON.stringify(config.data)}` })
    logger.warn({ message: `error-config-url: ${JSON.stringify(config.url)}` })
    logger.warn({ message: `error-config-headers: ${JSON.stringify(config.headers)}` })
    return Promise.resolve(response.data)
  }
  logger.warn({ message: `error: ${JSON.stringify(error)}` })
  const err = message
  logger.warn({ message: `url:${config.url},message:${message}` })
  return Promise.resolve(err)
}

const interceptorResponseErrorThird = (error: AxiosError) => {
  const { message, config, response } = error
  try {
    if (response && response.data) {
      logger.warn({ message: `error-response-data: ${JSON.stringify(response.data)}` })
      logger.warn({ message: `error-config-data: ${JSON.stringify(config.data)}` })
      logger.warn({ message: `error-config-url: ${JSON.stringify(config.url)}` })
      logger.warn({ message: `error-config-headers: ${JSON.stringify(config.headers)}` })
      return Promise.resolve(response.data)
    }
    logger.warn({ message: `error: ${JSON.stringify(error)}` })
    const err = message
    logger.warn({ message: `url:${config.url},message:${message}` })
    return Promise.resolve(err)
  } catch (e) {
    logger.warn(e)
    logger.warn(`响应拦截error处理出错: ${JSON.stringify(e)}`)
    console.log(error)
    return Promise.resolve(error)
  }
}

/** response拦截器  */
request.interceptors.response.use(
  interceptorsResponse,
  interceptorResponseError
)

export default request

export const thirdReq: AxiosInstance = axios.create({
  baseURL: config.third.domain,
  timeout: 30000,
  httpsAgent: agent
})

/** request拦截器  */
thirdReq.interceptors.request.use(
  (conf: AxiosRequestConfig) => {
    logger.info({ req: JSON.stringify(conf) })
    return conf
  },
  (error: AxiosError) => {
    return Promise.reject(error)
  }
)

thirdReq.interceptors.response.use(
  interceptorsResponse,
  interceptorResponseErrorThird
)
