import axios from "axios"
import { logger } from "../ins"
import { resErrJson } from "./msgCode"
import config from "../config"
import { sdkInstance } from "../grpc/sdk"
const sha1 = require('js-sha1')
const md5 = require('md5')

export async function sleep(ms: number) {
  return await new Promise(resolve => setTimeout(resolve, ms))
}

export async function getDecrypt(ctx: any) {
  let msg: any = ''
  const thirdunionid = ctx.request ? ctx.request.body.thirdunionid : ctx
  logger.info('拿到的开放平台id为:' + thirdunionid)
  const appId: any = config.appID
  const appKey: any = config.appKey
  const url: any = '/auth/private/id/deconfuse?cipher_text=' + thirdunionid

  let origin = await sdkInstance.middleware.cache.get('origin')
  logger.info({
    origin,
    msg: 'redis存储的origin'
  })
  if (origin) {
    origin = origin.data.data
  }
  const host = config.domain + '/open' // 'http://yunkit-opengateway'

  const time: any = new Date().toUTCString() //  'Mon, 26 Sep 2022 04:57:10 GMT' // new Date().toUTCString()

  const contentMd5: any = md5(Buffer.from('', 'utf8').toString())

  function _sig(contentMd5: any, url: string) {
    const hash = sha1.create()
    hash.update(appKey.toLocaleLowerCase())
    hash.update(contentMd5)
    hash.update(url)
    hash.update('application/json')
    hash.update(time)
    return `WPS-3:${appId}:${hash.hex()}`
  }

  try {
    const res = await axios.request({
      url: `${host}${url}`,
      method: 'get',
      headers: {
        'Content-type': 'application/json',
        'X-Auth': _sig(contentMd5, url),
        Date: time,
        'Content-Md5': contentMd5
      }
    })

    if (res.statusText === 'OK') {
      msg = {
        status: res.status,
        data: res.data
      }
      console.log(res.data)
      return res.data.de_confuse_result[thirdunionid] || ''
    } else {
      msg = resErrJson('开放平台id解密失败')
    }
  } catch (error) {
    logger.error('开放平台id解密为compuid: ' + error)
    msg = resErrJson(error)
  }
  ctx.code = 200
  ctx.body = msg
  return ctx
}
