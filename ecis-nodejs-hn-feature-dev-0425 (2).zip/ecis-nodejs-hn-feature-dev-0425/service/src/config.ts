import * as dotenv from 'dotenv'
dotenv.config()

interface Config {
  port: number
  appid: any
  appkey: any
  grpc: {
    addr: string
  }
  ecisHost: string

  // 扩展字段
  domain: string
  scope: string
  appID: string
  appKey: string
  dbName: string
  // 组件id
  cid: string
  compId: string
  baseUrl: {
    driveBaseUrl: string
    openBaseUrl: string
  }
  third: {
    domain: string
    clientId: string
    clientSecret: string
  }
  department: {
    parentId: string
    expertDept: string
    juryDept: string
  }
  URL: {
    getThirdInfo: string
    thirdInfoMethod: string
    driveRoute: string
  }
  data: {
    batchPath: string
    detailPath: string
    detailBidExpertPath: string
    detailJuryBidPath: string
    keys: {
      batchNumberKey: string
      IDCardKey: string
      startTimeKey: string
      endTimeKey: string
    }
    memberKeys: {
      id: string
      name: string
      mobilePhone: string
    }
  }
  taskCron: string
  taskFlag: string
  redis: {
    password: string
    members: Array<{
      port: number
      host: string
    }>
  }
}

const config: Config = {
  port: process.env.HTTP_KPORT ? parseInt(process.env.HTTP_KPORT) : 8000,
  appid: process.env.AK,
  appkey: process.env.SK,
  grpc: {
    addr: process.env.GRPC_ADDR ? process.env.GRPC_ADDR : 'encs-pri-ecis:50051'
  },
  ecisHost: process.env.ECIS_HOST
    ? process.env.ECIS_HOST
    : 'http://encs-pri-cams-engine/i/encs-pri-ecis',

  // 测试环境
  // domain: process.env.DOMAIN || 'http://192.168.0.23',
  // appID: process.env.APPID || 'AK20230808EOPCYA',
  // appKey: process.env.APPKEY || 'cd67056e5e60d3a1b6df3ded71167001',

  domain: process.env.DOMAIN || 'http://172.21.131.57',
  appID: process.env.APPID || 'AK20231016ECXHLW',
  appKey: process.env.APPKEY || '17ff464b35d2d3b87572bf954a6e2835',

  // 企业通讯录, 企业文档管理, 企业普通团队管理, 企业团队管理（管理级）
  scope:
    'corp_contacts_mgr,corp_files_synerg_mgr,corp_normal_group_all,admin_corp_groups.all',
  dbName: `ecis_plugins_${process.env.AK}`,
  cid: process.env.COMPONENT || 'ACCOUNTHNZB',
  compId: process.env.COMP_ID || '669229269',
  // 第三方
  third: {
    domain: '', //  三方域名
    clientId: '',
    clientSecret: ''
  },
  baseUrl: {
    driveBaseUrl: 'http://mics-urlrouter',
    openBaseUrl: 'http://yunkit-opengateway'
  },
  // 第三方根部门id
  department: {
    parentId: 'A10000',
    // 专家所属部门wpsID
    // expertDept: process.env.EXPERT_DEPT || 'L7DwP6x8yVr6MDE',
    // // 招标人代表所属部门wpsID
    // juryDept: process.env.JURY_DEPT || 'o1wEl3Eddv5MMDE'
    expertDept: process.env.EXPERT_DEPT || 'xO8VZV217LLOMDE',
    // 招标人代表所属部门wpsID
    juryDept: process.env.JURY_DEPT || 'NXVPvRG8WX2PMDE'
  },
  URL: {
    // 三方接口地址 - 评委会批次专家详细信息获取
    getThirdInfo:
      process.env.THIRD_INFO_URL ||
      'http://172.21.131.102:3000/mock/11/WPS/user_hnzb',
    // 请求方式
    thirdInfoMethod: process.env.THIRD_INFO_METHOD || 'post',
    // 自定义路由拦截后 服务端转发网关
    driveRoute: process.env.DRIVE_ROUTE || 'http://mics-urlrouter'
  },
  data: {
    // 三方调用插件接口传参路径 ctx.request.body
    batchPath: process.env.BATCH_DATA_PATH || 'request.body',
    // 评委会批次专家详细信息获取接口 - 返回数据路径 result.data
    detailPath: process.env.DETAIL_DATA_PATH || 'data',
    // 评委会批次专家详细信息获取接口 - 专家信息字段
    detailBidExpertPath: process.env.BID_EXPERT_DATA_PATH || 'evaExperts',
    // 评委会批次专家详细信息获取接口 - 招标人信息字段
    detailJuryBidPath: process.env.JURY_BID_DATA_PATH || 'evaRepresents',
    keys: {
      // 批次号字段
      batchNumberKey: process.env.KEY_BATCH_NUMBER || 'BatchNumber',
      // 项目经理身份证字段
      IDCardKey: process.env.KEY_ID_CARD || 'CompanyIDCard',
      // 评标开始时间字段
      startTimeKey: process.env.KEY_START_TIME || 'BidStartDate',
      // 评标结束时间字段
      endTimeKey: process.env.KEY_END_TIME || 'BidEndDate'
    },
    memberKeys: {
      // 专家、招标人身份证号（唯一标识）
      id: process.env.KEY_MEMBER_ID_CARD || 'idcard',
      // 专家、招标人姓名
      name: process.env.KEY_MEMBER_NAME || 'name',
      // 专家、招标人手机号（未用到 可忽略）
      mobilePhone: process.env.KEY_MEMBER_PHONE || 'mobilePhone'
    }
  },
  // 定时任务执行规则  0 0/15 * * * ? / 0 0 * * * ?
  taskCron: process.env.TASK_CRON || '0 0/15 * * * ? ',
  // 定时任务开关
  taskFlag: process.env.TASK_FLAG || 'off', // on -> 开启定时任务
  // redis锁配置 客户环境 - 192.168.0.x
  redis: {
    password: process.env.REDIS_PASS || 'kQ#!@tHAkKp!2$Ry',
    members: [
      {
        port: 8532,
        host: process.env.REDIS_HOST_8532 || '192.168.0.87'
      },
      {
        port: 8534,
        host: process.env.REDIS_HOST_8534 || '192.168.0.87'
      },
      {
        port: 8533,
        host: process.env.REDIS_HOST_8533 || '192.168.0.88'
      },
      {
        port: 8535,
        host: process.env.REDIS_HOST_8535 || '192.168.0.88'
      },
      {
        port: 8531,
        host: process.env.REDIS_HOST_8531 || '192.168.0.86'
      },
      {
        port: 8536,
        host: process.env.REDIS_HOST_8536 || '192.168.0.86'
      }
    ]
  }
}

export default config
