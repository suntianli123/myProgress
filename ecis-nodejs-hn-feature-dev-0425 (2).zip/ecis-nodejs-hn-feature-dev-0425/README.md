# ecis-nodejs-template-v61228

# 代码结构1.1.6

- ecissdk/ 定制能力SDK
- src/api/ API接口
- src/ins/ 全局实例
- src/model/ 定义数据模型
- src/util/ 工具方法
- src/unitest/ 单元测试
- src/index.ts 入口
- Dockerfile 本地开发构建Docker

# 基本操作

- 切换到服务目录：`cd service/<服务名>`
- 安装ecissdk依赖：`cd ecissdk && npm i`
- 安装开发依赖：`npm i`
- Eslint：`npm run eslint`
- 格式化：`npm run format`
- 单元测试：`npm run test`
- 启动服务：`npm run nodemon`

## 本地开发构建Docker

0. 构建Docker 镜像，导出镜像并生成ca文件，若未配置zip环境变量，需要将servie-ACCOUNTHNZB-1.0.1与meta.json文件一同压缩为zip格式并重命名

参数为组件ID和版本号(debug包无需修改版本号), 构建时会做单元测试, 需要保证单元测试正常

```
sh build_service.sh ACCOUNTHNZB 1.0.1
```

# 开发规范

- 使用Nodejs + Typescript + Koa2 框架开发
- ecissdk目录下的文件是grpc sdkclient相关代码，开发者无需进行修改
- 函数方法应该便于单元测试 
- 开发集中在service/<xxx>, unittest/xxx_test.go, manifest.json等3个目录和文件, 尽量不要对工程其他文件进行修改,否则可能导致构建不一致,失败等请求
- 开发者需要保证所有依赖能够通过公网拉取且能够通过Dockerfile 构建
- 服务名必须简单达意, 只能是26个小写字母,短横杆, 不能有特殊字符

# 单元测试

1. 所有单元测试写到unittest目录中
2. 命名`<功能点名称>.test.ts`

注: ecissdk 注意更新!
