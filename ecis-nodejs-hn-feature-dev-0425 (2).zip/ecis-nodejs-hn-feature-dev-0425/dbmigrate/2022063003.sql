SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `middle_group` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `group_id` varchar(50) NOT NULL COMMENT 'WPS团队ID',
  `batch_number` varchar(50) NOT NULL COMMENT '批次号',
  `own_id` varchar(50) NOT NULL COMMENT '团队拥有者开放平台id',
  `user_id` varchar(50) NOT NULL COMMENT '团队拥有者三方id',
  `start_time` datetime NOT NULL COMMENT '评标开始时间',
  `end_time` datetime NOT NULL COMMENT '评标结束时间',
  `member_endtime` varchar(50)  COMMENT '团员解散小时',
  `group_endtime` varchar(50)  COMMENT '团队解散小时',
  `message_time` varchar(50)  COMMENT '记录团队解散小时',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `update_time` datetime NOT NULL COMMENT '修改时间',
  `is_delete` int(1) NOT NULL COMMENT '删除标示：0未删除，1删除',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_batch_number` (`batch_number`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
